import '../../../shared/widgets/ios_density.dart';
import '../../../shared/widgets/sharp_logo.dart';
import '../../authentication/presentation/personal_account_settings_page.dart';
import '../../memberships/presentation/membership_settings_link.dart';
import '../../legal/presentation/legal_info_page.dart';
import '../../../shared/security/upload_safety.dart';
import '../../delivery/presentation/supplier_delivery_settings_page.dart';
import '../../../shared/widgets/phone_layout.dart';

import 'dart:typed_data';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class SupplierSettingsPage extends StatelessWidget {
  const SupplierSettingsPage({
    super.key,
    this.embedded = false,
    this.onBrandingChanged,
  });

  final bool embedded;
  final VoidCallback? onBrandingChanged;

  static const _darkRed = Color(0xFF741C1C);
  static const _canvas = Color(0xFFF7F8FA);
  static const _border = Color(0xFFE3E5E8);
  static const _muted = Color(0xFF666A70);

  Widget _body(BuildContext context) {
    return Align(
      alignment: Alignment.topCenter,
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 1180),
        child: ListView(
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 28),
          children: [
            const MembershipSettingsLink(),
            ListTile(
              leading: const Icon(Icons.privacy_tip_outlined),
              title: const Text('Privacy & policies'),
              subtitle: const Text('Notices and information requests'),
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute<void>(builder: (_) => const LegalInfoPage()),
              ),
            ),
            if (!embedded) ...[
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: _border),
                  boxShadow: const [
                    BoxShadow(
                      color: Color(0x07000000),
                      blurRadius: 10,
                      offset: Offset(0, 3),
                    ),
                  ],
                ),
                child: const Row(
                  children: [
                    Icon(Icons.tune_outlined, color: _darkRed, size: 22),
                    SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Supplier Settings',
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                          IosGap(height: 2),
                          Text(
                            'Manage your business profile, invoice configuration, privacy and notification preferences.',
                            style: TextStyle(color: _muted, fontSize: 12),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              const IosGap(height: 12),
            ],
            LayoutBuilder(
              builder: (context, constraints) {
                final twoColumns = constraints.maxWidth >= 760;

                final cards = [
                  _SettingsTile(
                    icon: Icons.local_shipping_outlined,
                    title: 'Delivery settings',
                    subtitle:
                        'Delivery availability, lead times, cut-off and delivery defaults.',
                    onTap: () => Navigator.of(context).push(
                      MaterialPageRoute<void>(
                        builder: (_) => const SupplierDeliverySettingsPage(
                          settingsOnly: true,
                        ),
                      ),
                    ),
                  ),
                  _SettingsTile(
                    icon: Icons.business_outlined,
                    title: 'Business Profile',
                    subtitle:
                        'Trading name, legal name, contact details and business address.',
                    onTap: () {
                      Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (_) => const SupplierProfileSettingsPage(),
                        ),
                      );
                    },
                  ),
                  _SettingsTile(
                    icon: Icons.receipt_long_outlined,
                    title: 'Invoice Configuration',
                    subtitle:
                        'Company logo, ABN, invoice contact details, address and banking details.',
                    onTap: () {
                      Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (_) => SupplierInvoiceConfigurationPage(
                            onBrandingChanged: onBrandingChanged,
                          ),
                        ),
                      );
                    },
                  ),
                  _SettingsTile(
                    icon: Icons.privacy_tip_outlined,
                    title: 'Privacy',
                    subtitle:
                        'Control marketplace profile visibility and customer access to contact details.',
                    onTap: () {
                      Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (_) => const SupplierPrivacySettingsPage(),
                        ),
                      );
                    },
                  ),
                  _SettingsTile(
                    icon: Icons.notifications_outlined,
                    title: 'Notifications',
                    subtitle:
                        'Choose which order, quote, payment and invoice activity should notify you.',
                    onTap: () {
                      Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (_) =>
                              const SupplierNotificationSettingsPage(),
                        ),
                      );
                    },
                  ),
                ];

                if (!twoColumns) {
                  return Column(
                    children: [
                      for (var i = 0; i < cards.length; i++) ...[
                        cards[i],
                        if (i != cards.length - 1) const IosGap(height: 10),
                      ],
                    ],
                  );
                }

                return Column(
                  children: [
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(child: cards[0]),
                        const SizedBox(width: 10),
                        Expanded(child: cards[1]),
                      ],
                    ),
                    const IosGap(height: 10),
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(child: cards[2]),
                        const SizedBox(width: 10),
                        Expanded(child: cards[3]),
                      ],
                    ),
                  ],
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _workspaceHeader() {
    return Container(
      height: 62,
      padding: const EdgeInsets.symmetric(horizontal: 22),
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(bottom: BorderSide(color: _border)),
      ),
      child: Row(
        children: [
          Container(
            width: 34,
            height: 34,
            decoration: BoxDecoration(
              color: const Color(0xFFF5EAEA),
              borderRadius: BorderRadius.circular(9),
            ),
            child: const Icon(
              Icons.settings_outlined,
              color: _darkRed,
              size: 19,
            ),
          ),
          const SizedBox(width: 11),
          const Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Settings',
                  style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900),
                ),
                IosGap(height: 1),
                Text(
                  'Manage your business profile, account preferences and platform settings',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: Color(0xFF74787E),
                    fontSize: 10.8,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (embedded) {
      return ColoredBox(
        color: _canvas,
        child: Column(
          children: [
            _workspaceHeader(),
            Expanded(child: _body(context)),
          ],
        ),
      );
    }

    return Scaffold(
      backgroundColor: _canvas,
      appBar: phoneAppBar(
        context,
        AppBar(
          backgroundColor: Colors.white,
          surfaceTintColor: Colors.white,
          elevation: 0,
          scrolledUnderElevation: 0,
          titleSpacing: 20,
          title: const Row(
            children: [
              Icon(Icons.settings_outlined, color: _darkRed, size: 22),
              SizedBox(width: 10),
              Text(
                'Settings',
                style: TextStyle(fontWeight: FontWeight.w900, fontSize: 19),
              ),
            ],
          ),
          bottom: const PreferredSize(
            preferredSize: Size.fromHeight(1),
            child: Divider(height: 1, thickness: 1, color: _border),
          ),
        ),
      ),
      body: _body(context),
    );
  }
}

class _SettingsTile extends StatelessWidget {
  const _SettingsTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  static const _darkRed = Color(0xFF741C1C);
  static const _border = Color(0xFFE3E5E8);
  static const _muted = Color(0xFF666A70);

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(14),
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: onTap,
        child: Container(
          constraints: const BoxConstraints(minHeight: 116),
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: _border),
            boxShadow: const [
              BoxShadow(
                color: Color(0x07000000),
                blurRadius: 10,
                offset: Offset(0, 3),
              ),
            ],
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: const Color(0xFFF8EEEE),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(icon, color: _darkRed, size: 20),
              ),
              const SizedBox(width: 11),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w900,
                        color: Color(0xFF1E2329),
                      ),
                    ),
                    const IosGap(height: 4),
                    Text(
                      subtitle,
                      style: const TextStyle(
                        color: _muted,
                        fontSize: 11.5,
                        height: 1.35,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              const IosPadding(
                padding: EdgeInsets.only(top: 7),
                child: Icon(
                  Icons.chevron_right,
                  color: Color(0xFF8A8F96),
                  size: 20,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _SupplierSettingsData {
  static List<Map<String, dynamic>> maps(dynamic value) {
    if (value is! List) return [];
    return value
        .whereType<Map>()
        .map((row) => Map<String, dynamic>.from(row))
        .toList();
  }

  static Future<String> resolveSupplierBusinessId() async {
    final client = Supabase.instance.client;
    final userId = client.auth.currentUser?.id;

    if (userId == null) {
      throw Exception('You are not signed in.');
    }

    final memberships = await client
        .from('business_memberships')
        .select('business_id')
        .eq('user_id', userId)
        .eq('status', 'active');

    final businessIds = <String>[
      for (final row in maps(memberships))
        if (row['business_id'] != null) row['business_id'].toString(),
    ];

    if (businessIds.isEmpty) {
      throw Exception('No active business membership was found.');
    }

    final businesses = await client
        .from('businesses')
        .select('id, business_type, active')
        .inFilter('id', businessIds);

    for (final business in maps(businesses)) {
      if (business['business_type']?.toString() == 'supplier' &&
          business['active'] != false) {
        final id = business['id']?.toString();
        if (id != null && id.isNotEmpty) {
          return id;
        }
      }
    }

    throw Exception('No active supplier business was found.');
  }
}

class SupplierProfileSettingsPage extends StatefulWidget {
  const SupplierProfileSettingsPage({super.key});

  @override
  State<SupplierProfileSettingsPage> createState() =>
      _SupplierProfileSettingsPageState();
}

class _SupplierProfileSettingsPageState
    extends State<SupplierProfileSettingsPage> {
  bool _loading = true;
  bool _saving = false;
  String? _error;
  String? _businessId;

  final _tradingName = TextEditingController();
  final _legalName = TextEditingController();
  final _email = TextEditingController();
  final _phone = TextEditingController();
  final _address1 = TextEditingController();
  final _address2 = TextEditingController();
  final _suburb = TextEditingController();
  final _state = TextEditingController();
  final _postcode = TextEditingController();

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    for (final c in [
      _tradingName,
      _legalName,
      _email,
      _phone,
      _address1,
      _address2,
      _suburb,
      _state,
      _postcode,
    ]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final id = await _SupplierSettingsData.resolveSupplierBusinessId();
      final business = await Supabase.instance.client
          .from('businesses')
          .select('''
            trading_name,
            legal_name,
            business_email,
            business_phone,
            address_line_1,
            address_line_2,
            suburb,
            state,
            postcode
          ''')
          .eq('id', id)
          .single();

      _tradingName.text = business['trading_name']?.toString() ?? '';
      _legalName.text = business['legal_name']?.toString() ?? '';
      _email.text = business['business_email']?.toString() ?? '';
      _phone.text = business['business_phone']?.toString() ?? '';
      _address1.text = business['address_line_1']?.toString() ?? '';
      _address2.text = business['address_line_2']?.toString() ?? '';
      _suburb.text = business['suburb']?.toString() ?? '';
      _state.text = business['state']?.toString() ?? '';
      _postcode.text = business['postcode']?.toString() ?? '';

      if (!mounted) return;
      setState(() {
        _businessId = id;
        _loading = false;
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _error = error.toString();
        _loading = false;
      });
    }
  }

  Future<void> _save() async {
    final businessId = _businessId;
    if (businessId == null || _saving) return;

    setState(() => _saving = true);

    try {
      final result = await Supabase.instance.client.rpc(
        'update_my_business_profile',
        params: {
          'target_business_id': businessId,
          'p_trading_name': _tradingName.text.trim(),
          'p_legal_name': _legalName.text.trim(),
          'p_business_email': _email.text.trim(),
          'p_business_phone': _phone.text.trim(),
          'p_address_line_1': _address1.text.trim(),
          'p_address_line_2': _address2.text.trim(),
          'p_suburb': _suburb.text.trim(),
          'p_state': _state.text.trim(),
          'p_postcode': _postcode.text.trim(),
        },
      );

      if (result is! Map) {
        throw Exception('The business profile was not saved.');
      }

      final saved = Map<String, dynamic>.from(result);

      _tradingName.text = saved['trading_name']?.toString() ?? '';
      _legalName.text = saved['legal_name']?.toString() ?? '';
      _email.text = saved['business_email']?.toString() ?? '';
      _phone.text = saved['business_phone']?.toString() ?? '';
      _address1.text = saved['address_line_1']?.toString() ?? '';
      _address2.text = saved['address_line_2']?.toString() ?? '';
      _suburb.text = saved['suburb']?.toString() ?? '';
      _state.text = saved['state']?.toString() ?? '';
      _postcode.text = saved['postcode']?.toString() ?? '';

      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Business profile saved successfully.')),
      );
    } on PostgrestException catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text(error.message)));
      }
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text(error.toString())));
      }
    } finally {
      if (mounted) {
        setState(() => _saving = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return _SettingsFormScaffold(
      title: 'Business Profile',
      loading: _loading,
      error: _error,
      saving: _saving,
      onRetry: _load,
      onSave: _save,
      child: Column(
        children: [
          const PersonalAccountSettingsPage(embedded: true),
          const IosGap(height: 20),
          const Divider(),
          const IosGap(height: 16),
          const Align(
            alignment: Alignment.centerLeft,
            child: Text(
              'Business details',
              style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800),
            ),
          ),
          const IosGap(height: 16),
          _field(_tradingName, 'Trading Name'),
          _field(_legalName, 'Legal Name'),
          _field(
            _email,
            'Business Contact Email',
            keyboardType: TextInputType.emailAddress,
          ),
          _field(_phone, 'Business Phone', keyboardType: TextInputType.phone),
          _field(_address1, 'Address Line 1'),
          _field(_address2, 'Address Line 2'),
          _field(_suburb, 'Suburb'),
          PhoneRow(
            mode: PhoneRowMode.stack,
            desktop: Row(
              children: [
                Expanded(child: _field(_state, 'State')),
                const SizedBox(width: 12),
                Expanded(
                  child: _field(
                    _postcode,
                    'Postcode',
                    keyboardType: TextInputType.number,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class SupplierInvoiceConfigurationPage extends StatefulWidget {
  const SupplierInvoiceConfigurationPage({super.key, this.onBrandingChanged});

  final VoidCallback? onBrandingChanged;

  @override
  State<SupplierInvoiceConfigurationPage> createState() =>
      _SupplierInvoiceConfigurationPageState();
}

class _SupplierInvoiceConfigurationPageState
    extends State<SupplierInvoiceConfigurationPage> {
  bool _loading = true;
  bool _saving = false;
  String? _error;
  String? _businessId;
  String? _logoPath;
  Uint8List? _logoBytes;
  bool _uploadingLogo = false;

  final _abn = TextEditingController();
  final _licence = TextEditingController();
  final _email = TextEditingController();
  final _phone = TextEditingController();
  final _address1 = TextEditingController();
  final _address2 = TextEditingController();
  final _suburb = TextEditingController();
  final _state = TextEditingController();
  final _postcode = TextEditingController();
  final _bankName = TextEditingController();
  final _accountName = TextEditingController();
  final _bsb = TextEditingController();
  final _accountNumber = TextEditingController();
  final _instructions = TextEditingController();
  final _salesName = TextEditingController();
  final _salesPhone = TextEditingController();
  final _accreditations = TextEditingController();
  final _invoiceTerms = TextEditingController();
  final _labellingNotice = TextEditingController();

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    for (final c in [
      _abn,
      _licence,
      _email,
      _phone,
      _address1,
      _address2,
      _suburb,
      _state,
      _postcode,
      _bankName,
      _accountName,
      _bsb,
      _accountNumber,
      _instructions,
      _salesName,
      _salesPhone,
      _accreditations,
      _invoiceTerms,
      _labellingNotice,
    ]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final id = await _SupplierSettingsData.resolveSupplierBusinessId();
      final client = Supabase.instance.client;
      final profile = await client
          .from('supplier_invoice_profiles')
          .select()
          .eq('supplier_business_id', id)
          .maybeSingle();
      final business = await client
          .from('businesses')
          .select('logo_path')
          .eq('id', id)
          .single();

      final logoPath = business['logo_path']?.toString().trim() ?? '';

      if (profile != null) {
        _abn.text = profile['abn']?.toString() ?? '';
        _licence.text = profile['licence_number']?.toString() ?? '';
        _email.text = profile['invoice_email']?.toString() ?? '';
        _phone.text = profile['invoice_phone']?.toString() ?? '';
        _address1.text = profile['address_line_1']?.toString() ?? '';
        _address2.text = profile['address_line_2']?.toString() ?? '';
        _suburb.text = profile['suburb']?.toString() ?? '';
        _state.text = profile['state']?.toString() ?? '';
        _postcode.text = profile['postcode']?.toString() ?? '';
        _bankName.text = profile['bank_name']?.toString() ?? '';
        _accountName.text = profile['bank_account_name']?.toString() ?? '';
        _bsb.text = profile['bank_bsb']?.toString() ?? '';
        _accountNumber.text = profile['bank_account_number']?.toString() ?? '';
        _instructions.text = profile['payment_instructions']?.toString() ?? '';
        _salesName.text = profile['default_salesperson_name']?.toString() ?? '';
        _salesPhone.text =
            profile['default_salesperson_phone']?.toString() ?? '';
        _accreditations.text =
            profile['accreditation_details']?.toString() ?? '';
        _invoiceTerms.text = profile['invoice_terms']?.toString() ?? '';
        _labellingNotice.text =
            profile['retail_labelling_notice']?.toString() ?? '';
      }

      if (!mounted) return;
      setState(() {
        _businessId = id;
        _logoPath = logoPath.isEmpty ? null : logoPath;
        _loading = false;
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _error = error.toString();
        _loading = false;
      });
    }
  }

  String? _logoPublicUrl() {
    final path = _logoPath;
    if (path == null || path.isEmpty) return null;
    return Supabase.instance.client.storage
        .from('business-branding')
        .getPublicUrl(path);
  }

  Future<void> _pickLogo() async {
    final businessId = _businessId;
    if (businessId == null || _uploadingLogo) return;

    final result = await FilePicker.pickFiles(
      type: FileType.custom,
      allowedExtensions: const ['png', 'jpg', 'jpeg'],
    );
    if (result.isEmpty) return;

    final file = result.first;
    final bytes = await file.readAsBytes();
    if (bytes.length > 5 * 1024 * 1024) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Logo must be 5 MB or smaller.')),
        );
      }
      return;
    }

    final extension = file.name.contains('.')
        ? file.name.split('.').last.toLowerCase()
        : 'png';
    final normalisedExtension = extension == 'jpeg' ? 'jpg' : extension;
    if (!const {'png', 'jpg'}.contains(normalisedExtension)) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Use a PNG or JPG company logo.')),
        );
      }
      return;
    }

    final newPath = '$businessId/logo.$normalisedExtension';
    final oldPath = _logoPath;
    final contentType = normalisedExtension == 'png'
        ? 'image/png'
        : 'image/jpeg';

    setState(() => _uploadingLogo = true);
    try {
      await UploadSafety.validateImage(bytes, file.name);
      final client = Supabase.instance.client;
      await client.storage
          .from('business-branding')
          .uploadBinary(
            newPath,
            bytes,
            fileOptions: FileOptions(contentType: contentType, upsert: true),
          );

      await client.rpc(
        'set_my_business_logo',
        params: {'p_business_id': businessId, 'p_logo_path': newPath},
      );

      if (oldPath != null && oldPath.isNotEmpty && oldPath != newPath) {
        try {
          await client.storage.from('business-branding').remove([oldPath]);
        } catch (_) {}
      }

      if (!mounted) return;
      setState(() {
        _logoPath = newPath;
        _logoBytes = bytes;
      });
      widget.onBrandingChanged?.call();
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('Company logo updated.')));
    } on FormatException catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text(error.message)));
      }
    } on StorageException catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text(error.message)));
      }
    } on PostgrestException catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text(error.message)));
      }
    } finally {
      if (mounted) setState(() => _uploadingLogo = false);
    }
  }

  Future<void> _removeLogo() async {
    final businessId = _businessId;
    final path = _logoPath;
    if (businessId == null || path == null || _uploadingLogo) return;

    setState(() => _uploadingLogo = true);
    try {
      final client = Supabase.instance.client;
      await client.rpc(
        'set_my_business_logo',
        params: {'p_business_id': businessId, 'p_logo_path': null},
      );
      try {
        await client.storage.from('business-branding').remove([path]);
      } catch (_) {}

      if (!mounted) return;
      setState(() {
        _logoPath = null;
        _logoBytes = null;
      });
      widget.onBrandingChanged?.call();
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('Company logo removed.')));
    } on PostgrestException catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text(error.message)));
      }
    } finally {
      if (mounted) setState(() => _uploadingLogo = false);
    }
  }

  Widget _brandingPanel() {
    final logoUrl = _logoPublicUrl();
    final hasLogo = _logoBytes != null || logoUrl != null;

    Widget preview;
    if (_logoBytes != null) {
      preview = SharpLogo.memory(_logoBytes!);
    } else if (logoUrl != null) {
      preview = SharpLogo.network(
        logoUrl,
        errorBuilder: (_, _, _) => const Icon(
          Icons.business_outlined,
          size: 38,
          color: Color(0xFF777777),
        ),
      );
    } else {
      preview = const Icon(
        Icons.business_outlined,
        size: 38,
        color: Color(0xFF777777),
      );
    }

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFFF8F9FA),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFE3E5E8)),
      ),
      child: PhoneRow(
        mode: PhoneRowMode.stack,
        desktop: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              width: 150,
              height: 82,
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: const Color(0xFFDADDE0)),
              ),
              child: preview,
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Company Logo',
                    style: TextStyle(fontSize: 14, fontWeight: FontWeight.w900),
                  ),
                  const IosGap(height: 4),
                  const Text(
                    'Used automatically on your CutLink supplier identity, quotes and invoices. PNG or JPG, up to 5 MB.',
                    style: TextStyle(
                      color: Color(0xFF666A70),
                      fontSize: 11.5,
                      height: 1.35,
                    ),
                  ),
                  const IosGap(height: 10),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      FilledButton.icon(
                        onPressed: _uploadingLogo ? null : _pickLogo,
                        icon: _uploadingLogo
                            ? const SizedBox(
                                width: 15,
                                height: 15,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  color: Colors.white,
                                ),
                              )
                            : const Icon(Icons.upload_outlined, size: 17),
                        label: Text(hasLogo ? 'Change Logo' : 'Upload Logo'),
                      ),
                      if (hasLogo)
                        OutlinedButton.icon(
                          onPressed: _uploadingLogo ? null : _removeLogo,
                          icon: const Icon(Icons.delete_outline, size: 17),
                          label: const Text('Remove'),
                        ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _save() async {
    if (_businessId == null || _saving) return;
    setState(() => _saving = true);

    try {
      final saved = await Supabase.instance.client
          .from('supplier_invoice_profiles')
          .upsert({
            'supplier_business_id': _businessId,
            'abn': _abn.text.trim(),
            'licence_number': _licence.text.trim(),
            'invoice_email': _email.text.trim(),
            'invoice_phone': _phone.text.trim(),
            'address_line_1': _address1.text.trim(),
            'address_line_2': _address2.text.trim(),
            'suburb': _suburb.text.trim(),
            'state': _state.text.trim(),
            'postcode': _postcode.text.trim(),
            'bank_name': _bankName.text.trim(),
            'bank_account_name': _accountName.text.trim(),
            'bank_bsb': _bsb.text.trim(),
            'bank_account_number': _accountNumber.text.trim(),
            'payment_instructions': _instructions.text.trim(),
            'default_salesperson_name': _salesName.text.trim(),
            'default_salesperson_phone': _salesPhone.text.trim(),
            'accreditation_details': _accreditations.text.trim(),
            'invoice_terms': _invoiceTerms.text.trim(),
            'retail_labelling_notice': _labellingNotice.text.trim(),
          })
          .select()
          .single();

      if (saved['supplier_business_id']?.toString() != _businessId) {
        throw Exception('The invoice configuration was not saved.');
      }

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Invoice configuration saved.')),
        );
      }
    } on PostgrestException catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text(error.message)));
      }
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return _SettingsFormScaffold(
      title: 'Invoice Configuration',
      loading: _loading,
      error: _error,
      saving: _saving,
      onRetry: _load,
      onSave: _save,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const _SectionHeading('Company Branding'),
          _brandingPanel(),
          const Divider(height: 30),
          const _SectionHeading('Supplier Invoice Details'),
          _field(_abn, 'ABN'),
          _field(_licence, 'Licence Number'),
          _field(
            _email,
            'Invoice Email',
            keyboardType: TextInputType.emailAddress,
          ),
          _field(_phone, 'Invoice Phone', keyboardType: TextInputType.phone),
          const Divider(height: 30),
          const _SectionHeading('Invoice Address'),
          _field(_address1, 'Address Line 1'),
          _field(_address2, 'Address Line 2'),
          _field(_suburb, 'Suburb'),
          PhoneRow(
            mode: PhoneRowMode.stack,
            desktop: Row(
              children: [
                Expanded(child: _field(_state, 'State')),
                const SizedBox(width: 12),
                Expanded(
                  child: _field(
                    _postcode,
                    'Postcode',
                    keyboardType: TextInputType.number,
                  ),
                ),
              ],
            ),
          ),
          const Divider(height: 30),
          const _SectionHeading('Banking Details'),
          _field(_bankName, 'Bank Name'),
          _field(_accountName, 'Account Name'),
          _field(_bsb, 'BSB', keyboardType: TextInputType.number),
          _field(
            _accountNumber,
            'Account Number',
            keyboardType: TextInputType.number,
          ),
          _field(_instructions, 'Payment Instructions', maxLines: 3),
          const Divider(height: 30),
          const _SectionHeading('Sales Contact & Invoice Notices'),
          const Text(
            'These defaults apply to new invoices only. Override the sales contact on a Quote or Work Order before invoicing. Account numbers use each customer’s Account Reference.',
          ),
          const IosGap(height: 12),
          _field(_salesName, 'Default salesperson name'),
          _field(
            _salesPhone,
            'Salesperson phone',
            keyboardType: TextInputType.phone,
          ),
          _field(
            _accreditations,
            'Accreditations / MSA licence details',
            maxLines: 3,
          ),
          _field(
            _labellingNotice,
            'Retail labelling notice (optional)',
            maxLines: 3,
          ),
          _field(
            _invoiceTerms,
            'Supplier terms / claims / payment notices (optional)',
            maxLines: 5,
          ),
          const Text(
            'Enter only your own verified accreditations and applicable terms. Issue-reporting hours come from the customer/order terms. Notices do not change prices, GST, fees or the issue-reporting workflow.',
          ),
        ],
      ),
    );
  }
}

class SupplierPrivacySettingsPage extends StatefulWidget {
  const SupplierPrivacySettingsPage({super.key});

  @override
  State<SupplierPrivacySettingsPage> createState() =>
      _SupplierPrivacySettingsPageState();
}

class _SupplierPrivacySettingsPageState
    extends State<SupplierPrivacySettingsPage> {
  bool _loading = true;
  bool _saving = false;
  String? _error;
  String? _businessId;
  bool _marketplaceVisible = true;
  bool _shareContact = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final id = await _SupplierSettingsData.resolveSupplierBusinessId();
      final settings = await Supabase.instance.client
          .from('business_app_settings')
          .select()
          .eq('business_id', id)
          .maybeSingle();

      if (settings != null) {
        _marketplaceVisible = settings['marketplace_profile_visible'] != false;
        _shareContact =
            settings['share_contact_with_approved_customers'] != false;
      }

      if (!mounted) return;
      setState(() {
        _businessId = id;
        _loading = false;
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _error = error.toString();
        _loading = false;
      });
    }
  }

  Future<void> _save() async {
    if (_businessId == null || _saving) return;
    setState(() => _saving = true);

    try {
      final saved = await Supabase.instance.client
          .from('business_app_settings')
          .upsert({
            'business_id': _businessId,
            'marketplace_profile_visible': _marketplaceVisible,
            'share_contact_with_approved_customers': _shareContact,
          })
          .select()
          .single();

      if (saved['business_id']?.toString() != _businessId) {
        throw Exception('The privacy settings were not saved.');
      }

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Privacy settings saved.')),
        );
      }
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return _SettingsFormScaffold(
      title: 'Privacy',
      loading: _loading,
      error: _error,
      saving: _saving,
      onRetry: _load,
      onSave: _save,
      child: Column(
        children: [
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Show supplier profile in marketplace'),
            subtitle: const Text(
              'Allows CutLink users to see your supplier profile where applicable.',
            ),
            value: _marketplaceVisible,
            onChanged: (value) {
              setState(() => _marketplaceVisible = value);
            },
          ),
          const Divider(),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Share contact details with approved customers'),
            subtitle: const Text(
              'Approved customers can see your business contact details.',
            ),
            value: _shareContact,
            onChanged: (value) {
              setState(() => _shareContact = value);
            },
          ),
        ],
      ),
    );
  }
}

class SupplierNotificationSettingsPage extends StatefulWidget {
  const SupplierNotificationSettingsPage({super.key});

  @override
  State<SupplierNotificationSettingsPage> createState() =>
      _SupplierNotificationSettingsPageState();
}

class _SupplierNotificationSettingsPageState
    extends State<SupplierNotificationSettingsPage> {
  final Map<String, bool> _activityPreferences = {
    'notify_platform': true,
    'notify_messages': true,
    'notify_credit_updates': true,
    'notify_delivery_updates': true,
    'notify_support_updates': true,
    'notify_product_reviews': true,
  };
  bool _muteAll = false;
  bool _loading = true;
  bool _saving = false;
  String? _error;
  String? _businessId;

  bool _newOrders = true;
  bool _quoteActivity = true;
  bool _paymentClaims = true;
  bool _invoiceUpdates = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final id = await _SupplierSettingsData.resolveSupplierBusinessId();
      final settings = await Supabase.instance.client
          .from('business_app_settings')
          .select()
          .eq('business_id', id)
          .maybeSingle();

      if (settings != null) {
        _muteAll = settings['mute_all_notifications'] == true;
        for (final key in _activityPreferences.keys) {
          _activityPreferences[key] = settings[key] != false;
        }
        _newOrders = settings['notify_new_orders'] != false;
        _quoteActivity = settings['notify_quote_activity'] != false;
        _paymentClaims = settings['notify_payment_claims'] != false;
        _invoiceUpdates = settings['notify_invoice_updates'] != false;
      }

      if (!mounted) return;
      setState(() {
        _businessId = id;
        _loading = false;
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _error = error.toString();
        _loading = false;
      });
    }
  }

  Future<void> _save() async {
    if (_businessId == null || _saving) return;
    setState(() => _saving = true);

    try {
      final saved = await Supabase.instance.client
          .from('business_app_settings')
          .upsert({
            'business_id': _businessId,
            ..._activityPreferences,
            'mute_all_notifications': _muteAll,
            'notify_new_orders': _newOrders,
            'notify_quote_activity': _quoteActivity,
            'notify_payment_claims': _paymentClaims,
            'notify_invoice_updates': _invoiceUpdates,
          })
          .select()
          .single();

      if (saved['business_id']?.toString() != _businessId) {
        throw Exception('The notification settings were not saved.');
      }

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Notification settings saved.')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              e is PostgrestException
                  ? e.message
                  : 'Could not save notification preferences. Please try again.',
            ),
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return _SettingsFormScaffold(
      title: 'Notification settings',
      loading: _loading,
      error: _error,
      saving: _saving,
      onRetry: _load,
      onSave: _save,
      child: Column(
        children: [
          const Text(
            'Choose what appears in the dashboard bell and unread alerts. Turn a category off to mute it. All activity remains available in All notifications.',
          ),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Mute all dashboard alerts'),
            subtitle: const Text(
              'Keep notification history without bell alerts.',
            ),
            value: _muteAll,
            onChanged: _saving ? null : (v) => setState(() => _muteAll = v),
          ),
          for (final entry in const {
            'notify_platform': 'CutLink announcements',
            'notify_messages': 'Marketplace messages & issues',
            'notify_credit_updates': 'Credits & refunds',
            'notify_delivery_updates': 'Delivery and pickup updates',
            'notify_support_updates': 'CutLink Support replies',
            'notify_product_reviews': 'Product reports and corrections',
          }.entries)
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: Text(entry.value),
              value: _activityPreferences[entry.key]!,
              onChanged: (v) =>
                  setState(() => _activityPreferences[entry.key] = v),
            ),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('New marketplace orders'),
            value: _newOrders,
            onChanged: (value) {
              setState(() => _newOrders = value);
            },
          ),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Quote activity'),
            value: _quoteActivity,
            onChanged: (value) {
              setState(() => _quoteActivity = value);
            },
          ),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Customer payment claims'),
            value: _paymentClaims,
            onChanged: (value) {
              setState(() => _paymentClaims = value);
            },
          ),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Invoice updates'),
            value: _invoiceUpdates,
            onChanged: (value) {
              setState(() => _invoiceUpdates = value);
            },
          ),
        ],
      ),
    );
  }
}

class _SettingsFormScaffold extends StatelessWidget {
  const _SettingsFormScaffold({
    required this.title,
    required this.loading,
    required this.error,
    required this.saving,
    required this.onRetry,
    required this.onSave,
    required this.child,
  });

  final String title;
  final bool loading;
  final String? error;
  final bool saving;
  final VoidCallback onRetry;
  final VoidCallback onSave;
  final Widget child;

  static const _darkRed = Color(0xFF741C1C);
  static const _canvas = Color(0xFFF7F8FA);
  static const _border = Color(0xFFE3E5E8);
  static const _muted = Color(0xFF666A70);

  IconData get _pageIcon {
    switch (title) {
      case 'Business Profile':
        return Icons.business_outlined;
      case 'Invoice Configuration':
        return Icons.receipt_long_outlined;
      case 'Privacy':
        return Icons.privacy_tip_outlined;
      case 'Notifications':
        return Icons.notifications_outlined;
      default:
        return Icons.settings_outlined;
    }
  }

  String get _pageDescription {
    switch (title) {
      case 'Business Profile':
        return 'Maintain the supplier details used throughout CutLink.';
      case 'Invoice Configuration':
        return 'Manage the supplier information and payment details shown on invoices.';
      case 'Privacy':
        return 'Control how your supplier profile and contact information are shared.';
      case 'Notifications':
        return 'Choose which supplier activity should generate notifications.';
      default:
        return 'Manage this supplier setting.';
    }
  }

  AppBar _appBar(BuildContext context) {
    return phoneAppBar(
      context,
      AppBar(
        backgroundColor: Colors.white,
        surfaceTintColor: Colors.white,
        elevation: 0,
        scrolledUnderElevation: 0,
        titleSpacing: 8,
        title: Row(
          children: [
            Icon(_pageIcon, color: _darkRed, size: 21),
            const SizedBox(width: 9),
            Text(
              title,
              style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18),
            ),
          ],
        ),
        bottom: const PreferredSize(
          preferredSize: Size.fromHeight(1),
          child: Divider(height: 1, thickness: 1, color: _border),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return Scaffold(
        backgroundColor: _canvas,
        appBar: _appBar(context),
        body: const Center(child: CircularProgressIndicator(color: _darkRed)),
      );
    }

    if (error != null) {
      return Scaffold(
        backgroundColor: _canvas,
        appBar: _appBar(context),
        body: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 560),
            child: Container(
              margin: const EdgeInsets.all(24),
              padding: const EdgeInsets.all(22),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: _border),
                boxShadow: const [
                  BoxShadow(
                    color: Color(0x07000000),
                    blurRadius: 10,
                    offset: Offset(0, 3),
                  ),
                ],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.error_outline, color: _darkRed, size: 30),
                  const IosGap(height: 12),
                  Text(
                    error!,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      color: Color(0xFF4B4F55),
                      height: 1.4,
                    ),
                  ),
                  const IosGap(height: 18),
                  FilledButton.icon(
                    style: FilledButton.styleFrom(
                      backgroundColor: _darkRed,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(
                        horizontal: 18,
                        vertical: 14,
                      ),
                    ),
                    onPressed: onRetry,
                    icon: const Icon(Icons.refresh),
                    label: const Text(
                      'Try Again',
                      style: TextStyle(fontWeight: FontWeight.w800),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      );
    }

    return Scaffold(
      backgroundColor: _canvas,
      appBar: _appBar(context),
      body: Align(
        alignment: Alignment.topCenter,
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 980),
          child: ListView(
            padding: const EdgeInsets.fromLTRB(24, 28, 24, 50),
            children: [
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: _border),
                  boxShadow: const [
                    BoxShadow(
                      color: Color(0x07000000),
                      blurRadius: 10,
                      offset: Offset(0, 3),
                    ),
                  ],
                ),
                child: Row(
                  children: [
                    Container(
                      width: 46,
                      height: 46,
                      decoration: BoxDecoration(
                        color: const Color(0xFFF8EEEE),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Icon(_pageIcon, color: _darkRed, size: 23),
                    ),
                    const SizedBox(width: 13),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            title,
                            style: const TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                          const IosGap(height: 3),
                          Text(
                            _pageDescription,
                            style: const TextStyle(
                              color: _muted,
                              fontSize: 12.5,
                              height: 1.4,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              const IosGap(height: 18),
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: _border),
                  boxShadow: const [
                    BoxShadow(
                      color: Color(0x07000000),
                      blurRadius: 10,
                      offset: Offset(0, 3),
                    ),
                  ],
                ),
                child: child,
              ),
              const IosGap(height: 18),
              Align(
                alignment: Alignment.centerRight,
                child: SizedBox(
                  height: 48,
                  child: FilledButton.icon(
                    style: FilledButton.styleFrom(
                      backgroundColor: _darkRed,
                      foregroundColor: Colors.white,
                      disabledBackgroundColor: _darkRed.withValues(alpha: 0.45),
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                    onPressed: saving ? null : onSave,
                    icon: saving
                        ? const SizedBox(
                            width: 17,
                            height: 17,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color: Colors.white,
                            ),
                          )
                        : const Icon(Icons.save_outlined, size: 19),
                    label: Text(
                      saving ? 'Saving...' : 'Save Changes',
                      style: const TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _SectionHeading extends StatelessWidget {
  const _SectionHeading(this.text);

  final String text;

  @override
  Widget build(BuildContext context) {
    return IosPadding(
      padding: const EdgeInsets.only(bottom: 12),
      child: PhoneRow(
        mode: PhoneRowMode.wrap,
        desktop: Row(
          children: [
            Container(
              width: 4,
              height: 20,
              decoration: BoxDecoration(
                color: const Color(0xFF741C1C),
                borderRadius: BorderRadius.circular(999),
              ),
            ),
            const SizedBox(width: 9),
            Text(
              text,
              style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w900,
                color: Color(0xFF1E2329),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

Widget _field(
  TextEditingController controller,
  String label, {
  TextInputType? keyboardType,
  int maxLines = 1,
}) {
  return IosPadding(
    padding: const EdgeInsets.only(bottom: 14),
    child: TextField(
      controller: controller,
      keyboardType: keyboardType,
      maxLines: maxLines,
      decoration: InputDecoration(
        labelText: label,
        filled: true,
        fillColor: Colors.white,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: const BorderSide(color: Color(0xFFD9DDE1)),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: const BorderSide(color: Color(0xFFD9DDE1)),
        ),
      ),
    ),
  );
}
