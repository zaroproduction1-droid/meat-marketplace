import '../../../shared/widgets/ios_density.dart';
import '../../../shared/widgets/phone_layout.dart';

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'supplier_invoice_page.dart';

class SupplierInvoicesPage extends StatefulWidget {
  const SupplierInvoicesPage({super.key, this.embedded = false});

  final bool embedded;

  @override
  State<SupplierInvoicesPage> createState() => _SupplierInvoicesPageState();
}

class _SupplierInvoicesPageState extends State<SupplierInvoicesPage>
    with SingleTickerProviderStateMixin {
  static const _darkRed = Color(0xFF741C1C);

  late final TabController _tabController;

  bool _isLoading = true;
  String? _errorMessage;

  List<Map<String, dynamic>> _invoices = [];
  final Set<String> _busyInvoiceIds = <String>{};

  final _searchController = TextEditingController();

  static const _tabs = <String>[
    'all',
    'draft',
    'issued',
    'part_paid',
    'paid',
    'void',
  ];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: _tabs.length, vsync: this);
    _tabController.addListener(() {
      if (!_tabController.indexIsChanging && mounted) {
        setState(() {});
      }
    });
    _searchController.addListener(() {
      if (mounted) {
        setState(() {});
      }
    });
    _loadInvoices();
  }

  @override
  void dispose() {
    _tabController.dispose();
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _loadInvoices() async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    try {
      final client = Supabase.instance.client;
      final userId = client.auth.currentUser?.id;

      if (userId == null) {
        throw Exception('You must be signed in.');
      }

      final membership = await client
          .from('business_memberships')
          .select('business_id, businesses(id, business_type)')
          .eq('user_id', userId)
          .limit(50);

      String? supplierBusinessId;

      for (final raw in membership as List) {
        if (raw is! Map) {
          continue;
        }

        final row = Map<String, dynamic>.from(raw);
        final businessRaw = row['businesses'];

        if (businessRaw is Map) {
          final business = Map<String, dynamic>.from(businessRaw);
          final type = business['business_type']?.toString();

          if (type == 'supplier') {
            supplierBusinessId = row['business_id']?.toString();
            break;
          }
        }
      }

      if (supplierBusinessId == null || supplierBusinessId.isEmpty) {
        throw Exception('No supplier business membership was found.');
      }

      final response = await client
          .from('invoices')
          .select('''
            id,
            invoice_number,
            order_id,
            supplier_business_id,
            butcher_business_id,
            supplier_customer_account_id,
            status,
            customer_name_snapshot,
            customer_reference_snapshot,
            payment_method_snapshot,
            payment_terms_days_snapshot,
            products_subtotal,
            delivery_fee,
            tax_status,
            tax_category_snapshot,
            tax_rate_snapshot,
            tax_amount,
            total_amount,
            invoice_date,
            due_date,
            issued_at,
            sent_to_butcher_at,
            amount_paid,
            credit_applied,
            outstanding_amount,
            paid_at,
            voided_at,
            created_at,
            updated_at,
            orders(
              id,
              order_number,
              order_source
            )
          ''')
          .eq('supplier_business_id', supplierBusinessId)
          .order('created_at', ascending: false);

      if (!mounted) {
        return;
      }

      setState(() {
        _invoices = (response as List)
            .whereType<Map>()
            .map((row) => Map<String, dynamic>.from(row))
            .toList();
        _isLoading = false;
      });
    } on PostgrestException catch (error) {
      if (!mounted) {
        return;
      }

      setState(() {
        _errorMessage = error.message;
        _isLoading = false;
      });
    } catch (error) {
      if (!mounted) {
        return;
      }

      setState(() {
        _errorMessage = error.toString();
        _isLoading = false;
      });
    }
  }

  double _asDouble(dynamic value) {
    if (value is num) {
      return value.toDouble();
    }

    return double.tryParse('$value') ?? 0;
  }

  String _money(dynamic value) {
    final amount = _asDouble(value);
    final formatted = amount.toStringAsFixed(2);
    final parts = formatted.split('.');
    final whole = parts.first;
    final decimal = parts.last;

    final buffer = StringBuffer();
    for (var i = 0; i < whole.length; i++) {
      final remaining = whole.length - i;
      buffer.write(whole[i]);

      if (remaining > 1 && remaining % 3 == 1) {
        buffer.write(',');
      }
    }

    return '\$${buffer.toString()}.$decimal';
  }

  String _statusLabel(String? status) {
    return switch (status) {
      'draft' => 'Draft',
      'ready' => 'Created',
      'issued' => 'Created',
      'part_paid' => 'Part Paid',
      'paid' => 'Paid',
      'void' => 'Void',
      _ => status ?? 'Unknown',
    };
  }

  String _paymentText(Map<String, dynamic> invoice) {
    final method = invoice['payment_method_snapshot']?.toString();

    switch (method) {
      case 'account':
        final days = invoice['payment_terms_days_snapshot'];
        final number = days is num ? days.toInt() : int.tryParse('$days') ?? 0;
        return '$number day account';
      case 'prepaid':
        return 'Prepaid';
      case 'cod':
        return 'COD';
      default:
        return 'Not recorded';
    }
  }

  String _orderNumber(Map<String, dynamic> invoice) {
    final raw = invoice['orders'];

    if (raw is Map) {
      return raw['order_number']?.toString() ?? '';
    }

    if (raw is List && raw.isNotEmpty && raw.first is Map) {
      return (raw.first as Map)['order_number']?.toString() ?? '';
    }

    return '';
  }

  String _orderSource(Map<String, dynamic> invoice) {
    final raw = invoice['orders'];

    String? source;

    if (raw is Map) {
      source = raw['order_source']?.toString();
    } else if (raw is List && raw.isNotEmpty && raw.first is Map) {
      source = (raw.first as Map)['order_source']?.toString();
    }

    return switch (source) {
      'marketplace' => 'Marketplace',
      'phone' => 'Phone',
      'email' => 'Email',
      'sales_rep' => 'Sales Rep',
      'manual' => 'Manual',
      _ => source ?? '',
    };
  }

  int _countForStatus(String status) {
    if (status == 'all') {
      return _invoices.length;
    }

    return _invoices
        .where((invoice) => invoice['status']?.toString() == status)
        .length;
  }

  List<Map<String, dynamic>> get _filteredInvoices {
    final selectedStatus = _tabs[_tabController.index];
    final query = _searchController.text.trim().toLowerCase();

    return _invoices.where((invoice) {
      if (selectedStatus != 'all' &&
          invoice['status']?.toString() != selectedStatus) {
        return false;
      }

      if (query.isEmpty) {
        return true;
      }

      final searchText =
          [
                invoice['invoice_number'],
                invoice['customer_name_snapshot'],
                invoice['customer_reference_snapshot'],
                _orderNumber(invoice),
                _orderSource(invoice),
              ]
              .whereType<Object>()
              .map((value) => value.toString().toLowerCase())
              .join(' ');

      return searchText.contains(query);
    }).toList();
  }

  Future<void> _openInvoice(Map<String, dynamic> invoice) async {
    final invoiceId = invoice['id']?.toString();

    if (invoiceId == null || invoiceId.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('This invoice could not be identified.')),
      );
      return;
    }

    await Navigator.of(context).push(
      MaterialPageRoute(
        builder: (context) => SupplierInvoicePage(invoiceId: invoiceId),
      ),
    );

    if (mounted) {
      await _loadInvoices();
    }
  }

  bool _isIssuedStatus(String status) {
    return status == 'issued' || status == 'part_paid' || status == 'paid';
  }

  bool _hasButcherAccount(Map<String, dynamic> invoice) {
    return (invoice['butcher_business_id']?.toString().trim() ?? '').isNotEmpty;
  }

  bool _sentToButcher(Map<String, dynamic> invoice) {
    return invoice['sent_to_butcher_at'] != null;
  }

  Future<void> _sendInvoiceFromList(Map<String, dynamic> invoice) async {
    final id = invoice['id']?.toString();
    if (id == null || id.isEmpty || _busyInvoiceIds.contains(id)) {
      return;
    }

    if (!_hasButcherAccount(invoice)) {
      return;
    }

    try {
      setState(() => _busyInvoiceIds.add(id));

      await Supabase.instance.client.rpc(
        'send_invoice_to_butcher',
        params: {'target_invoice_id': id},
      );

      await _loadInvoices();

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Invoice sent to the butcher’s CutLink account.'),
          ),
        );
      }
    } on PostgrestException catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text(error.message)));
      }
    } finally {
      if (mounted) {
        setState(() => _busyInvoiceIds.remove(id));
      }
    }
  }

  Widget _invoiceLifecycleAction(Map<String, dynamic> invoice) {
    final id = invoice['id']?.toString() ?? '';
    final status = invoice['status']?.toString() ?? 'draft';
    final busy = _busyInvoiceIds.contains(id);
    final issued = _isIssuedStatus(status);
    final sent = _sentToButcher(invoice);
    final hasButcher = _hasButcherAccount(invoice);

    if (!issued) {
      return OutlinedButton.icon(
        onPressed: busy ? null : () => _openInvoice(invoice),
        style: OutlinedButton.styleFrom(visualDensity: VisualDensity.compact),
        icon: const Icon(Icons.open_in_new, size: 17),
        label: const Text('Open Invoice'),
      );
    }

    if (hasButcher && !sent) {
      return FilledButton.icon(
        onPressed: busy ? null : () => _sendInvoiceFromList(invoice),
        style: FilledButton.styleFrom(
          backgroundColor: const Color(0xFF315A8C),
          visualDensity: VisualDensity.compact,
        ),
        icon: const Icon(Icons.send_outlined, size: 17),
        label: const Text('Send to Butcher'),
      );
    }

    if (hasButcher && sent) {
      return const Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            Icons.mark_email_read_outlined,
            size: 17,
            color: Color(0xFF2E7D32),
          ),
          SizedBox(width: 5),
          Text(
            'Sent',
            style: TextStyle(
              color: Color(0xFF2E7D32),
              fontWeight: FontWeight.w800,
              fontSize: 11.5,
            ),
          ),
        ],
      );
    }

    return const Text(
      'External Customer',
      style: TextStyle(
        color: Color(0xFF777777),
        fontSize: 11.5,
        fontWeight: FontWeight.w700,
      ),
    );
  }

  Widget _statusChip(String status) {
    Color background;
    Color foreground;

    switch (status) {
      case 'draft':
        background = const Color(0xFFF0F0F0);
        foreground = const Color(0xFF555555);
        break;
      case 'ready':
        background = const Color(0xFFFFF1D8);
        foreground = const Color(0xFF8A5B00);
        break;
      case 'issued':
        background = const Color(0xFFE4EEF9);
        foreground = const Color(0xFF275A89);
        break;
      case 'part_paid':
        background = const Color(0xFFF3E9FA);
        foreground = const Color(0xFF6D378C);
        break;
      case 'paid':
        background = const Color(0xFFE5F4E9);
        foreground = const Color(0xFF25663A);
        break;
      case 'void':
        background = const Color(0xFFFCE8E8);
        foreground = const Color(0xFF8C2A2A);
        break;
      default:
        background = const Color(0xFFF0F0F0);
        foreground = const Color(0xFF555555);
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: background,
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(
        _statusLabel(status),
        style: TextStyle(
          color: foreground,
          fontSize: 10.5,
          fontWeight: FontWeight.w800,
        ),
      ),
    );
  }

  Widget _buildInvoiceCard(Map<String, dynamic> invoice) {
    final status = invoice['status']?.toString() ?? 'draft';
    final taxConfigured = invoice['tax_status']?.toString() == 'configured';
    final total = invoice['total_amount'];
    final orderNumber = _orderNumber(invoice);
    final orderSource = _orderSource(invoice);

    return MouseRegion(
      cursor: SystemMouseCursors.click,
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: () async {
          await _openInvoice(invoice);
        },
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
          decoration: BoxDecoration(
            color: Colors.white,
            border: Border.all(color: const Color(0xFFE3E5E8)),
            borderRadius: BorderRadius.circular(14),
            boxShadow: const [
              BoxShadow(
                color: Color(0x07000000),
                blurRadius: 10,
                offset: Offset(0, 3),
              ),
            ],
          ),
          child: LayoutBuilder(
            builder: (context, constraints) {
              final narrow = constraints.maxWidth < 850;

              final identity = Row(
                children: [
                  Container(
                    width: 38,
                    height: 38,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: const Color(0xFFF5EAEA),
                      borderRadius: BorderRadius.circular(9),
                    ),
                    child: const Icon(
                      Icons.receipt_long_outlined,
                      color: _darkRed,
                      size: 21,
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Flexible(
                              child: Text(
                                invoice['invoice_number']?.toString() ??
                                    'Invoice',
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                  fontSize: 15,
                                  fontWeight: FontWeight.w900,
                                ),
                              ),
                            ),
                            const SizedBox(width: 8),
                            _statusChip(status),
                          ],
                        ),
                        const IosGap(height: 2),
                        Text(
                          invoice['customer_name_snapshot']?.toString() ??
                              'Customer',
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            color: _darkRed,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              );

              final facts = Wrap(
                spacing: 14,
                runSpacing: 6,
                children: [
                  if (orderNumber.isNotEmpty)
                    _MiniInfo(label: 'Order', value: orderNumber),
                  if (orderSource.isNotEmpty)
                    _MiniInfo(label: 'Source', value: orderSource),
                  _MiniInfo(
                    label: 'Invoice date',
                    value: invoice['invoice_date']?.toString() ?? '',
                  ),
                  _MiniInfo(label: 'Payment', value: _paymentText(invoice)),
                  if (!taxConfigured)
                    const _MiniInfo(label: 'GST', value: 'Pending'),
                ],
              );

              final trailing = Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  _invoiceLifecycleAction(invoice),
                  const SizedBox(width: 12),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      const Text(
                        'TOTAL',
                        style: TextStyle(
                          color: Color(0xFF777777),
                          fontSize: 10,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                      const IosGap(height: 2),
                      Text(
                        total == null ? 'Pending' : _money(total),
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(width: 10),
                  const Icon(Icons.chevron_right, color: _darkRed),
                ],
              );

              if (narrow) {
                return Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    identity,
                    const IosGap(height: 8),
                    facts,
                    const IosGap(height: 8),
                    Align(alignment: Alignment.centerRight, child: trailing),
                  ],
                );
              }

              return Row(
                children: [
                  SizedBox(width: 310, child: identity),
                  const SizedBox(width: 14),
                  Expanded(child: facts),
                  const SizedBox(width: 12),
                  trailing,
                ],
              );
            },
          ),
        ),
      ),
    );
  }

  Widget _buildBody() {
    if (_isLoading) {
      return const Center(child: CircularProgressIndicator());
    }

    if (_errorMessage != null) {
      return Center(
        child: IosPadding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.error_outline, size: 60, color: _darkRed),
              const IosGap(height: 16),
              Text(_errorMessage!, textAlign: TextAlign.center),
              const IosGap(height: 18),
              FilledButton(
                onPressed: _loadInvoices,
                child: const Text('Try Again'),
              ),
            ],
          ),
        ),
      );
    }

    final filtered = _filteredInvoices;

    return Center(
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 1320),
        child: Column(
          children: [
            if (!widget.embedded)
              IosPadding(
                padding: const EdgeInsets.fromLTRB(18, 14, 18, 8),
                child: Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: const Color(0xFFE3E5E8)),
                    boxShadow: const [
                      BoxShadow(
                        color: Color(0x07000000),
                        blurRadius: 10,
                        offset: Offset(0, 3),
                      ),
                    ],
                  ),
                  child: const Row(
                    children: [
                      Icon(
                        Icons.receipt_long_outlined,
                        color: _darkRed,
                        size: 22,
                      ),
                      SizedBox(width: 10),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Invoice Management',
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                            IosGap(height: 2),
                            Text(
                              'Create, send and track customer invoices and receivables.',
                              style: TextStyle(
                                color: Color(0xFF666A70),
                                fontSize: 12,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            IosPadding(
              padding: EdgeInsets.fromLTRB(18, widget.embedded ? 14 : 0, 18, 0),
              child: TextField(
                controller: _searchController,
                decoration: InputDecoration(
                  hintText:
                      'Search invoice number, customer, reference or sales order',
                  prefixIcon: const Icon(Icons.search, size: 20),
                  suffixIcon: _searchController.text.isEmpty
                      ? null
                      : IconButton(
                          onPressed: _searchController.clear,
                          icon: const Icon(Icons.close),
                        ),
                  filled: true,
                  fillColor: const Color(0xFFFAFAFB),
                  isDense: true,
                  contentPadding: const EdgeInsets.symmetric(vertical: 12),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide: const BorderSide(color: Color(0xFFE3E5E8)),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide: const BorderSide(color: Color(0xFFE3E5E8)),
                  ),
                ),
              ),
            ),
            const IosGap(height: 10),
            IosPadding(
              padding: const EdgeInsets.symmetric(horizontal: 18),
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: const Color(0xFFE3E5E8)),
                ),
                child: TabBar(
                  controller: _tabController,
                  isScrollable: true,
                  tabAlignment: TabAlignment.start,
                  labelColor: _darkRed,
                  unselectedLabelColor: const Color(0xFF666A70),
                  indicatorColor: _darkRed,
                  indicatorWeight: 3,
                  labelPadding: const EdgeInsets.symmetric(horizontal: 12),
                  labelStyle: const TextStyle(
                    fontSize: 11.5,
                    fontWeight: FontWeight.w800,
                  ),
                  tabs: [
                    Tab(text: 'All (${_countForStatus('all')})'),
                    Tab(text: 'Draft (${_countForStatus('draft')})'),
                    Tab(text: 'Created (${_countForStatus('issued')})'),
                    Tab(text: 'Part Paid (${_countForStatus('part_paid')})'),
                    Tab(text: 'Paid (${_countForStatus('paid')})'),
                    Tab(text: 'Void (${_countForStatus('void')})'),
                  ],
                ),
              ),
            ),
            const IosGap(height: 6),
            Expanded(
              child: filtered.isEmpty
                  ? Center(
                      child: IosPadding(
                        padding: const EdgeInsets.all(24),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(
                              Icons.receipt_long_outlined,
                              size: 42,
                              color: Color(0xFFAAAAAA),
                            ),
                            const IosGap(height: 10),
                            Text(
                              _searchController.text.trim().isEmpty
                                  ? 'No invoices in this section.'
                                  : 'No invoices match your search.',
                              style: const TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                          ],
                        ),
                      ),
                    )
                  : RefreshIndicator(
                      onRefresh: _loadInvoices,
                      child: ListView.separated(
                        physics: const AlwaysScrollableScrollPhysics(),
                        padding: const EdgeInsets.fromLTRB(18, 8, 18, 20),
                        itemCount: filtered.length,
                        separatorBuilder: (_, _) => const IosGap(height: 7),
                        itemBuilder: (context, index) {
                          return _buildInvoiceCard(filtered[index]);
                        },
                      ),
                    ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _workspaceHeader() {
    return Container(
      height: 62,
      padding: const EdgeInsets.symmetric(horizontal: 22),
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(bottom: BorderSide(color: Color(0xFFE3E5E8))),
      ),
      child: Row(
        children: [
          Container(
            width: 34,
            height: 34,
            decoration: BoxDecoration(
              color: const Color(0xFFF5EAEA),
              borderRadius: BorderRadius.circular(9),
            ),
            child: const Icon(
              Icons.request_quote_outlined,
              color: _darkRed,
              size: 19,
            ),
          ),
          const SizedBox(width: 11),
          const Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Invoices',
                  style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900),
                ),
                IosGap(height: 1),
                Text(
                  'Create, send and track customer invoices and receivables',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: Color(0xFF74787E),
                    fontSize: 10.8,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
          IconButton(
            onPressed: _isLoading ? null : _loadInvoices,
            tooltip: 'Refresh invoices',
            icon: const Icon(Icons.refresh_rounded),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (widget.embedded) {
      return ColoredBox(
        color: const Color(0xFFF7F8FA),
        child: Column(
          children: [
            _workspaceHeader(),
            Expanded(child: _buildBody()),
          ],
        ),
      );
    }

    return Scaffold(
      backgroundColor: const Color(0xFFF7F8FA),
      appBar: phoneAppBar(
        context,
        AppBar(
          backgroundColor: Colors.white,
          surfaceTintColor: Colors.white,
          elevation: 0,
          scrolledUnderElevation: 0,
          titleSpacing: 20,
          title: const Row(
            children: [
              Icon(Icons.request_quote_outlined, color: _darkRed, size: 22),
              SizedBox(width: 10),
              Text(
                'Invoices',
                style: TextStyle(fontWeight: FontWeight.w900, fontSize: 19),
              ),
            ],
          ),
          actions: [
            IconButton(
              onPressed: _loadInvoices,
              tooltip: 'Refresh invoices',
              icon: const Icon(Icons.refresh),
            ),
            const SizedBox(width: 10),
          ],
          bottom: const PreferredSize(
            preferredSize: Size.fromHeight(1),
            child: Divider(height: 1, color: Color(0xFFE4E6E8)),
          ),
        ),
      ),
      body: _buildBody(),
    );
  }
}

class _MiniInfo extends StatelessWidget {
  const _MiniInfo({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 145,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: const TextStyle(
              color: Color(0xFF777777),
              fontSize: 11,
              fontWeight: FontWeight.w700,
            ),
          ),
          const IosGap(height: 2),
          Text(
            value,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontWeight: FontWeight.w700),
          ),
        ],
      ),
    );
  }
}
