import '../../../shared/widgets/ios_density.dart';
import '../../../shared/widgets/supplier_photo_policy.dart';
import '../../legal/presentation/legal_info_page.dart';
import '../../../shared/widgets/public_auth_frame.dart';
import '../../../shared/widgets/phone_layout.dart';

import 'package:flutter/material.dart';

import '../../landing/presentation/public_page_palette.dart';

import 'package:supabase_flutter/supabase_flutter.dart';

import 'registration_type_page.dart';
import 'business_details_page.dart';
import 'sign_in_page.dart';

class AccountDetailsPage extends StatefulWidget {
  const AccountDetailsPage({super.key, required this.businessType});

  final BusinessType businessType;

  @override
  State<AccountDetailsPage> createState() => _AccountDetailsPageState();
}

class _AccountDetailsPageState extends State<AccountDetailsPage> {
  final _formKey = GlobalKey<FormState>();

  final _firstNameController = TextEditingController();
  final _lastNameController = TextEditingController();
  final _emailController = TextEditingController();
  final _phoneController = TextEditingController();
  final _passwordController = TextEditingController();
  final _confirmPasswordController = TextEditingController();

  bool _acknowledged = false;
  bool _hidePassword = true;
  bool _hideConfirmPassword = true;
  bool _isLoading = false;

  @override
  void dispose() {
    _firstNameController.dispose();
    _lastNameController.dispose();
    _emailController.dispose();
    _phoneController.dispose();
    _passwordController.dispose();
    _confirmPasswordController.dispose();
    super.dispose();
  }

  String get businessTypeName {
    return widget.businessType == BusinessType.supplier
        ? 'Supplier'
        : 'Butcher';
  }

  Future<void> continueRegistration() async {
    if (_isLoading) {
      return;
    }
    FocusScope.of(context).unfocus();
    if (!_acknowledged) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Read the development notices and confirm your business authority before continuing.',
          ),
        ),
      );
      return;
    }

    if (!_formKey.currentState!.validate()) {
      return;
    }

    setState(() {
      _isLoading = true;
    });

    try {
      final response = await Supabase.instance.client.auth.signUp(
        email: _emailController.text.trim(),
        password: _passwordController.text,
        data: {
          'first_name': _firstNameController.text.trim(),
          'last_name': _lastNameController.text.trim(),
          'phone': _phoneController.text.trim(),
          'business_type': widget.businessType.name,
          'development_notice_version': LegalInfoPage.version,
          'adult_business_authority_acknowledged': true,
          if (widget.businessType == BusinessType.supplier) ...{
            'supplier_photo_terms_accepted': true,
            'supplier_photo_terms_version': SupplierPhotoPolicy.version,
          },
        },
      );

      if (!mounted) {
        return;
      }

      if (response.user == null) {
        throw Exception('The account could not be created.');
      }

      final session = response.session;

      if (session == null) {
        await showDialog<void>(
          context: context,
          builder: (context) {
            return phoneDialog(
              context,
              AlertDialog(
                title: const Text('Check your email'),
                content: Text(
                  'Confirm the email sent to ${_emailController.text.trim()}, '
                  'then return and sign in to finish registration.',
                ),
                actions: [
                  FilledButton(
                    onPressed: () {
                      Navigator.of(context).pop();

                      Navigator.of(context).pushReplacement(
                        MaterialPageRoute(
                          builder: (context) =>
                              SignInPage(businessType: widget.businessType),
                        ),
                      );
                    },
                    child: const Text('Go to sign in'),
                  ),
                ],
              ),
            );
          },
        );

        return;
      }

      Navigator.of(context).push(
        MaterialPageRoute(
          builder: (context) =>
              BusinessDetailsPage(businessType: widget.businessType),
        ),
      );
    } on AuthException catch (error) {
      if (!mounted) {
        return;
      }

      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(error.message)));
    } catch (error) {
      if (!mounted) {
        return;
      }

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Something went wrong while creating the account.'),
        ),
      );
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  String? validateRequired(String? value, String fieldName) {
    if (value == null || value.trim().isEmpty) {
      return 'Please enter your $fieldName.';
    }

    return null;
  }

  String? validateEmail(String? value) {
    final email = value?.trim() ?? '';

    if (email.isEmpty) {
      return 'Please enter your email address.';
    }

    final emailPattern = RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$');

    if (!emailPattern.hasMatch(email)) {
      return 'Please enter a valid email address.';
    }

    return null;
  }

  String? validatePhone(String? value) {
    final phone = value?.replaceAll(RegExp(r'\s+'), '') ?? '';

    if (phone.isEmpty) {
      return 'Please enter your phone number.';
    }

    if (phone.length < 8) {
      return 'Please enter a valid phone number.';
    }

    return null;
  }

  String? validatePassword(String? value) {
    final password = value ?? '';

    if (password.isEmpty) {
      return 'Please enter a password.';
    }

    if (password.length < 8) {
      return 'Password must be at least 8 characters.';
    }

    if (!password.contains(RegExp(r'[A-Z]'))) {
      return 'Include at least one capital letter.';
    }

    if (!password.contains(RegExp(r'[0-9]'))) {
      return 'Include at least one number.';
    }

    return null;
  }

  String? validateConfirmPassword(String? value) {
    if (value == null || value.isEmpty) {
      return 'Please confirm your password.';
    }

    if (value != _passwordController.text) {
      return 'The passwords do not match.';
    }

    return null;
  }

  @override
  Widget build(BuildContext context) {
    const darkRed = Color(0xFF933744);

    return PublicAuthFrame(
      title: 'Create your CutLink login.',
      description:
          'One account for the tools your business needs. Start with your contact and login details.',
      step: 2,
      child: Form(
        key: _formKey,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text(
              'Create your login details',
              style: TextStyle(fontSize: 30, fontWeight: FontWeight.w800),
            ),
            const IosGap(height: 12),
            Text(
              'You are registering as a $businessTypeName business.',
              style: const TextStyle(
                fontSize: 16,
                color: PublicPagePalette.muted,
              ),
            ),
            const IosGap(height: 32),
            LayoutBuilder(
              builder: (context, constraints) {
                final isNarrow = constraints.maxWidth < 550;

                final firstNameField = TextFormField(
                  controller: _firstNameController,
                  textInputAction: TextInputAction.next,
                  decoration: const InputDecoration(labelText: 'First name'),
                  validator: (value) {
                    return validateRequired(value, 'first name');
                  },
                );

                final lastNameField = TextFormField(
                  controller: _lastNameController,
                  textInputAction: TextInputAction.next,
                  decoration: const InputDecoration(labelText: 'Last name'),
                  validator: (value) {
                    return validateRequired(value, 'last name');
                  },
                );

                if (isNarrow) {
                  return Column(
                    children: [
                      firstNameField,
                      const IosGap(height: 18),
                      lastNameField,
                    ],
                  );
                }

                return Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(child: firstNameField),
                    const SizedBox(width: 18),
                    Expanded(child: lastNameField),
                  ],
                );
              },
            ),
            const IosGap(height: 18),
            TextFormField(
              controller: _emailController,
              keyboardType: TextInputType.emailAddress,
              textInputAction: TextInputAction.next,
              autofillHints: const [AutofillHints.email],
              decoration: const InputDecoration(
                labelText: 'Email address',
                hintText: 'name@business.com.au',
              ),
              validator: validateEmail,
            ),
            const IosGap(height: 18),
            TextFormField(
              controller: _phoneController,
              keyboardType: TextInputType.phone,
              textInputAction: TextInputAction.next,
              autofillHints: const [AutofillHints.telephoneNumber],
              decoration: const InputDecoration(
                labelText: 'Phone number',
                hintText: '04XX XXX XXX',
              ),
              validator: validatePhone,
            ),
            const IosGap(height: 18),
            TextFormField(
              controller: _passwordController,
              obscureText: _hidePassword,
              textInputAction: TextInputAction.next,
              autofillHints: const [AutofillHints.newPassword],
              decoration: InputDecoration(
                labelText: 'Password',
                helperText:
                    'At least 8 characters, one capital letter and one number.',

                suffixIcon: IconButton(
                  tooltip: 'Show or hide password',
                  onPressed: () {
                    setState(() {
                      _hidePassword = !_hidePassword;
                    });
                  },
                  icon: Icon(
                    _hidePassword
                        ? Icons.visibility_outlined
                        : Icons.visibility_off_outlined,
                  ),
                ),
              ),
              validator: validatePassword,
            ),
            const IosGap(height: 18),
            TextFormField(
              controller: _confirmPasswordController,
              obscureText: _hideConfirmPassword,
              textInputAction: TextInputAction.done,
              autofillHints: const [AutofillHints.newPassword],
              decoration: InputDecoration(
                labelText: 'Confirm password',

                suffixIcon: IconButton(
                  tooltip: 'Show or hide password',
                  onPressed: () {
                    setState(() {
                      _hideConfirmPassword = !_hideConfirmPassword;
                    });
                  },
                  icon: Icon(
                    _hideConfirmPassword
                        ? Icons.visibility_outlined
                        : Icons.visibility_off_outlined,
                  ),
                ),
              ),
              validator: validateConfirmPassword,
              onFieldSubmitted: (_) {
                continueRegistration();
              },
            ),
            const IosGap(height: 16),
            CheckboxListTile(
              value: _acknowledged,
              onChanged: _isLoading
                  ? null
                  : (value) => setState(() => _acknowledged = value ?? false),
              contentPadding: EdgeInsets.zero,
              controlAffinity: ListTileControlAffinity.leading,
              title: Text(
                widget.businessType == BusinessType.supplier
                    ? 'I am 18 or over, authorised to act for this business, and agree to the development Terms, including the supplier photo terms. I have read the Privacy notice.'
                    : 'I am 18 or over, authorised to act for this business, and have read the development Terms and Privacy notice.',
              ),
            ),
            TextButton(
              onPressed: () => Navigator.of(context).push(
                MaterialPageRoute<void>(builder: (_) => const LegalInfoPage()),
              ),
              child: const Text('Read Terms and Privacy notice'),
            ),
            const IosGap(height: 28),
            FilledButton(
              onPressed: _isLoading ? null : continueRegistration,
              style: FilledButton.styleFrom(
                backgroundColor: darkRed,
                padding: const EdgeInsets.symmetric(vertical: 18),
              ),
              child: _isLoading
                  ? const SizedBox(
                      width: 22,
                      height: 22,
                      child: CircularProgressIndicator(
                        strokeWidth: 2.5,
                        color: Colors.white,
                      ),
                    )
                  : const Text(
                      'Create account',
                      style: TextStyle(
                        fontSize: 17,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
            ),
            const IosGap(height: 12),
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: const Text('Back to business type'),
            ),
          ],
        ),
      ),
    );
  }
}
