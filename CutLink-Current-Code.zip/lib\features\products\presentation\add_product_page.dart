import '../../../shared/widgets/ios_density.dart';
import '../../../shared/widgets/local_draft_recovery.dart';
import '../../../shared/widgets/supplier_specification_field.dart';
import '../../../shared/animal_catalogues/supplier_variant_options.dart';
import '../../../shared/drafts/local_draft_store.dart';
import '../../../shared/widgets/unsaved_changes_guard.dart';
import '../../../shared/widgets/workspace_loading.dart';
import '../../../shared/widgets/workspace_request_error.dart';
import '../../../shared/widgets/cutlink_review_theme.dart';
import '../../../shared/widgets/phone_layout.dart';

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../../shared/animal_catalogues/product_variant.dart';
import '../../../shared/widgets/product_variant_fields.dart';
import '../../../shared/widgets/cutlink_picker.dart';
import '../../../shared/animal_catalogues/animal_catalogue_registry.dart';
import '../../../shared/widgets/interactive_animal_browser.dart';

class AddProductPage extends StatefulWidget {
  const AddProductPage({
    super.key,
    this.initialAnimalCode,
    this.supplierBusinessId,
    this.initialSectionId,
    this.initialSpecificationId,
  });

  final String? initialAnimalCode;
  final String? supplierBusinessId;
  final String? initialSectionId;
  final String? initialSpecificationId;

  @override
  State<AddProductPage> createState() => _AddProductPageState();
}

class _AddProductPageState extends State<AddProductPage> {
  static const _darkRed = Color(0xFF741C1C);

  var _formKey = GlobalKey<FormState>();
  final _draftKey = GlobalKey<LocalDraftRecoveryState>();
  final _draftUser = Supabase.instance.client.auth.currentUser?.id ?? '';
  Map<String, TextEditingController> get _draftControllers => {
    'sku': _sku,
    'productName': _productName,
    'standardPrice': _standardPrice,
    'minimumCartons': _minimumCartons,
    'brand': _brand,
    'description': _description,
    'originCountry': _originCountry,
    'originState': _originState,
    'marbling': _marbling,
    'breed': _breed,
    'trim': _trim,
    'fat': _fat,
    'packaging': _packaging,
    'piecesPerCarton': _piecesPerCarton,
    'supplierNotes': _supplierNotes,
    'chickenSizeWeight': _chickenSizeWeight,
    'chickenCartonSize': _chickenCartonSize,
    'goatWeightMin': _goatWeightMin,
    'goatWeightMax': _goatWeightMax,
    'goatCartonWeight': _goatCartonWeight,
    'commercialDescription': _commercialDescription,
    'lotBatch': _lotBatch,
    'slaughterDate': _slaughterDate,
    'useByDate': _useByDate,
  };
  Map<String, dynamic> _draftValues() => {
    'supplierAttributes': Map<String, String>.from(_supplierAttributes),
    'animalId': _animalId,
    'sectionId': _sectionId,
    'specificationId': _specificationId,
    'gradeId': _gradeId,
    'pieceSizeKind': _pieceSizeKind,
    'pieceSizeUnit': _pieceSizeUnit,
    'temperature': _temperature,
    'availability': _availability,
    'halal': _halal,
    'goatBoneState': _goatBoneState,
    'lambBoneState': _lambBoneState,
    'lambFatClass': _lambFatClass,
    'chickenSkin': _chickenSkin,
    'chickenBone': _chickenBone,
    'chickenProductionType': _chickenProductionType,
    'chickenPreparation': _chickenPreparation,
  };
  final _sku = TextEditingController();
  final Map<String, String> _supplierAttributes = {};
  Map<String, dynamic> get _supplierCutRules {
    for (final cut in _specifications) {
      if (cut['id']?.toString() == _specificationId &&
          cut['supplier_attribute_rules'] is Map) {
        return Map<String, dynamic>.from(
          cut['supplier_attribute_rules'] as Map,
        );
      }
    }
    return const {};
  }

  void _pruneSupplierAttributes() {
    final valid = SupplierVariantOptions.normaliseForCut(
      _selectedAnimalCode,
      _supplierAttributes,
      _supplierCutRules,
    );
    _supplierAttributes
      ..clear()
      ..addAll(valid);
  }

  final _productName = TextEditingController();
  final _standardPrice = TextEditingController();
  final _availableCartons = TextEditingController();
  final _minimumCartons = TextEditingController(text: '1');
  final _brand = TextEditingController();
  final _description = TextEditingController();
  final _originCountry = TextEditingController(text: 'Australia');
  final _originState = TextEditingController();
  final _marbling = TextEditingController();
  final _breed = TextEditingController();
  final _trim = TextEditingController();
  final _fat = TextEditingController();
  final _packaging = TextEditingController();
  final _piecesPerCarton = TextEditingController();
  final _supplierNotes = TextEditingController();
  final _chickenSizeWeight = TextEditingController();
  final _chickenCartonSize = TextEditingController();
  final _goatWeightMin = TextEditingController();
  final _goatWeightMax = TextEditingController();
  final _goatCartonWeight = TextEditingController();
  final _commercialDescription = TextEditingController();
  final _lotBatch = TextEditingController();
  final _slaughterDate = TextEditingController();
  final _useByDate = TextEditingController();

  String? _supplierBusinessId;
  String? _animalId;
  String? _sectionId;
  String? _specificationId;
  String? _gradeId;

  String _pieceSizeKind = 'none';
  String _pieceSizeUnit = 'kg';
  String _temperature = 'chilled';
  String _availability = 'in_stock';
  String _halal = 'not_specified';
  String _goatBoneState = 'bone_in';
  String _lambBoneState = 'not_specified';
  String _lambFatClass = 'not_specified';

  String _chickenSkin = 'not_applicable';
  String _chickenBone = 'not_applicable';
  String _chickenProductionType = 'conventional';
  String _chickenPreparation = 'not_applicable';

  bool _loading = true;
  bool _saving = false;
  bool _hasUnsavedChanges = false;
  String? _initialSelections;
  String? _loadError;
  String get _selectionSnapshot => [
    _supplierAttributes.toString(),
    _animalId,
    _sectionId,
    _specificationId,
    _gradeId,
    _pieceSizeKind,
    _pieceSizeUnit,
    _temperature,
    _availability,
    _halal,
    _goatBoneState,
    _lambBoneState,
    _lambFatClass,
    _chickenSkin,
    _chickenBone,
    _chickenProductionType,
    _chickenPreparation,
  ].join('|');
  bool _loadingSections = false;
  bool _loadingSpecifications = false;
  bool _loadingGrades = false;

  List<Map<String, dynamic>> _animals = [];
  List<Map<String, dynamic>> _sections = [];
  List<Map<String, dynamic>> _specifications = [];
  List<Map<String, dynamic>> _grades = [];

  Future<void> _restoreDraftValues(Map<String, dynamic> data) async {
    final animalId = data['animalId'];
    if (animalId is String && animalId != _animalId) {
      if (!_animals.any((row) => row['id']?.toString() == animalId)) {
        throw StateError('Catalogue selection unavailable');
      }
      await _selectAnimal(animalId);
      if (!mounted) {
        return;
      }
    }
    final sectionId = data['sectionId'];
    if (sectionId is String && sectionId != _sectionId) {
      if (!_sections.any((row) => row['id']?.toString() == sectionId)) {
        throw StateError('Catalogue selection unavailable');
      }
      await _selectSection(sectionId);
      if (!mounted) {
        return;
      }
    }
    final specificationId = data['specificationId'];
    if (specificationId is String && specificationId != _specificationId) {
      if (!_specifications.any(
        (row) => row['id']?.toString() == specificationId,
      )) {
        throw StateError('Catalogue selection unavailable');
      }
      await _selectSpecification(specificationId);
      if (!mounted) {
        return;
      }
    }
    _supplierAttributes
      ..clear()
      ..addAll(
        SupplierVariantOptions.normaliseForCut(
          _selectedAnimalCode,
          data['supplierAttributes'],
          _supplierCutRules,
        ),
      );
    final grade = data['gradeId'];
    if (grade is String &&
        _grades.any((row) => row['id']?.toString() == grade)) {
      _gradeId = grade;
    } else if (grade is String && _usesGradeStage) {
      throw StateError('Catalogue grade unavailable');
    }
    if (!mounted) {
      return;
    }
    setState(() {
      _pieceSizeKind = LocalDraftStore.choice(
        data,
        'pieceSizeKind',
        _pieceSizeKind,
        ['none', 'exact', 'range', 'at_least', 'under', 'up_to'],
      );
      _pieceSizeUnit = LocalDraftStore.choice(
        data,
        'pieceSizeUnit',
        _pieceSizeUnit,
        ['kg', 'g'],
      );
      _temperature = LocalDraftStore.choice(data, 'temperature', _temperature, [
        'fresh',
        'chilled',
        'frozen',
      ]);
      _availability = LocalDraftStore.choice(
        data,
        'availability',
        _availability,
        ['in_stock', 'limited', 'out_of_stock', 'made_to_order'],
      );
      _halal = LocalDraftStore.choice(data, 'halal', _halal, [
        'not_specified',
        'halal',
        'not_halal',
      ]);
      _goatBoneState = LocalDraftStore.choice(
        data,
        'goatBoneState',
        _goatBoneState,
        ['bone_in', 'boneless'],
      );
      _lambBoneState = LocalDraftStore.choice(
        data,
        'lambBoneState',
        _lambBoneState,
        ['not_specified', 'bone_in', 'boneless'],
      );
      _lambFatClass = LocalDraftStore.choice(
        data,
        'lambFatClass',
        _lambFatClass,
        ['not_specified', '1', '2', '3', '4', '5'],
      );
      _chickenSkin = LocalDraftStore.choice(data, 'chickenSkin', _chickenSkin, [
        'not_applicable',
        'skin_on',
        'skin_off',
      ]);
      _chickenBone = LocalDraftStore.choice(data, 'chickenBone', _chickenBone, [
        'not_applicable',
        'bone_in',
        'boneless',
      ]);
      _chickenProductionType = LocalDraftStore.choice(
        data,
        'chickenProductionType',
        _chickenProductionType,
        ['conventional', 'free_range', 'organic', 'other'],
      );
      _chickenPreparation = LocalDraftStore.choice(
        data,
        'chickenPreparation',
        _chickenPreparation,
        [
          'not_applicable',
          'whole',
          'fillet',
          'diced',
          'strips',
          'sliced',
          'minced',
          'butterflied',
          'schnitzel',
          'portion_controlled',
          'other',
        ],
      );
      _hasUnsavedChanges = true;
      _formKey = GlobalKey<FormState>();
    });
  }

  @override
  void initState() {
    super.initState();
    _loadInitial();
  }

  @override
  void dispose() {
    for (final controller in [
      _sku,
      _productName,
      _standardPrice,
      _availableCartons,
      _minimumCartons,
      _brand,
      _description,
      _originCountry,
      _originState,
      _marbling,
      _breed,
      _trim,
      _fat,
      _packaging,
      _piecesPerCarton,
      _supplierNotes,
      _chickenSizeWeight,
      _chickenCartonSize,
      _goatWeightMin,
      _goatWeightMax,
      _goatCartonWeight,
      _commercialDescription,
      _lotBatch,
      _slaughterDate,
      _useByDate,
    ]) {
      controller.dispose();
    }
    super.dispose();
  }

  Future<void> _loadInitial() async {
    setState(() {
      _loading = true;
      _loadError = null;
    });
    try {
      final user = Supabase.instance.client.auth.currentUser;
      if (user == null) {
        throw Exception('No signed-in user was found.');
      }

      var membershipQuery = Supabase.instance.client
          .from('business_memberships')
          .select('business_id, businesses(business_type, verification_status)')
          .eq('user_id', user.id)
          .eq('status', 'active');
      final requestedBusiness = widget.supplierBusinessId;
      if (requestedBusiness != null) {
        membershipQuery = membershipQuery.eq('business_id', requestedBusiness);
      }
      final membership = await membershipQuery.limit(1).single();

      final business = Map<String, dynamic>.from(
        membership['businesses'] as Map,
      );
      if (business['business_type'] != 'supplier') {
        throw Exception('Only supplier accounts can create products.');
      }
      if (business['verification_status'] != 'approved') {
        throw Exception('Your supplier business must be approved first.');
      }

      final animals = await Supabase.instance.client
          .from('meat_animals')
          .select('id, code, name, display_order')
          .eq('is_active', true)
          .inFilter('code', const [
            CutLinkAnimals.beef,
            CutLinkAnimals.veal,
            CutLinkAnimals.lamb,
            CutLinkAnimals.mutton,
            CutLinkAnimals.goat,
            CutLinkAnimals.chicken,
          ])
          .order('display_order');

      if (!mounted) {
        return;
      }
      setState(() {
        _supplierBusinessId = membership['business_id'].toString();
        _animals = List<Map<String, dynamic>>.from(animals);
      });

      final initialAnimalCode = widget.initialAnimalCode?.trim().toUpperCase();

      if (initialAnimalCode != null && initialAnimalCode.isNotEmpty) {
        Map<String, dynamic>? initialAnimal;

        for (final animal in _animals) {
          if (animal['code']?.toString().trim().toUpperCase() ==
              initialAnimalCode) {
            initialAnimal = animal;
            break;
          }
        }

        final initialAnimalId = initialAnimal?['id']?.toString();

        if (initialAnimalId != null && initialAnimalId.isNotEmpty) {
          await _selectAnimal(initialAnimalId);

          if (!mounted) {
            return;
          }

          final requestedSectionId = widget.initialSectionId;

          if (requestedSectionId != null &&
              requestedSectionId.isNotEmpty &&
              _sections.any(
                (section) => section['id']?.toString() == requestedSectionId,
              )) {
            await _selectSection(requestedSectionId);

            if (!mounted) {
              return;
            }

            final requestedSpecificationId = widget.initialSpecificationId;

            if (requestedSpecificationId != null &&
                requestedSpecificationId.isNotEmpty &&
                _specifications.any(
                  (specification) =>
                      specification['id']?.toString() ==
                      requestedSpecificationId,
                )) {
              await _selectSpecification(requestedSpecificationId);
            }
          }
        }
      }
      _initialSelections = _selectionSnapshot;
      if (mounted) {
        setState(() => _loading = false);
      }
    } on PostgrestException catch (e) {
      _finishWithError(e.message);
    } catch (e) {
      _finishWithError(e.toString());
    }
  }

  void _finishWithError(String message) {
    if (!mounted) {
      return;
    }
    setState(() {
      _loading = false;
      _loadError = message;
    });
    _message(message);
  }

  Map<String, dynamic>? get _selectedAnimal {
    if (_animalId == null) {
      return null;
    }
    for (final animal in _animals) {
      if (animal['id']?.toString() == _animalId) {
        return animal;
      }
    }
    return null;
  }

  String? get _selectedAnimalCode =>
      _selectedAnimal?['code']?.toString().trim().toUpperCase();

  dynamic get _animalCatalogue =>
      AnimalCatalogueRegistry.forCode(_selectedAnimalCode);

  bool get _usesGradeStage => _animalCatalogue?.usesGradeStage ?? true;

  String get _gradeStageLabel =>
      _animalCatalogue?.gradeStageLabel ?? 'Grade / Category';

  bool get _isChicken => _selectedAnimalCode == 'CHICKEN';
  bool get _usesGeneralSubcuts =>
      SupplierSpecificationField.usesGeneralSubcuts(_selectedAnimalCode);
  bool get _isGoat => _selectedAnimalCode == 'GOAT';
  bool get _isLamb => _selectedAnimalCode == 'LAMB';

  bool get _isWholeLamb {
    if (!_isLamb || _sectionId == null) {
      return false;
    }
    for (final section in _sections) {
      if (section['id']?.toString() == _sectionId) {
        return section['code']?.toString().toUpperCase() == 'WHOLE_CARCASE';
      }
    }
    return false;
  }

  Future<void> _selectAnimal(String? id) async {
    if (id == null) {
      return;
    }
    final selected = _animals.firstWhere(
      (animal) => animal['id']?.toString() == id,
    );
    final chicken = selected['code']?.toString() == 'CHICKEN';
    final goat = selected['code']?.toString() == 'GOAT';

    setState(() {
      _animalId = id;
      _supplierAttributes.clear();
      _sectionId = null;
      _specificationId = null;
      _gradeId = null;
      _sections = [];
      _specifications = [];
      _grades = [];
      _loadingSections = true;
      _temperature = chicken || goat ? 'fresh' : 'chilled';
      if (goat) {
        _goatBoneState = 'bone_in';
      }
      if (chicken) {
        _chickenSkin = 'not_applicable';
        _chickenBone = 'not_applicable';
        _chickenProductionType = 'conventional';
        _chickenPreparation = 'not_applicable';
      }
    });

    try {
      final rows = await Supabase.instance.client
          .from('meat_sections')
          .select('id, code, name, is_miscellaneous, display_order')
          .eq('animal_id', id)
          .eq('is_active', true)
          .order('display_order');

      if (!mounted) {
        return;
      }

      final loadedSections = List<Map<String, dynamic>>.from(rows);
      String? defaultGoatSectionId;

      if (goat) {
        for (final section in loadedSections) {
          if (section['code']?.toString() == 'WHOLE') {
            defaultGoatSectionId = section['id']?.toString();
            break;
          }
        }
      }

      setState(() {
        _sections = loadedSections;
        _sectionId = defaultGoatSectionId;
        _loadingSections = false;
      });

      if (defaultGoatSectionId != null) {
        await _loadSpecifications();
      }
    } catch (e) {
      if (mounted) {
        setState(() => _loadingSections = false);
      }
      _message('Unable to load sections: $e');
    }
  }

  Future<void> _selectSection(String? id) async {
    if (id == null) {
      return;
    }
    setState(() {
      _sectionId = id;
      _supplierAttributes.clear();
      _specificationId = null;
      _gradeId = null;
      _specifications = [];
      _grades = [];
      _loadingSpecifications = true;
    });
    await _loadSpecifications();
  }

  Future<void> _loadSpecifications({String? selectId}) async {
    final sectionId = _sectionId;
    if (sectionId == null) {
      return;
    }

    try {
      final rows = await Supabase.instance.client
          .from('meat_specifications')
          .select(
            'id, name, ham_code, specification_type, approval_status, supplier_attribute_rules',
          )
          .eq('section_id', sectionId)
          .eq('is_active', true)
          .order('display_order')
          .order('name');

      if (!mounted) {
        return;
      }
      setState(() {
        _specifications = List<Map<String, dynamic>>.from(rows);
        _specificationId = selectId;
        _gradeId = null;
        _grades = [];
        _loadingSpecifications = false;
      });
      if (selectId != null) {
        await _selectSpecification(selectId);
      }
    } catch (e) {
      if (mounted) {
        setState(() => _loadingSpecifications = false);
      }
      _message('Unable to load specifications: $e');
    }
  }

  Future<void> _selectSpecification(String? id) async {
    if (id == null) {
      return;
    }

    final selectedSpecification = _specifications.firstWhere(
      (row) => row['id']?.toString() == id,
    );

    setState(() {
      _specificationId = id;
      _pruneSupplierAttributes();
      _gradeId = null;
      _grades = [];
      _loadingGrades = _usesGradeStage;
      _productName.text = selectedSpecification['name']?.toString() ?? '';
    });

    if (!_usesGradeStage) {
      return;
    }

    try {
      final mappings = await Supabase.instance.client
          .from('meat_specification_grades')
          .select('grade_id, display_order')
          .eq('specification_id', id)
          .eq('is_active', true)
          .order('display_order');

      final ids = List<Map<String, dynamic>>.from(
        mappings,
      ).map((e) => e['grade_id'].toString()).toList();

      if (ids.isEmpty) {
        if (!mounted) {
          return;
        }
        setState(() => _loadingGrades = false);
        return;
      }

      final grades = await Supabase.instance.client
          .from('meat_grades')
          .select('id, code, name, description, display_order')
          .inFilter('id', ids)
          .eq('is_active', true)
          .order('display_order');

      if (!mounted) {
        return;
      }
      final loadedGrades = List<Map<String, dynamic>>.from(grades);
      setState(() {
        _grades = loadedGrades;
        _loadingGrades = false;
      });
    } catch (e) {
      if (mounted) {
        setState(() => _loadingGrades = false);
      }
      _message('Unable to load categories: $e');
    }
  }

  Future<void> _addManualSpecification() async {
    if (_supplierBusinessId == null ||
        _animalId == null ||
        _sectionId == null) {
      _message('Select the animal and section first.');
      return;
    }

    final name = TextEditingController();
    final details = TextEditingController();

    final result = await showDialog<Map<String, String>>(
      context: context,
      builder: (dialogContext) => phoneDialog(
        context,
        AlertDialog(
          title: const Text('Add Supplier-Specific Cut'),
          content: SizedBox(
            width: 520,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: name,
                  autofocus: true,
                  decoration: const InputDecoration(
                    labelText: 'Specification name',
                    hintText: 'Enter the missing trade specification',
                    border: OutlineInputBorder(),
                  ),
                ),
                const IosGap(height: 14),
                TextField(
                  controller: details,
                  minLines: 3,
                  maxLines: 5,
                  decoration: const InputDecoration(
                    labelText: 'Specification details (optional)',
                    hintText:
                        'Trim, preparation, code or other defining details',
                    border: OutlineInputBorder(),
                  ),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: const Text('Cancel'),
            ),
            FilledButton(
              style: FilledButton.styleFrom(backgroundColor: _darkRed),
              onPressed: () {
                if (name.text.trim().isEmpty) {
                  return;
                }
                Navigator.pop(dialogContext, {
                  'name': name.text.trim(),
                  'details': details.text.trim(),
                });
              },
              child: const Text('Add Specification'),
            ),
          ],
        ),
      ),
    );

    name.dispose();
    details.dispose();
    if (result == null) {
      return;
    }

    try {
      setState(() => _loadingSpecifications = true);
      final created = await Supabase.instance.client.rpc(
        'create_supplier_custom_specification',
        params: {
          'p_supplier_business_id': _supplierBusinessId,
          'p_animal_id': _animalId,
          'p_section_id': _sectionId,
          'p_name': result['name'],
          'p_description': null,
          'p_specification_notes': result['details']!.isEmpty
              ? null
              : result['details'],
        },
      );

      final row = Map<String, dynamic>.from(created as Map);
      await _loadSpecifications(selectId: row['id'].toString());
      _message('Supplier-specific cut added.');
    } on PostgrestException catch (e) {
      if (mounted) {
        setState(() => _loadingSpecifications = false);
      }
      _message(e.message);
    }
  }

  String _specLabel(Map<String, dynamic> row) {
    final custom = row['specification_type'] == 'supplier_custom';
    final base = row['name'].toString();
    return custom ? '$base • Custom' : base;
  }

  String _gradeLabel(Map<String, dynamic> row) {
    return '${row['code']} — ${row['name']}';
  }

  String? _required(String? value, String label) {
    if (value == null || value.trim().isEmpty) {
      return '$label is required.';
    }
    return null;
  }

  String? _moneyValidator(String? value) {
    final number = double.tryParse(value?.trim() ?? '');
    if (number == null || number < 0) {
      return 'Enter a valid price.';
    }
    return null;
  }

  String? _optionalPositive(String? value) {
    if (value == null || value.trim().isEmpty) {
      return null;
    }
    final number = double.tryParse(value.trim());
    if (number == null || number < 0) {
      return 'Enter a valid number.';
    }
    return null;
  }

  Future<void> _save() async {
    if (_draftKey.currentState?.awaitingDecision == true) {
      _message(
        'Restore or discard the saved draft before saving this product.',
      );
      return;
    }
    if (_draftKey.currentState?.restoring == true) {
      return;
    }
    if (_saving) {
      return;
    }
    FocusScope.of(context).unfocus();
    if (!_formKey.currentState!.validate()) {
      return;
    }

    if (_animalId == null || _sectionId == null || _specificationId == null) {
      _message('Select animal, main cut and sub-cut.');
      return;
    }

    if (_usesGeneralSubcuts && _supplierCutRules.isEmpty) {
      _message(
        'Specification options are not available. Refresh the catalogue before saving.',
      );
      return;
    }
    _pruneSupplierAttributes();
    if (_usesGradeStage && _gradeId == null) {
      _message('Select $_gradeStageLabel.');
      return;
    }

    if (_supplierBusinessId == null) {
      return;
    }

    final minimum = double.tryParse(_minimumCartons.text.trim());
    if (minimum == null || minimum < 1) {
      _message(
        'Minimum order must be at least 1 ${_isWholeLamb ? 'carcase' : 'carton'}.',
      );
      return;
    }

    final piecesText = _piecesPerCarton.text.trim();
    final pieces = piecesText.isEmpty ? null : int.tryParse(piecesText);
    if (piecesText.isNotEmpty && (pieces == null || pieces <= 0)) {
      _message('Enter a valid pieces per carton value.');
      return;
    }

    final size = ProductPieceSize(
      _pieceSizeKind,
      double.tryParse(_goatWeightMin.text.trim()),
      double.tryParse(_goatWeightMax.text.trim()),
      _pieceSizeUnit,
    );
    if (size.error != null) {
      _message(size.error!);
      return;
    }
    final cartonWeight = double.tryParse(_goatCartonWeight.text.trim());
    if ((_isGoat || _isLamb) &&
        _goatCartonWeight.text.trim().isNotEmpty &&
        (cartonWeight == null || !cartonWeight.isFinite || cartonWeight < 0)) {
      _message('Enter a valid carton weight.');
      return;
    }

    setState(() => _saving = true);

    try {
      if (_isChicken) {
        await Supabase.instance.client.rpc(
          'create_supplier_catalogue_product',
          params: {
            'p_details': {
              ...size.fields,
              'supplier_attributes': _supplierAttributes,
              'p_supplier_business_id': _supplierBusinessId,
              'p_animal_id': _animalId,
              'p_section_id': _sectionId,
              'p_specification_id': _specificationId,
              'p_sku': _sku.text.trim(),
              'p_product_name': _productName.text.trim(),
              'p_standard_price_inc_gst': double.parse(
                _standardPrice.text.trim(),
              ),
              'p_available_cartons': _availableCartons.text.trim().isEmpty
                  ? null
                  : double.parse(_availableCartons.text.trim()),
              'p_minimum_cartons': minimum,
              'p_temperature_state': _temperature,
              'p_availability_status': _availability,
              'p_description': _description.text.trim().isEmpty
                  ? null
                  : _description.text.trim(),
              'p_brand': _brand.text.trim().isEmpty ? null : _brand.text.trim(),
              'p_halal_status': _halal,
              'p_chicken_skin': _chickenSkin,
              'p_chicken_bone': _chickenBone,
              'p_chicken_production_type': _chickenProductionType,
              'p_chicken_preparation': _chickenPreparation,
              'p_chicken_size_weight': _chickenSizeWeight.text.trim().isEmpty
                  ? null
                  : _chickenSizeWeight.text.trim(),
              'p_chicken_carton_size': _chickenCartonSize.text.trim().isEmpty
                  ? null
                  : _chickenCartonSize.text.trim(),
              'p_packaging_type': _packaging.text.trim().isEmpty
                  ? null
                  : _packaging.text.trim(),
              'p_pieces_per_carton': pieces,
              'p_supplier_specification': _supplierNotes.text.trim().isEmpty
                  ? null
                  : _supplierNotes.text.trim(),
            },
          },
        );
      } else {
        await Supabase.instance.client.rpc(
          'create_supplier_catalogue_product',
          params: {
            'p_details': {
              ...size.fields,
              if (_usesGeneralSubcuts)
                'supplier_attributes': _supplierAttributes,
              if (_isGoat || _isLamb) ...{
                'bone_state': _isLamb ? _lambBoneState : _goatBoneState,
                'carton_weight': cartonWeight,
                'carton_weight_unit': cartonWeight == null ? null : 'kg',
              },
              if (_isLamb) ...{
                'fat_class': _lambFatClass == 'not_specified'
                    ? null
                    : int.parse(_lambFatClass),
                'commercial_description':
                    _commercialDescription.text.trim().isEmpty
                    ? null
                    : _commercialDescription.text.trim(),
                'lot_batch': _lotBatch.text.trim().isEmpty
                    ? null
                    : _lotBatch.text.trim(),
                'slaughter_date': _slaughterDate.text.trim().isEmpty
                    ? null
                    : _slaughterDate.text.trim(),
                'use_by_date': _useByDate.text.trim().isEmpty
                    ? null
                    : _useByDate.text.trim(),
              },
              'p_supplier_business_id': _supplierBusinessId,
              'p_animal_id': _animalId,
              'p_section_id': _sectionId,
              'p_specification_id': _specificationId,
              'p_grade_id': _gradeId,
              'p_sku': _sku.text.trim(),
              'p_product_name': _productName.text.trim(),
              'p_standard_price_inc_gst': double.parse(
                _standardPrice.text.trim(),
              ),
              'p_available_cartons': _availableCartons.text.trim().isEmpty
                  ? null
                  : double.parse(_availableCartons.text.trim()),
              'p_minimum_cartons': minimum,
              'p_temperature_state': _temperature,
              'p_availability_status': _availability,
              'p_description': _description.text.trim().isEmpty
                  ? null
                  : _description.text.trim(),
              'p_brand': _brand.text.trim().isEmpty ? null : _brand.text.trim(),
              'p_origin_country': _originCountry.text.trim().isEmpty
                  ? null
                  : _originCountry.text.trim(),
              'p_origin_state': _originState.text.trim().isEmpty
                  ? null
                  : _originState.text.trim(),
              'p_marbling_score': _marbling.text.trim().isEmpty
                  ? null
                  : _marbling.text.trim(),
              'p_breed_program': _breed.text.trim().isEmpty
                  ? null
                  : _breed.text.trim(),
              'p_trim_specification': _trim.text.trim().isEmpty
                  ? null
                  : _trim.text.trim(),
              'p_fat_specification': _fat.text.trim().isEmpty
                  ? null
                  : _fat.text.trim(),
              'p_halal_status': _halal,
              'p_packaging_type': _packaging.text.trim().isEmpty
                  ? null
                  : _packaging.text.trim(),
              'p_pieces_per_carton': pieces,
              'p_supplier_specification': _supplierNotes.text.trim().isEmpty
                  ? null
                  : _supplierNotes.text.trim(),
            },
          },
        );
      }

      if (!mounted) {
        return;
      }
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            _usesGeneralSubcuts
                ? 'Product created.'
                : 'Product and category price created.',
          ),
        ),
      );
      _hasUnsavedChanges = false;
      _initialSelections = _selectionSnapshot;
      try {
        await _draftKey.currentState?.clearDraft();
      } catch (_) {
        _message('Product saved. The local draft backup could not be cleared.');
      }
      if (!mounted) {
        return;
      }
      _saving = false;
      Navigator.pop(context, true);
    } on PostgrestException catch (e) {
      _message(
        e.code == '23505'
            ? 'That SKU already exists for this supplier.'
            : e.message,
      );
    } catch (e) {
      _message('Unable to create product: $e');
    } finally {
      if (mounted) {
        setState(() => _saving = false);
      }
    }
  }

  void _message(String text) {
    if (!mounted) {
      return;
    }
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  Widget _sectionCard({
    required String title,
    required String subtitle,
    required Widget child,
    IconData icon = Icons.inventory_2_outlined,
    bool collapsed = false,
  }) {
    return Container(
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFE3E3DF)),
      ),
      child: collapsed
          ? ExpansionTile(
              tilePadding: EdgeInsets.zero,
              title: Text(
                title,
                style: const TextStyle(fontWeight: FontWeight.w800),
              ),
              subtitle: Text(subtitle),
              children: [const IosGap(height: 14), child],
            )
          : Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      width: 40,
                      height: 40,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        color: const Color(0xFFF4EAEA),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Icon(icon, color: _darkRed, size: 21),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            title,
                            style: const TextStyle(
                              fontSize: 17,
                              fontWeight: FontWeight.w900,
                              color: Color(0xFF2A2A2A),
                            ),
                          ),
                          const IosGap(height: 3),
                          Text(
                            subtitle,
                            style: const TextStyle(
                              color: Color(0xFF6B6B6B),
                              fontSize: 12.5,
                              height: 1.35,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const IosGap(height: 20),
                child,
              ],
            ),
    );
  }

  Future<String?> _showCutLinkPicker({
    required String title,
    required List<Map<String, String>> options,
    String? currentValue,
  }) {
    return showCutLinkPickerDialog<String>(
      context: context,
      title: title,
      currentValue: currentValue,
      options: options
          .map(
            (option) => CutLinkPickerOption<String>(
              value: option['value']!,
              label: option['label'] ?? '',
              subtitle: option['subtitle'],
            ),
          )
          .toList(),
    );
  }

  Widget _cutLinkPickerField({
    required String label,
    required String? value,
    required List<Map<String, String>> options,
    required Future<void> Function(String?) onSelected,
    String hint = 'Select',
    bool enabled = true,
    bool loading = false,
    String? helperText,
    String? Function(String?)? validator,
  }) {
    final selected = options.cast<Map<String, String>?>().firstWhere(
      (option) => option?['value'] == value,
      orElse: () => null,
    );

    return FormField<String>(
      key: ValueKey('$label-$value-${options.length}-$loading'),
      initialValue: value,
      validator: validator,
      builder: (field) {
        final hasValue = selected != null;

        return Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            InkWell(
              borderRadius: BorderRadius.circular(13),
              onTap: !enabled || loading
                  ? null
                  : () async {
                      final picked = await _showCutLinkPicker(
                        title: label,
                        options: options,
                        currentValue: value,
                      );
                      if (picked == null) {
                        return;
                      }
                      field.didChange(picked);
                      await onSelected(picked);
                    },
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 150),
                constraints: const BoxConstraints(minHeight: 58),
                padding: const EdgeInsets.symmetric(
                  horizontal: 14,
                  vertical: 10,
                ),
                decoration: BoxDecoration(
                  color: enabled ? Colors.white : const Color(0xFFF3F3F1),
                  borderRadius: BorderRadius.circular(13),
                  border: Border.all(
                    color: field.hasError
                        ? Colors.red.shade700
                        : hasValue
                        ? const Color(0xFFC9B1B1)
                        : const Color(0xFFD8D8D4),
                    width: hasValue ? 1.2 : 1,
                  ),
                ),
                child: Row(
                  children: [
                    Container(
                      width: 34,
                      height: 34,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        color: hasValue
                            ? const Color(0xFFF4E8E8)
                            : const Color(0xFFF1F1EE),
                        borderRadius: BorderRadius.circular(9),
                      ),
                      child: loading
                          ? const SizedBox(
                              width: 17,
                              height: 17,
                              child: CircularProgressIndicator(strokeWidth: 2),
                            )
                          : Icon(
                              hasValue
                                  ? Icons.check_circle_outline
                                  : Icons.touch_app_outlined,
                              size: 18,
                              color: hasValue
                                  ? _darkRed
                                  : const Color(0xFF777777),
                            ),
                    ),
                    const SizedBox(width: 11),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            label,
                            style: const TextStyle(
                              fontSize: 10.5,
                              color: Color(0xFF777777),
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                          const IosGap(height: 2),
                          Text(
                            hasValue
                                ? selected['label'] ?? hint
                                : loading
                                ? 'Loading...'
                                : hint,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.w800,
                              color: hasValue
                                  ? const Color(0xFF262626)
                                  : const Color(0xFF999999),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 8),
                    const Icon(
                      Icons.keyboard_arrow_down_rounded,
                      color: Color(0xFF666666),
                    ),
                  ],
                ),
              ),
            ),
            if (helperText != null && helperText.trim().isNotEmpty) ...[
              const IosGap(height: 5),
              IosPadding(
                padding: const EdgeInsets.symmetric(horizontal: 4),
                child: Text(
                  helperText,
                  style: const TextStyle(
                    color: Color(0xFF777777),
                    fontSize: 11,
                    height: 1.25,
                  ),
                ),
              ),
            ],
            if (field.hasError) ...[
              const IosGap(height: 5),
              IosPadding(
                padding: const EdgeInsets.symmetric(horizontal: 4),
                child: Text(
                  field.errorText!,
                  style: TextStyle(color: Colors.red.shade700, fontSize: 11),
                ),
              ),
            ],
          ],
        );
      },
    );
  }

  Widget _twoFields(Widget left, Widget right) {
    return LayoutBuilder(
      builder: (context, constraints) {
        if (constraints.maxWidth < 620) {
          return Column(children: [left, const IosGap(height: 14), right]);
        }
        return Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(child: left),
            const SizedBox(width: 14),
            Expanded(child: right),
          ],
        );
      },
    );
  }

  Widget _chickenSpecifications() => _twoFields(
    TextFormField(
      controller: _chickenSizeWeight,
      decoration: const InputDecoration(
        labelText: 'Bird size label (optional)',
        helperText: 'Use Piece size for searchable weight ranges.',
        border: OutlineInputBorder(),
      ),
    ),
    TextFormField(
      controller: _chickenCartonSize,
      decoration: const InputDecoration(
        labelText: 'Pack label (optional)',
        border: OutlineInputBorder(),
      ),
    ),
  );

  Future<void> _pickDate(TextEditingController controller) async {
    final parsed = DateTime.tryParse(controller.text.trim());
    final picked = await showDatePicker(
      context: context,
      initialDate: parsed ?? DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime.now().add(const Duration(days: 3650)),
    );
    if (picked == null) {
      return;
    }
    controller.text = picked.toIso8601String().split('T').first;
  }

  Widget _lambSpecifications() {
    const fatClasses = [
      CutLinkPickerOption(value: 'not_specified', label: 'Not specified'),
      CutLinkPickerOption(value: '1', label: 'Fat Class 1'),
      CutLinkPickerOption(value: '2', label: 'Fat Class 2'),
      CutLinkPickerOption(value: '3', label: 'Fat Class 3'),
      CutLinkPickerOption(value: '4', label: 'Fat Class 4'),
      CutLinkPickerOption(value: '5', label: 'Fat Class 5'),
    ];

    Widget dateField(String label, TextEditingController controller) {
      return TextFormField(
        controller: controller,
        readOnly: true,
        onTap: _saving ? null : () => _pickDate(controller),
        decoration: InputDecoration(
          labelText: '$label (optional)',
          suffixIcon: controller.text.isEmpty
              ? const Icon(Icons.calendar_month_outlined)
              : IconButton(
                  tooltip: 'Clear',
                  onPressed: _saving ? null : () => setState(controller.clear),
                  icon: const Icon(Icons.close),
                ),
          border: const OutlineInputBorder(),
        ),
      );
    }

    return Column(
      children: [
        _twoFields(
          ProductAttributeField(
            controller: _breed,
            label: 'Commercial program',
            choices: productLambPrograms,
            allowCustom: false,
            enabled: !_saving,
          ),
          CutLinkPickerField<String>(
            label: 'Fat Class',
            value: _lambFatClass,
            options: fatClasses,
            enabled: !_saving,
            onChanged: (value) {
              if (value != null) {
                setState(() => _lambFatClass = value);
              }
            },
          ),
        ),
        const IosGap(height: 14),
        _twoFields(
          TextFormField(
            controller: _goatCartonWeight,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: const InputDecoration(
              labelText: 'Carton / Pack Weight (optional)',
              suffixText: 'kg',
              border: OutlineInputBorder(),
            ),
          ),
          TextFormField(
            controller: _originCountry,
            decoration: const InputDecoration(
              labelText: 'Country of Origin',
              border: OutlineInputBorder(),
            ),
          ),
        ),
        if (_isWholeLamb) ...[
          const IosGap(height: 14),
          _twoFields(
            TextFormField(
              controller: _lotBatch,
              decoration: const InputDecoration(
                labelText: 'Lot / Batch (optional)',
                border: OutlineInputBorder(),
              ),
            ),
            dateField('Slaughter Date', _slaughterDate),
          ),
          const IosGap(height: 14),
          Align(
            alignment: Alignment.centerLeft,
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 560),
              child: dateField('Expiry / Use-by', _useByDate),
            ),
          ),
        ],
        const IosGap(height: 10),
        const Align(
          alignment: Alignment.centerLeft,
          child: Text(
            'Fat Class describes fat cover only; it is not a quality ranking.',
            style: TextStyle(color: Color(0xFF6B6B6B), fontSize: 11.5),
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(
        body: WorkspaceLoading(label: 'Loading product form…'),
      );
    }

    if (_loadError != null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Add Product')),
        body: WorkspaceRequestError(
          onRetry: _loadInitial,
          title: 'Could not load the product form',
        ),
      );
    }

    return UnsavedChangesGuard(
      isDirty: () =>
          _hasUnsavedChanges ||
          (_initialSelections != null &&
              _initialSelections != _selectionSnapshot),
      isBusy: () => _saving || _draftKey.currentState?.restoring == true,
      onDiscard: () async {
        await _draftKey.currentState?.clearDraft();
      },
      child: CutLinkReviewTheme(
        child: Scaffold(
          backgroundColor: const Color(0xFFF6F6F3),
          appBar: phoneAppBar(
            context,
            AppBar(
              title: const Text(
                'Add Product',
                style: TextStyle(fontWeight: FontWeight.w900),
              ),
            ),
          ),
          body: LocalDraftRecovery(
            key: _draftKey,
            scope: LocalDraftStore.scope(
              _draftUser,
              _supplierBusinessId ?? '',
              'product',
              'new',
            ),
            controllers: _draftControllers,
            values: _draftValues,
            restoreValues: _restoreDraftValues,
            isBusy: () => _saving,
            isCurrentUser: () =>
                _draftUser.isNotEmpty &&
                Supabase.instance.client.auth.currentUser?.id == _draftUser,
            child: Form(
              key: _formKey,
              onChanged: () {
                if (!_loading && !_saving) {
                  _hasUnsavedChanges = true;
                }
              },
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(18, 18, 18, 34),
                child: Center(
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 1160),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        const Text(
                          'Create Supplier Product',
                          style: TextStyle(
                            fontSize: 26,
                            fontWeight: FontWeight.w900,
                            color: Color(0xFF262626),
                          ),
                        ),
                        const IosGap(height: 4),
                        Text(
                          _isChicken
                              ? 'Chicken uses cut, sub-cut and practical product specifications instead of beef-style grades.'
                              : 'Create an inventory product using the CutLink animal, cut and category structure.',
                          style: const TextStyle(
                            color: Color(0xFF6A6A6A),
                            height: 1.4,
                          ),
                        ),
                        const IosGap(height: 18),
                        _sectionCard(
                          title: 'Product Classification',
                          subtitle: _isChicken
                              ? 'Choose Chicken, the main cut and the sub-cut. Grade is not required for Chicken.'
                              : 'Choose the animal, main cut, specification and category.',
                          icon: Icons.account_tree_outlined,
                          child: Column(
                            children: [
                              _twoFields(
                                _cutLinkPickerField(
                                  label: 'Animal',
                                  value: _animalId,
                                  options: _animals
                                      .map(
                                        (e) => {
                                          'value': e['id'].toString(),
                                          'label': e['name'].toString(),
                                          'subtitle':
                                              'Browse ${e['name']} catalogue',
                                        },
                                      )
                                      .toList(),
                                  onSelected: _selectAnimal,
                                  enabled: !_saving,
                                  hint: 'Choose animal',
                                  validator: (value) => value == null
                                      ? 'Animal is required.'
                                      : null,
                                ),
                                _cutLinkPickerField(
                                  label: _usesGeneralSubcuts
                                      ? 'Main Cut'
                                      : 'Section / Main Cut',
                                  value: _sectionId,
                                  options: _sections
                                      .map(
                                        (e) => {
                                          'value': e['id'].toString(),
                                          'label': e['name'].toString(),
                                          'subtitle':
                                              e['is_miscellaneous'] == true
                                              ? 'Other / miscellaneous'
                                              : 'Main cut',
                                        },
                                      )
                                      .toList(),
                                  onSelected: _selectSection,
                                  enabled:
                                      _animalId != null &&
                                      !_loadingSections &&
                                      !_saving,
                                  loading: _loadingSections,
                                  hint: _animalId == null
                                      ? 'Choose animal first'
                                      : 'Choose main cut',
                                  validator: (value) => value == null
                                      ? 'Main cut is required.'
                                      : null,
                                ),
                              ),
                              const IosGap(height: 14),
                              _cutLinkPickerField(
                                label: _usesGeneralSubcuts
                                    ? 'Sub-cut'
                                    : 'Cut / Specification',
                                value: _specificationId,
                                options: _specifications
                                    .map(
                                      (e) => {
                                        'value': e['id'].toString(),
                                        'label': _specLabel(e),
                                        'subtitle':
                                            e['specification_type'] ==
                                                'supplier_custom'
                                            ? 'Supplier custom specification'
                                            : _usesGeneralSubcuts
                                            ? 'General sub-cut'
                                            : 'CutLink specification',
                                      },
                                    )
                                    .toList(),
                                onSelected: _selectSpecification,
                                enabled:
                                    _sectionId != null &&
                                    !_loadingSpecifications &&
                                    !_saving,
                                loading: _loadingSpecifications,
                                hint: _sectionId == null
                                    ? 'Choose main cut first'
                                    : 'Choose sub-cut',
                                validator: (value) => value == null
                                    ? 'Sub-cut is required.'
                                    : null,
                              ),
                              const IosGap(height: 10),
                              if (!_usesGeneralSubcuts)
                                Align(
                                  alignment: Alignment.centerLeft,
                                  child: OutlinedButton.icon(
                                    onPressed: _sectionId == null || _saving
                                        ? null
                                        : _addManualSpecification,
                                    icon: const Icon(Icons.add),
                                    label: const Text(
                                      'Add Supplier-Specific Cut',
                                    ),
                                  ),
                                ),
                              const IosGap(height: 14),
                              ProductSizeFields(
                                supplierBusinessId: _supplierBusinessId,
                                specificationId: _specificationId,
                                minimum: _goatWeightMin,
                                maximum: _goatWeightMax,
                                kind: _pieceSizeKind,
                                unit: _pieceSizeUnit,
                                enabled: !_saving,
                                onKindChanged: (v) =>
                                    setState(() => _pieceSizeKind = v),
                                onUnitChanged: (v) => setState(() {
                                  if (v != _pieceSizeUnit) {
                                    for (final controller in [
                                      _goatWeightMin,
                                      _goatWeightMax,
                                    ]) {
                                      final number = double.tryParse(
                                        controller.text.trim(),
                                      );
                                      if (number != null) {
                                        controller.text =
                                            ProductPieceSize.number(
                                              v == 'g'
                                                  ? number * 1000
                                                  : number / 1000,
                                            );
                                      }
                                    }
                                    _pieceSizeUnit = v;
                                  }
                                }),
                              ),
                              if (_usesGradeStage) ...[
                                const IosGap(height: 14),
                                _cutLinkPickerField(
                                  label: _gradeStageLabel,
                                  value: _gradeId,
                                  options: _grades
                                      .map(
                                        (e) => {
                                          'value': e['id'].toString(),
                                          'label': _gradeLabel(e),
                                          'subtitle':
                                              e['description']?.toString() ??
                                              '',
                                        },
                                      )
                                      .toList(),
                                  onSelected: (value) async {
                                    setState(() => _gradeId = value);
                                  },
                                  enabled:
                                      _grades.isNotEmpty &&
                                      !_loadingGrades &&
                                      !_saving,
                                  loading: _loadingGrades,
                                  hint: _specificationId == null
                                      ? 'Choose specification first'
                                      : _grades.isEmpty && !_loadingGrades
                                      ? 'No mapped categories'
                                      : 'Choose $_gradeStageLabel',
                                  helperText: _specificationId == null
                                      ? 'Choose a specification first.'
                                      : _grades.isEmpty && !_loadingGrades
                                      ? 'No $_gradeStageLabel options are mapped to this specification yet.'
                                      : 'The supplier price below is specific to this $_gradeStageLabel.',
                                  validator: (value) =>
                                      !_usesGradeStage || value != null
                                      ? null
                                      : '$_gradeStageLabel is required.',
                                ),
                              ],
                            ],
                          ),
                        ),
                        if (_usesGeneralSubcuts) ...[
                          const IosGap(height: 14),
                          _sectionCard(
                            title: 'Supplier specification',
                            subtitle:
                                'Standard options used by suppliers and butcher search.',
                            icon: Icons.tune_outlined,
                            child: Column(
                              children: [
                                SupplierSpecificationField(
                                  cutRules: _supplierCutRules,
                                  values: _supplierAttributes,
                                  onChanged: (field, value) => setState(() {
                                    if (value.isEmpty) {
                                      _supplierAttributes.remove(field);
                                    } else {
                                      _supplierAttributes[field] = value;
                                    }
                                    _pruneSupplierAttributes();
                                  }),
                                  animalCode: _selectedAnimalCode,
                                  enabled: !_saving,
                                ),
                                const IosGap(height: 14),
                                _twoFields(
                                  CutLinkPickerField<String>(
                                    label: 'Temperature',
                                    value: _temperature,
                                    enabled: !_saving,
                                    options: [
                                      const CutLinkPickerOption(
                                        value: 'fresh',
                                        label: 'Fresh',
                                      ),
                                      if (!_isChicken && !_isGoat)
                                        const CutLinkPickerOption(
                                          value: 'chilled',
                                          label: 'Chilled',
                                        ),
                                      const CutLinkPickerOption(
                                        value: 'frozen',
                                        label: 'Frozen',
                                      ),
                                    ],
                                    onChanged: (v) {
                                      if (v != null) {
                                        setState(() => _temperature = v);
                                      }
                                    },
                                  ),
                                  CutLinkPickerField<String>(
                                    label: 'Halal',
                                    value: _halal,
                                    enabled: !_saving,
                                    options: const [
                                      CutLinkPickerOption(
                                        value: 'not_specified',
                                        label: 'Not specified',
                                      ),
                                      CutLinkPickerOption(
                                        value: 'halal',
                                        label: 'Halal',
                                      ),
                                      CutLinkPickerOption(
                                        value: 'not_halal',
                                        label: 'Not halal',
                                      ),
                                    ],
                                    onChanged: (v) {
                                      if (v != null) {
                                        setState(() => _halal = v);
                                      }
                                    },
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                        if (_isChicken) ...[
                          const IosGap(height: 14),
                          _sectionCard(
                            title: 'Optional chicken details',
                            collapsed: true,
                            subtitle:
                                'These describe the actual product variation without creating duplicate sub-categories.',
                            icon: Icons.tune_outlined,
                            child: _chickenSpecifications(),
                          ),
                        ],
                        if (_isLamb) ...[
                          const IosGap(height: 14),
                          _sectionCard(
                            title: _isWholeLamb
                                ? 'Optional carcase details'
                                : 'Optional lamb details',
                            collapsed: true,
                            subtitle: _isWholeLamb
                                ? 'Record only the carcase, program and traceability details supplied for this product.'
                                : 'Add only the commercial details relevant to this Lamb cut.',
                            icon: Icons.fact_check_outlined,
                            child: _lambSpecifications(),
                          ),
                        ],
                        const IosGap(height: 14),
                        _sectionCard(
                          title: 'Product Details',
                          subtitle:
                              'Supplier SKU, product identity, brand and description.',
                          icon: Icons.sell_outlined,
                          child: Column(
                            children: [
                              _twoFields(
                                TextFormField(
                                  controller: _sku,
                                  decoration: const InputDecoration(
                                    labelText: 'Supplier SKU / Product Code',
                                    border: OutlineInputBorder(),
                                  ),
                                  validator: (v) =>
                                      _required(v, 'Supplier SKU'),
                                ),
                                TextFormField(
                                  controller: _productName,
                                  readOnly: true,
                                  decoration: const InputDecoration(
                                    labelText: 'Product Name',
                                    helperText:
                                        'Linked to the selected CutLink sub-cut.',
                                    prefixIcon: Icon(Icons.link_outlined),
                                    border: OutlineInputBorder(),
                                  ),
                                  validator: (v) =>
                                      _required(v, 'Product name'),
                                ),
                              ),
                              const IosGap(height: 14),
                              _twoFields(
                                ProductBrandField(
                                  controller: _brand,
                                  allowCustom: !_usesGeneralSubcuts,
                                  supplierBusinessId: _supplierBusinessId,
                                  animalCode: _selectedAnimalCode,
                                  enabled: !_saving,
                                ),
                                ProductAttributeField(
                                  controller: _packaging,
                                  allowCustom: !_usesGeneralSubcuts,
                                  label: 'Packaging',
                                  choices: productPackagingOptions,
                                ),
                              ),
                              const IosGap(height: 14),
                              TextFormField(
                                controller: _description,
                                minLines: 2,
                                maxLines: 4,
                                decoration: const InputDecoration(
                                  labelText: 'Description (optional)',
                                  border: OutlineInputBorder(),
                                ),
                              ),
                            ],
                          ),
                        ),
                        const IosGap(height: 14),
                        LayoutBuilder(
                          builder: (context, constraints) {
                            final narrow = constraints.maxWidth < 820;

                            final pricing = _sectionCard(
                              title: 'Pricing',
                              subtitle: _isChicken
                                  ? 'Customer-facing Standard Price. Chicken remains ordered by carton and charged by actual kilograms where catch-weight applies.'
                                  : 'Standard category price, GST inclusive.',
                              icon: Icons.payments_outlined,
                              child: TextFormField(
                                controller: _standardPrice,
                                keyboardType:
                                    const TextInputType.numberWithOptions(
                                      decimal: true,
                                    ),
                                decoration: const InputDecoration(
                                  labelText: 'Standard Price inc GST',
                                  prefixText: '\$',
                                  suffixText: '/ kg',
                                  border: OutlineInputBorder(),
                                ),
                                validator: _moneyValidator,
                              ),
                            );

                            final inventory = _sectionCard(
                              title: 'Inventory',
                              subtitle:
                                  'Stock, minimum order and product availability.',
                              icon: Icons.warehouse_outlined,
                              child: Column(
                                children: [
                                  _twoFields(
                                    TextFormField(
                                      controller: _availableCartons,
                                      keyboardType:
                                          const TextInputType.numberWithOptions(
                                            decimal: true,
                                          ),
                                      decoration: InputDecoration(
                                        labelText: 'Current Stock',
                                        suffixText: _isWholeLamb
                                            ? 'carcases'
                                            : 'cartons',
                                        border: OutlineInputBorder(),
                                      ),
                                      validator: _optionalPositive,
                                    ),
                                    TextFormField(
                                      controller: _minimumCartons,
                                      keyboardType: TextInputType.number,
                                      decoration: InputDecoration(
                                        labelText: 'Minimum Order',
                                        suffixText: _isWholeLamb
                                            ? 'carcases'
                                            : 'cartons',
                                        border: OutlineInputBorder(),
                                      ),
                                      validator: _optionalPositive,
                                    ),
                                  ),
                                  const IosGap(height: 14),
                                  _twoFields(
                                    TextFormField(
                                      controller: _piecesPerCarton,
                                      keyboardType: TextInputType.number,
                                      decoration: const InputDecoration(
                                        labelText: 'Units / Pieces per Carton',
                                        border: OutlineInputBorder(),
                                      ),
                                    ),
                                    CutLinkPickerField<String>(
                                      label: 'Availability',
                                      value: _availability,
                                      options: const [
                                        CutLinkPickerOption(
                                          value: 'in_stock',
                                          label: 'In stock',
                                        ),
                                        CutLinkPickerOption(
                                          value: 'limited',
                                          label: 'Limited stock',
                                        ),
                                        CutLinkPickerOption(
                                          value: 'out_of_stock',
                                          label: 'Out of stock',
                                        ),
                                        CutLinkPickerOption(
                                          value: 'made_to_order',
                                          label: 'Made to order',
                                        ),
                                      ],
                                      enabled: !_saving,
                                      onChanged: (value) {
                                        if (value != null) {
                                          setState(() => _availability = value);
                                        }
                                      },
                                    ),
                                  ),
                                ],
                              ),
                            );

                            if (narrow) {
                              return Column(
                                children: [
                                  pricing,
                                  const IosGap(height: 14),
                                  inventory,
                                ],
                              );
                            }

                            return Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Expanded(flex: 4, child: pricing),
                                const SizedBox(width: 14),
                                Expanded(flex: 6, child: inventory),
                              ],
                            );
                          },
                        ),
                        const IosGap(height: 14),

                        const IosGap(height: 14),
                        if (_isGoat)
                          _sectionCard(
                            title: 'Pack weight',
                            subtitle:
                                'Weight of the pack. Piece size is recorded separately.',
                            icon: Icons.inventory_2_outlined,
                            child: TextFormField(
                              controller: _goatCartonWeight,
                              keyboardType:
                                  const TextInputType.numberWithOptions(
                                    decimal: true,
                                  ),
                              decoration: const InputDecoration(
                                labelText: 'Pack weight',
                                suffixText: 'kg',
                                border: OutlineInputBorder(),
                              ),
                            ),
                          ),
                        if (_usesGradeStage)
                          _sectionCard(
                            title: 'Additional Product Details',
                            subtitle:
                                'Secondary red-meat attributes. These do not replace the selected category.',
                            icon: Icons.fact_check_outlined,
                            child: Column(
                              children: [
                                _twoFields(
                                  CutLinkPickerField<String>(
                                    label: 'Storage Condition',
                                    value: _temperature,
                                    options: const [
                                      CutLinkPickerOption(
                                        value: 'fresh',
                                        label: 'Fresh',
                                      ),
                                      CutLinkPickerOption(
                                        value: 'chilled',
                                        label: 'Chilled',
                                      ),
                                      CutLinkPickerOption(
                                        value: 'frozen',
                                        label: 'Frozen',
                                      ),
                                    ],
                                    enabled: !_saving,
                                    onChanged: (value) {
                                      if (value != null) {
                                        setState(() => _temperature = value);
                                      }
                                    },
                                  ),
                                  CutLinkPickerField<String>(
                                    label: 'Halal Status',
                                    value: _halal,
                                    options: const [
                                      CutLinkPickerOption(
                                        value: 'not_specified',
                                        label: 'Not specified',
                                      ),
                                      CutLinkPickerOption(
                                        value: 'halal',
                                        label: 'Halal',
                                      ),
                                      CutLinkPickerOption(
                                        value: 'not_halal',
                                        label: 'Not halal',
                                      ),
                                    ],
                                    enabled: !_saving,
                                    onChanged: (value) {
                                      if (value != null) {
                                        setState(() => _halal = value);
                                      }
                                    },
                                  ),
                                ),
                                const IosGap(height: 14),
                                _twoFields(
                                  ProductAttributeField(
                                    controller: _marbling,
                                    label:
                                        _breed.text.toLowerCase().contains(
                                          'wagyu',
                                        )
                                        ? 'Wagyu marbling / MB score'
                                        : 'Marbling / MB score',
                                    choices: productMarblingScores,
                                    enabled: !_saving,
                                  ),
                                  ProductAttributeField(
                                    controller: _breed,
                                    label: 'Breed / program',
                                    choices: productPrograms,
                                    enabled: !_saving,
                                    onChanged: () => setState(() {}),
                                  ),
                                ),
                                const IosGap(height: 14),
                                _twoFields(
                                  TextFormField(
                                    controller: _trim,
                                    decoration: const InputDecoration(
                                      labelText:
                                          'Trim Specification (optional)',
                                      border: OutlineInputBorder(),
                                    ),
                                  ),
                                  TextFormField(
                                    controller: _fat,
                                    decoration: const InputDecoration(
                                      labelText: 'Fat Specification (optional)',
                                      border: OutlineInputBorder(),
                                    ),
                                  ),
                                ),
                                const IosGap(height: 14),
                                _twoFields(
                                  TextFormField(
                                    controller: _originCountry,
                                    decoration: const InputDecoration(
                                      labelText: 'Country of Origin',
                                      border: OutlineInputBorder(),
                                    ),
                                  ),
                                  TextFormField(
                                    controller: _originState,
                                    decoration: const InputDecoration(
                                      labelText: 'State of Origin (optional)',
                                      border: OutlineInputBorder(),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        if (_usesGradeStage) const IosGap(height: 14),
                        if (!_usesGeneralSubcuts)
                          _sectionCard(
                            title: 'Supplier Notes',
                            subtitle:
                                'Optional internal/trade specification information.',
                            icon: Icons.notes_outlined,
                            child: TextFormField(
                              controller: _supplierNotes,
                              minLines: 3,
                              maxLines: 6,
                              decoration: const InputDecoration(
                                labelText:
                                    'Supplier Specification / Notes (optional)',
                                border: OutlineInputBorder(),
                              ),
                            ),
                          ),
                        const IosGap(height: 18),
                        PhoneRow(
                          mode: PhoneRowMode.wrap,
                          desktop: Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              TextButton(
                                onPressed: _saving
                                    ? null
                                    : () => Navigator.of(context).maybePop(),
                                child: const Text('Cancel'),
                              ),
                              const SizedBox(width: 10),
                              SizedBox(
                                height: 50,
                                child: FilledButton.icon(
                                  style: FilledButton.styleFrom(
                                    backgroundColor: _darkRed,
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 24,
                                    ),
                                  ),
                                  onPressed: _saving ? null : _save,
                                  icon: _saving
                                      ? const SizedBox(
                                          width: 18,
                                          height: 18,
                                          child: CircularProgressIndicator(
                                            strokeWidth: 2,
                                            color: Colors.white,
                                          ),
                                        )
                                      : const Icon(Icons.add_business_outlined),
                                  label: Text(
                                    _saving
                                        ? 'Saving...'
                                        : _isChicken
                                        ? 'Add Chicken Product'
                                        : 'Add Product',
                                    style: const TextStyle(
                                      fontWeight: FontWeight.w900,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
