import '../../../shared/theme/cutlink_appearance.dart';
import '../../../shared/widgets/ios_density.dart';
import '../../delivery/presentation/packing_list_page.dart';
import '../../delivery/presentation/supplier_fulfilment_actions.dart';
import '../../credits/presentation/credit_notes_page.dart';
import '../../../shared/navigation/page_location.dart';
import '../../../shared/widgets/phone_layout.dart';
import '../services/document_product_details.dart';
import '../services/document_product_loader.dart';

import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:printing/printing.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../services/invoice_pdf_service.dart';
import '../services/invoice_commercial_details.dart';
import '../services/invoice_account_balance.dart';
import '../../../shared/widgets/zoomable_pdf_preview.dart';

class SupplierInvoicePage extends StatefulWidget {
  const SupplierInvoicePage({
    super.key,
    this.orderId,
    this.invoiceId,
    this.openPdfOnLoad = false,
    this.initialTabIndex = 0,
  }) : assert(
         (orderId != null && orderId != '') ||
             (invoiceId != null && invoiceId != ''),
         'Either orderId or invoiceId is required.',
       );

  final String? orderId;
  final String? invoiceId;
  final bool openPdfOnLoad;
  final int initialTabIndex;

  @override
  State<SupplierInvoicePage> createState() => _SupplierInvoicePageState();
}

class _SupplierInvoicePageState extends State<SupplierInvoicePage> {
  static const _darkRed = Color(0xFF741C1C);

  bool _isLoading = true;
  bool _isSaving = false;
  String? _errorMessage;

  Map<String, dynamic>? _invoice;
  List<Map<String, dynamic>> _items = [];
  Uint8List? _supplierLogoBytes;
  bool _didAutoOpenPdf = false;
  late int _workspaceTabIndex;

  final _notesController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _workspaceTabIndex = widget.initialTabIndex.clamp(0, 2);
    _loadPage();
  }

  @override
  void dispose() {
    _notesController.dispose();
    super.dispose();
  }

  Future<void> _loadPage() async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    try {
      final client = Supabase.instance.client;

      Map<String, dynamic> invoice;

      final directInvoiceId = widget.invoiceId;

      if (directInvoiceId != null && directInvoiceId.isNotEmpty) {
        invoice = {'id': directInvoiceId};
      } else {
        final orderId = widget.orderId;

        if (orderId == null || orderId.isEmpty) {
          throw Exception('Invoice could not be identified.');
        }

        final existingRows = await client
            .from('invoices')
            .select('id')
            .eq('order_id', orderId)
            .order('created_at', ascending: false)
            .limit(1);

        if (existingRows.isEmpty) {
          throw Exception(
            'No invoice exists for this order yet. Finish the Work Order to create the invoice.',
          );
        }

        invoice = Map<String, dynamic>.from(existingRows.first);
      }

      await client.rpc(
        'snapshot_invoice_party_details',
        params: {'target_invoice_id': invoice['id']},
      );

      final response = await client
          .from('invoices')
          .select('''
            id,
            invoice_number,
            commercial_details_snapshot,
            credited_total,
            refunded_total,
            order_id,
            supplier_business_id,
            butcher_business_id,
            supplier_customer_account_id,
            status,
            customer_name_snapshot,
            customer_contact_name_snapshot,
            customer_reference_snapshot,
            payment_method_snapshot,
            payment_terms_days_snapshot,
            products_subtotal,
            delivery_fee,
            tax_status,
            tax_category_snapshot,
            tax_rate_snapshot,
            tax_amount,
            total_amount,
            invoice_date,
            due_date,
            notes,
            issued_at,
            paid_at,
            voided_at,
            sent_to_butcher_at,
            amount_paid,
            credit_applied,
            outstanding_amount,
            last_payment_at,
            customer_payment_claim_status,
            customer_payment_claimed_at,
            customer_payment_claimed_amount,
            customer_payment_claimed_note,
            payment_claim_reviewed_at,
            payment_claim_review_note,
            supplier_trading_name_snapshot,
            supplier_legal_name_snapshot,
            supplier_logo_path_snapshot,
            supplier_abn_snapshot,
            supplier_licence_number_snapshot,
            supplier_email_snapshot,
            supplier_phone_snapshot,
            supplier_address_line_1_snapshot,
            supplier_address_line_2_snapshot,
            supplier_suburb_snapshot,
            supplier_state_snapshot,
            supplier_postcode_snapshot,
            bank_name_snapshot,
            bank_account_name_snapshot,
            bank_bsb_snapshot,
            bank_account_number_snapshot,
            payment_instructions_snapshot,
            customer_legal_name_snapshot,
            customer_abn_snapshot,
            customer_email_snapshot,
            customer_phone_snapshot,
            customer_billing_address_line_1_snapshot,
            customer_billing_address_line_2_snapshot,
            customer_billing_suburb_snapshot,
            customer_billing_state_snapshot,
            customer_billing_postcode_snapshot,
            created_at,
            updated_at,
            orders(
              id,
              assigned_delivery_driver_id,
              order_number,
              status,
              fulfilment_method,
              ready_for_pickup_at,
              picked_up_at,
              delivery_contact_name_snapshot,
              delivery_contact_phone_snapshot,
              delivery_address_line_1_snapshot,
              delivery_address_line_2_snapshot,
              delivery_suburb_snapshot,
              delivery_state_snapshot,
              delivery_address_postcode_snapshot,
              delivery_postcode_snapshot,
              created_at,
              submitted_at,
              accepted_at,
              dispatched_at,
              delivered_at,
              completed_at,
              warehouse_work_orders(
                created_at,
                printed_at,
                picking_started_at,
                picked_at,
                completed_at
              )
            ),
            invoice_items(
              id,
              order_item_id,
              product_id,
              product_name_snapshot,
              product_details_snapshot,
              sku_snapshot,
              ordered_quantity,
              ordered_quantity_unit,
              supplied_quantity,
              supplied_quantity_unit,
              catch_weight_snapshot,
              actual_weight,
              actual_weight_unit,
              locked_unit_price,
              price_basis,
              gross_line_amount,
              discount_type,
              discount_value,
              discount_amount,
              line_amount,
              notes_snapshot,
              public_comment
            )
          ''')
          .eq('id', invoice['id'])
          .single();

      if (!mounted) {
        return;
      }

      final loaded = Map<String, dynamic>.from(response);
      final rawItems = loaded['invoice_items'];

      final baseItems = rawItems is List
          ? rawItems
                .whereType<Map>()
                .map((item) => Map<String, dynamic>.from(item))
                .toList()
          : <Map<String, dynamic>>[];

      final enrichedItems = await _enrichInvoiceItems(baseItems);

      final privateComments = <String, String>{};
      final lineIds = enrichedItems
          .map((item) => item['id']?.toString())
          .whereType<String>()
          .where((id) => id.isNotEmpty)
          .toList();

      if (lineIds.isNotEmpty) {
        final privateRows = await client
            .from('supplier_document_line_private_notes')
            .select('line_id, private_comment')
            .eq('document_kind', 'invoice')
            .eq('document_id', loaded['id'])
            .inFilter('line_id', lineIds);

        for (final rawNote in privateRows) {
          final lineId = rawNote['line_id']?.toString();
          final comment = rawNote['private_comment']?.toString() ?? '';
          if (lineId != null &&
              lineId.isNotEmpty &&
              comment.trim().isNotEmpty) {
            privateComments[lineId] = comment;
          }
        }
      }

      Uint8List? logoBytes;
      final logoPath =
          loaded['supplier_logo_path_snapshot']?.toString().trim() ?? '';
      if (logoPath.isNotEmpty) {
        try {
          logoBytes = await client.storage
              .from('business-branding')
              .download(logoPath);
        } catch (_) {
          logoBytes = null;
        }
      }

      if (!mounted) {
        return;
      }

      loaded['account_balance_summary'] = await InvoiceAccountBalance.tryLoad(
        loaded['id'].toString(),
      );
      if (!mounted) {
        return;
      }
      _notesController.text = loaded['notes']?.toString() ?? '';

      setState(() {
        _invoice = loaded;
        _items = enrichedItems;
        _supplierLogoBytes = logoBytes;
        _isLoading = false;
      });

      if (widget.openPdfOnLoad && !_didAutoOpenPdf) {
        _didAutoOpenPdf = true;
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (mounted) {
            _printInvoice();
          }
        });
      }
    } on PostgrestException catch (error) {
      if (!mounted) {
        return;
      }

      setState(() {
        _errorMessage = error.message;
        _isLoading = false;
      });
    } catch (error) {
      if (!mounted) {
        return;
      }

      setState(() {
        _errorMessage = error.toString();
        _isLoading = false;
      });
    }
  }

  Future<List<Map<String, dynamic>>> _enrichInvoiceItems(
    List<Map<String, dynamic>> items,
  ) => loadDocumentProductDetails(items);

  double _asDouble(dynamic value) {
    if (value is num) {
      return value.toDouble();
    }

    return double.tryParse('$value') ?? 0;
  }

  String _money(dynamic value) {
    final number = _asDouble(value);
    final fixed = number.toStringAsFixed(2);
    final parts = fixed.split('.');
    final whole = parts.first;
    final decimal = parts.last;

    final buffer = StringBuffer();

    for (var index = 0; index < whole.length; index++) {
      final remaining = whole.length - index;
      buffer.write(whole[index]);

      if (remaining > 1 && remaining % 3 == 1) {
        buffer.write(',');
      }
    }

    return '\$${buffer.toString()}.$decimal';
  }

  String _formatNumber(dynamic value) {
    final number = _asDouble(value);

    if (number == number.roundToDouble()) {
      return number.toInt().toString();
    }

    return number
        .toStringAsFixed(3)
        .replaceFirst(RegExp(r'0+$'), '')
        .replaceFirst(RegExp(r'\.$'), '');
  }

  String _unitLabel(String? value) {
    return switch (value) {
      'carton' => 'cartons',
      'kilogram' => 'kg',
      'unit' => 'units',
      _ => value ?? '',
    };
  }

  String _basisLabel(String? value) {
    return switch (value) {
      'carton' => 'carton',
      'kilogram' => 'kg',
      'unit' => 'unit',
      _ => value ?? '',
    };
  }

  String _statusLabel(String? status) {
    return switch (status) {
      'draft' => 'Draft',
      'ready' => 'Created',
      'issued' => 'Created',
      'part_paid' => 'Part Paid',
      'paid' => 'Paid',
      'void' => 'Void',
      _ => status ?? 'Unknown',
    };
  }

  String _paymentText() {
    final method = _invoice?['payment_method_snapshot']?.toString();

    switch (method) {
      case 'account':
        final days = _invoice?['payment_terms_days_snapshot'];
        return '${_formatNumber(days)} day account';
      case 'prepaid':
        return 'Prepaid';
      case 'cod':
        return 'COD';
      default:
        return 'Not recorded';
    }
  }

  double get _incGstTotal => _asDouble(_invoice?['total_amount']);

  double get _gstIncluded => _asDouble(_invoice?['tax_amount']);

  double get _exGstTotal => _incGstTotal - _gstIncluded;

  double get _amountPaid => _asDouble(_invoice?['amount_paid']);

  double get _amountOutstanding {
    final outstanding = _incGstTotal - _amountPaid;
    return outstanding < 0 ? 0 : outstanding;
  }

  bool get _sentToButcher => _invoice?['sent_to_butcher_at'] != null;

  bool get _hasButcherAccount =>
      (_invoice?['butcher_business_id']?.toString().trim() ?? '').isNotEmpty;

  bool get _canSendToButcher {
    final status = _invoice?['status']?.toString();
    return _hasButcherAccount &&
        !_sentToButcher &&
        (status == 'issued' || status == 'part_paid' || status == 'paid');
  }

  bool get _canRecordPayment {
    final status = _invoice?['status']?.toString();
    return (status == 'issued' || status == 'part_paid') &&
        _amountOutstanding > 0;
  }

  Future<void> _sendInvoiceToButcher() async {
    final invoiceId = _invoice?['id']?.toString();

    if (invoiceId == null || !_canSendToButcher || _isSaving) {
      return;
    }

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => phoneDialog(
        context,
        AlertDialog(
          title: const Text('Send Invoice to Customer?'),
          content: Text(
            'Send ${_invoice?['invoice_number'] ?? 'this invoice'} to '
            '${_invoice?['customer_name_snapshot'] ?? 'the customer'} inside CutLink?\n\n'
            'It will appear in their Accounts section and remain linked to this supplier invoice.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(false),
              child: const Text('Cancel'),
            ),
            FilledButton(
              style: FilledButton.styleFrom(backgroundColor: _darkRed),
              onPressed: () => Navigator.of(dialogContext).pop(true),
              child: const Text('Send Invoice'),
            ),
          ],
        ),
      ),
    );

    if (confirmed != true) {
      return;
    }

    setState(() => _isSaving = true);

    try {
      await Supabase.instance.client.rpc(
        'send_invoice_to_butcher',
        params: {'target_invoice_id': invoiceId},
      );

      if (!mounted) {
        return;
      }

      final updatedInvoice = Map<String, dynamic>.from(_invoice ?? const {});
      updatedInvoice['sent_to_butcher_at'] = DateTime.now()
          .toUtc()
          .toIso8601String();

      setState(() {
        _invoice = updatedInvoice;
      });

      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!mounted) {
          return;
        }

        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Invoice sent to the butcher’s CutLink account.'),
          ),
        );
      });
    } on PostgrestException catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text(error.message)));
      }
    } finally {
      if (mounted) {
        setState(() => _isSaving = false);
      }
    }
  }

  Future<void> _recordPayment() async {
    final invoiceId = _invoice?['id']?.toString();

    if (invoiceId == null || !_canRecordPayment || _isSaving) {
      return;
    }

    final controller = TextEditingController();
    final amount = await showDialog<double>(
      context: context,
      builder: (dialogContext) => phoneDialog(
        context,
        AlertDialog(
          title: const Text('Record Payment'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Outstanding: ${_money(_amountOutstanding)}'),
              const IosGap(height: 14),
              TextField(
                controller: controller,
                autofocus: true,
                keyboardType: const TextInputType.numberWithOptions(
                  decimal: true,
                ),
                decoration: InputDecoration(
                  labelText: 'Payment received',
                  prefixText: r'$',
                  border: OutlineInputBorder(),
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(),
              child: const Text('Cancel'),
            ),
            FilledButton(
              style: FilledButton.styleFrom(backgroundColor: _darkRed),
              onPressed: () {
                final parsed = double.tryParse(
                  controller.text.replaceAll(',', '').trim(),
                );

                if (parsed == null || parsed <= 0) {
                  return;
                }

                Navigator.of(dialogContext).pop(parsed);
              },
              child: const Text('Record Payment'),
            ),
          ],
        ),
      ),
    );
    controller.dispose();

    if (amount == null) {
      return;
    }

    setState(() => _isSaving = true);

    try {
      await Supabase.instance.client.rpc(
        'record_invoice_payment',
        params: {'target_invoice_id': invoiceId, 'payment_amount': amount},
      );

      if (!mounted) {
        return;
      }

      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('Payment recorded.')));

      await _loadPage();
    } on PostgrestException catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text(error.message)));
      }
    } finally {
      if (mounted) {
        setState(() => _isSaving = false);
      }
    }
  }

  bool get _hasPendingCustomerPaymentClaim =>
      _invoice?['customer_payment_claim_status']?.toString() == 'pending';

  Future<void> _reviewCustomerPaymentClaim(bool confirm) async {
    final invoiceId = _invoice?['id']?.toString();

    if (invoiceId == null || !_hasPendingCustomerPaymentClaim || _isSaving) {
      return;
    }

    final noteController = TextEditingController();
    final claimedAmount = _asDouble(
      _invoice?['customer_payment_claimed_amount'],
    );

    final proceed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => phoneDialog(
        context,
        AlertDialog(
          title: Text(confirm ? 'Confirm Payment?' : 'Reject Payment Claim?'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                confirm
                    ? 'The customer says they paid ${_money(claimedAmount)}. Confirm only after checking that the payment has arrived.'
                    : 'Reject this payment claim if the funds have not arrived or the details are incorrect.',
              ),
              const IosGap(height: 14),
              TextField(
                controller: noteController,
                maxLines: 2,
                decoration: InputDecoration(
                  labelText: confirm
                      ? 'Confirmation note (optional)'
                      : 'Reason / note (optional)',
                  border: const OutlineInputBorder(),
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(false),
              child: const Text('Cancel'),
            ),
            FilledButton(
              style: FilledButton.styleFrom(
                backgroundColor: confirm ? const Color(0xFF2E7D32) : _darkRed,
              ),
              onPressed: () => Navigator.of(dialogContext).pop(true),
              child: Text(confirm ? 'Confirm Payment' : 'Reject Claim'),
            ),
          ],
        ),
      ),
    );

    final note = noteController.text.trim();
    noteController.dispose();

    if (proceed != true) {
      return;
    }

    setState(() => _isSaving = true);

    try {
      await Supabase.instance.client.rpc(
        confirm
            ? 'confirm_customer_payment_claim'
            : 'reject_customer_payment_claim',
        params: {'target_invoice_id': invoiceId, 'review_note': note},
      );

      if (!mounted) {
        return;
      }

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            confirm
                ? 'Payment confirmed. The invoice balance has been updated.'
                : 'Payment claim rejected.',
          ),
        ),
      );

      await _loadPage();
    } on PostgrestException catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text(error.message)));
      }
    } finally {
      if (mounted) {
        setState(() => _isSaving = false);
      }
    }
  }

  Future<void> _saveNotes() async {
    final id = _invoice?['id']?.toString();

    if (id == null || _isSaving) {
      return;
    }

    setState(() => _isSaving = true);

    try {
      final updated = await Supabase.instance.client
          .from('invoices')
          .update({
            'notes': _notesController.text.trim().isEmpty
                ? null
                : _notesController.text.trim(),
          })
          .eq('id', id)
          .select()
          .single();

      if (!mounted) {
        return;
      }

      setState(() {
        _invoice = {...?_invoice, ...Map<String, dynamic>.from(updated)};
      });

      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('Invoice notes saved.')));
    } on PostgrestException catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text(error.message)));
      }
    } finally {
      if (mounted) {
        setState(() => _isSaving = false);
      }
    }
  }

  Future<Uint8List> _buildInvoicePdf() async {
    final invoice = _invoice;
    if (invoice == null) {
      throw Exception('Invoice is not loaded.');
    }

    return CutLinkInvoicePdf.build(
      invoice: invoice,
      accountBalance: await InvoiceAccountBalance.load(
        invoice['id'].toString(),
      ),
      items: _items,
      supplierLogoBytes: _supplierLogoBytes,
    );
  }

  Future<void> _printInvoice() async {
    if (_invoice == null || _isSaving) {
      return;
    }

    try {
      await Printing.layoutPdf(
        name: '${_invoice?['invoice_number'] ?? 'CutLink-Invoice'}.pdf',
        onLayout: (_) => _buildInvoicePdf(),
      );
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Could not create invoice PDF: $error')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    AppearanceScope.watch(context);
    PageLocation.track(context, {
      'page': 'invoice',
      'id': widget.invoiceId,
      'order': widget.orderId,
    });
    return Scaffold(
      backgroundColor: CutLinkPalette.color(0xFFF7F8FA),
      appBar: phoneAppBar(
        context,
        AppBar(
          backgroundColor: CutLinkPalette.surface,
          surfaceTintColor: Colors.white,
          elevation: 0,
          scrolledUnderElevation: 0,
          titleSpacing: 20,
          title: Row(
            children: [
              const Icon(
                Icons.receipt_long_outlined,
                color: _darkRed,
                size: 22,
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  _invoice?['invoice_number']?.toString() ?? 'Supplier Invoice',
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontWeight: FontWeight.w900,
                    fontSize: 18,
                  ),
                ),
              ),
            ],
          ),
          actions: [
            if (_invoice?['orders'] is Map &&
                (_invoice!['orders'] as Map)['fulfilment_method'] ==
                    'delivery' &&
                [
                  'dispatched',
                  'delivered',
                  'completed',
                ].contains((_invoice!['orders'] as Map)['status']))
              OutlinedButton.icon(
                onPressed: () => Navigator.of(context).push(
                  MaterialPageRoute<void>(
                    builder: (_) => PackingListPage(
                      orderId: _invoice!['order_id'].toString(),
                    ),
                  ),
                ),
                icon: const Icon(Icons.inventory_2_outlined, size: 17),
                label: const Text('Packing list PDF'),
              ),
            FilledButton.icon(
              icon: const Icon(Icons.assignment_return_outlined, size: 18),
              label: const Text('Credit'),
              onPressed: _invoice == null
                  ? null
                  : () async {
                      await Navigator.of(context).push(
                        MaterialPageRoute<void>(
                          builder: (_) => CreditNoteEditor(
                            invoiceId: _invoice!['id'].toString(),
                          ),
                        ),
                      );
                      if (mounted) {
                        await _loadPage();
                      }
                    },
            ),
            TextButton(
              onPressed: _invoice == null
                  ? null
                  : () async {
                      await Navigator.of(context).push(
                        MaterialPageRoute<void>(
                          builder: (_) => CreditNotesPage(
                            supplierView: true,
                            invoiceId: _invoice!['id'].toString(),
                          ),
                        ),
                      );
                      if (mounted) {
                        await _loadPage();
                      }
                    },
              child: const Text('Credit notes'),
            ),

            OutlinedButton.icon(
              onPressed: _isLoading || _isSaving ? null : _downloadInvoice,
              icon: const Icon(Icons.download_outlined, size: 17),
              label: const Text('Download'),
            ),
            const SizedBox(width: 7),
            FilledButton.icon(
              onPressed: _isLoading || _isSaving ? null : _printInvoice,
              style: FilledButton.styleFrom(backgroundColor: _darkRed),
              icon: const Icon(Icons.print_outlined, size: 17),
              label: const Text('Print'),
            ),
            const SizedBox(width: 7),
            IconButton(
              onPressed: _isLoading ? null : _loadPage,
              tooltip: 'Refresh',
              icon: const Icon(Icons.refresh),
            ),
            const SizedBox(width: 10),
          ],
          bottom: PreferredSize(
            preferredSize: const Size.fromHeight(49),
            child: _workspaceTabs(),
          ),
        ),
      ),
      body: switch (_workspaceTabIndex) {
        0 => _buildBody(),
        1 => _buildPreviewTab(),
        _ => _buildHistoryTab(),
      },
    );
  }

  Widget _workspaceTabs() {
    return Container(
      height: 49,
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 6),
      decoration: BoxDecoration(
        color: CutLinkPalette.surface,
        border: Border(
          top: BorderSide(color: CutLinkPalette.color(0xFFF0F1F2)),
        ),
      ),
      child: PhoneRow(
        mode: PhoneRowMode.scroll,
        desktop: Row(
          children: [
            _workspaceTab(0, Icons.receipt_long_outlined, 'Invoice'),
            _workspaceTab(1, Icons.picture_as_pdf_outlined, 'Preview'),
            _workspaceTab(2, Icons.history, 'Order History'),
          ],
        ),
      ),
    );
  }

  Widget _workspaceTab(int index, IconData icon, String label) {
    final selected = _workspaceTabIndex == index;
    return IosPadding(
      padding: const EdgeInsets.only(right: 6),
      child: TextButton.icon(
        onPressed: () => setState(() => _workspaceTabIndex = index),
        style: TextButton.styleFrom(
          foregroundColor: selected
              ? Colors.white
              : CutLinkPalette.color(0xFF5E6369),
          backgroundColor: selected
              ? _darkRed
              : CutLinkPalette.color(0xFFF4F5F6),
          padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 9),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(9),
            side: BorderSide(
              color: selected ? _darkRed : CutLinkPalette.color(0xFFE1E3E6),
            ),
          ),
        ),
        icon: Icon(icon, size: 16),
        label: Text(
          label,
          style: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.w800),
        ),
      ),
    );
  }

  Widget _buildPreviewTab() {
    final invoiceNumber =
        _invoice?['invoice_number']?.toString() ?? 'CutLink-Invoice';

    return Column(
      children: [
        Container(
          color: CutLinkPalette.surface,
          padding: const EdgeInsets.all(12),
          child: PhoneRow(
            mode: PhoneRowMode.wrap,
            desktop: Row(
              children: [
                const Expanded(
                  child: Text(
                    'Invoice PDF',
                    style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900),
                  ),
                ),
                Text(
                  'Scroll wheel to zoom',
                  style: TextStyle(
                    color: CutLinkPalette.color(0xFF6D7177),
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(width: 12),
                OutlinedButton.icon(
                  onPressed: _downloadInvoice,
                  icon: const Icon(Icons.download_outlined, size: 17),
                  label: const Text('Download'),
                ),
              ],
            ),
          ),
        ),
        Expanded(
          child: ZoomablePdfPreview(
            documentKey:
                'invoice-${_invoice?['id'] ?? widget.invoiceId ?? widget.orderId}-$invoiceNumber-${_invoice?['status']}-${_invoice?['outstanding_amount']}',
            buildPdf: _buildInvoicePdf,
            dpi: 420,
          ),
        ),
      ],
    );
  }

  Future<void> _downloadInvoice() async {
    try {
      await Printing.sharePdf(
        bytes: await _buildInvoicePdf(),
        filename: '${_invoice?['invoice_number'] ?? 'CutLink-Invoice'}.pdf',
      );
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Could not download invoice: $error')),
        );
      }
    }
  }

  Widget _buildHistoryTab() {
    if (_isLoading) {
      return const Center(child: CircularProgressIndicator());
    }
    if (_errorMessage != null || _invoice == null) {
      return _buildBody();
    }
    final order = _nestedMap(_invoice?['orders']);
    final workOrder = _nestedMap(order?['warehouse_work_orders']);
    final events = <({String title, dynamic value, IconData icon})>[
      (
        title: 'Order created',
        value: order?['created_at'],
        icon: Icons.add_circle_outline,
      ),
      (
        title: 'Order submitted',
        value: order?['submitted_at'],
        icon: Icons.send_outlined,
      ),
      (
        title: 'Order accepted',
        value: order?['accepted_at'],
        icon: Icons.check_circle_outline,
      ),
      (
        title: 'Work order created',
        value: workOrder?['created_at'],
        icon: Icons.assignment_outlined,
      ),
      (
        title: 'Picking slip printed',
        value: workOrder?['printed_at'],
        icon: Icons.print_outlined,
      ),
      (
        title: 'Picking started',
        value: workOrder?['picking_started_at'],
        icon: Icons.play_circle_outline,
      ),
      (
        title: 'Picking completed',
        value: workOrder?['picked_at'],
        icon: Icons.inventory_2_outlined,
      ),
      (
        title: 'Invoice created',
        value: _invoice?['created_at'],
        icon: Icons.receipt_long_outlined,
      ),
      (
        title: 'Invoice created',
        value: _invoice?['issued_at'],
        icon: Icons.verified_outlined,
      ),
      (
        title: 'Invoice sent',
        value: _invoice?['sent_to_butcher_at'],
        icon: Icons.email_outlined,
      ),
      (
        title: 'Invoice paid',
        value: _invoice?['paid_at'],
        icon: Icons.payments_outlined,
      ),
      (
        title: 'Invoice voided',
        value: _invoice?['voided_at'],
        icon: Icons.block_outlined,
      ),
      (
        title: 'Order dispatched',
        value: order?['dispatched_at'],
        icon: Icons.local_shipping_outlined,
      ),
      (
        title: 'Order delivered',
        value: order?['delivered_at'],
        icon: Icons.inventory_outlined,
      ),
      (
        title: 'Order completed',
        value: order?['completed_at'],
        icon: Icons.task_alt,
      ),
    ].where((event) => event.value != null).toList();

    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            color: CutLinkPalette.surface,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: CutLinkPalette.color(0xFFE3E5E8)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Order History',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900),
              ),
              const IosGap(height: 3),
              Text(
                'Recorded order, warehouse and invoice milestones.',
                style: TextStyle(
                  color: CutLinkPalette.color(0xFF73777D),
                  fontSize: 12,
                ),
              ),
              const IosGap(height: 18),
              if (events.isEmpty)
                const Text('No recorded milestones yet.')
              else
                for (var index = 0; index < events.length; index++)
                  _historyEvent(
                    events[index],
                    last: index == events.length - 1,
                  ),
            ],
          ),
        ),
      ],
    );
  }

  Map<String, dynamic>? _nestedMap(dynamic raw) {
    if (raw is Map) {
      return Map<String, dynamic>.from(raw);
    }
    if (raw is List && raw.isNotEmpty && raw.first is Map) {
      return Map<String, dynamic>.from(raw.first as Map);
    }
    return null;
  }

  Widget _historyEvent(
    ({String title, dynamic value, IconData icon}) event, {
    required bool last,
  }) {
    final parsed = DateTime.tryParse(event.value.toString())?.toLocal();
    final date = parsed == null
        ? event.value.toString()
        : '${parsed.day.toString().padLeft(2, '0')}/${parsed.month.toString().padLeft(2, '0')}/${parsed.year}  ${parsed.hour.toString().padLeft(2, '0')}:${parsed.minute.toString().padLeft(2, '0')}';
    return IntrinsicHeight(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Column(
            children: [
              Container(
                width: 30,
                height: 30,
                decoration: BoxDecoration(
                  color: CutLinkPalette.color(0xFFF5EAEA),
                  shape: BoxShape.circle,
                ),
                child: Icon(event.icon, size: 16, color: _darkRed),
              ),
              if (!last)
                Expanded(
                  child: Container(
                    width: 1,
                    color: CutLinkPalette.color(0xFFE0E2E5),
                  ),
                ),
            ],
          ),
          const SizedBox(width: 12),
          Expanded(
            child: IosPadding(
              padding: const EdgeInsets.only(bottom: 18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    event.title,
                    style: const TextStyle(fontWeight: FontWeight.w900),
                  ),
                  const IosGap(height: 2),
                  Text(
                    date,
                    style: TextStyle(
                      color: CutLinkPalette.color(0xFF71767C),
                      fontSize: 11.5,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBody() {
    if (_isLoading) {
      return const Center(child: CircularProgressIndicator());
    }

    if (_errorMessage != null) {
      return Center(
        child: IosPadding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.error_outline, size: 60, color: _darkRed),
              const IosGap(height: 16),
              Text(_errorMessage!, textAlign: TextAlign.center),
              const IosGap(height: 18),
              FilledButton(
                onPressed: _loadPage,
                child: const Text('Try Again'),
              ),
            ],
          ),
        ),
      );
    }

    final status = _invoice?['status']?.toString();

    String clean(dynamic value, {String fallback = '—'}) {
      final text = value?.toString().trim() ?? '';
      return text.isEmpty ? fallback : text;
    }

    String address({
      required dynamic line1,
      dynamic line2,
      dynamic suburb,
      dynamic state,
      dynamic postcode,
    }) {
      return [
        clean(line1, fallback: ''),
        clean(line2, fallback: ''),
        [
          clean(suburb, fallback: ''),
          clean(state, fallback: ''),
          clean(postcode, fallback: ''),
        ].where((part) => part.isNotEmpty).join(' '),
      ].where((part) => part.isNotEmpty).join(', ');
    }

    Widget sectionTitle(String title, {IconData? icon}) {
      return IosPadding(
        padding: const EdgeInsets.only(bottom: 8),
        child: PhoneRow(
          mode: PhoneRowMode.wrap,
          desktop: Row(
            children: [
              if (icon != null) ...[
                Icon(icon, size: 18, color: _darkRed),
                const SizedBox(width: 7),
              ],
              Text(
                title,
                style: const TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ],
          ),
        ),
      );
    }

    Widget fact(String label, String value) {
      return IosPadding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
              width: 118,
              child: Text(
                label,
                style: TextStyle(
                  color: CutLinkPalette.color(0xFF777777),
                  fontSize: 10.5,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ),
            Expanded(
              child: Text(
                value,
                style: const TextStyle(
                  fontSize: 11.5,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          ],
        ),
      );
    }

    final customerAddress = address(
      line1: _invoice?['customer_billing_address_line_1_snapshot'],
      line2: _invoice?['customer_billing_address_line_2_snapshot'],
      suburb: _invoice?['customer_billing_suburb_snapshot'],
      state: _invoice?['customer_billing_state_snapshot'],
      postcode: _invoice?['customer_billing_postcode_snapshot'],
    );

    Widget customerSummaryPanel() {
      return Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: CutLinkPalette.surface,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: CutLinkPalette.color(0xFFE3E5E8)),
          boxShadow: const [
            BoxShadow(
              color: Color(0x07000000),
              blurRadius: 10,
              offset: Offset(0, 3),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            sectionTitle('Customer', icon: Icons.business_outlined),
            fact('Business', clean(_invoice?['customer_name_snapshot'])),
            if (clean(
              _invoice?['customer_contact_name_snapshot'],
              fallback: '',
            ).isNotEmpty)
              fact(
                'Contact',
                clean(_invoice?['customer_contact_name_snapshot']),
              ),
            if (clean(
              _invoice?['customer_abn_snapshot'],
              fallback: '',
            ).isNotEmpty)
              fact('ABN', clean(_invoice?['customer_abn_snapshot'])),
            if (clean(
              _invoice?['customer_email_snapshot'],
              fallback: '',
            ).isNotEmpty)
              fact('Email', clean(_invoice?['customer_email_snapshot'])),
            if (clean(
              _invoice?['customer_phone_snapshot'],
              fallback: '',
            ).isNotEmpty)
              fact('Phone', clean(_invoice?['customer_phone_snapshot'])),
            if (customerAddress.isNotEmpty) fact('Billing', customerAddress),
          ],
        ),
      );
    }

    Widget invoiceSummaryPanel() {
      return Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: CutLinkPalette.surface,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: CutLinkPalette.color(0xFFE3E5E8)),
          boxShadow: const [
            BoxShadow(
              color: Color(0x07000000),
              blurRadius: 10,
              offset: Offset(0, 3),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            sectionTitle('Invoice Summary', icon: Icons.receipt_long_outlined),
            fact('Tax Invoice No.', clean(_invoice?['invoice_number'])),
            for (final entry in invoiceCommercialReferences(_invoice!).entries)
              fact(entry.key, entry.value),
            if (invoiceSupplySummary(_items).isNotEmpty)
              fact('Supply totals', invoiceSupplySummary(_items)),
            fact('Invoice date', clean(_invoice?['invoice_date'])),
            fact('Due date', clean(_invoice?['due_date'])),
            fact('Payment', _paymentText()),
          ],
        ),
      );
    }

    Widget itemsPanel() {
      return Container(
        decoration: BoxDecoration(
          color: CutLinkPalette.surface,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: CutLinkPalette.color(0xFFE3E5E8)),
          boxShadow: const [
            BoxShadow(
              color: Color(0x07000000),
              blurRadius: 10,
              offset: Offset(0, 3),
            ),
          ],
        ),
        child: Column(
          children: [
            IosPadding(
              padding: const EdgeInsets.fromLTRB(14, 11, 14, 9),
              child: PhoneRow(
                mode: PhoneRowMode.wrap,
                desktop: Row(
                  children: [
                    const Icon(
                      Icons.inventory_2_outlined,
                      size: 19,
                      color: _darkRed,
                    ),
                    const SizedBox(width: 8),
                    const Text(
                      'Invoice Items',
                      style: TextStyle(
                        fontSize: 17,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    Text(
                      '${_items.length} line${_items.length == 1 ? '' : 's'}',
                      style: TextStyle(
                        color: CutLinkPalette.color(0xFF777777),
                        fontSize: 11.5,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const Divider(height: 1),
            PhoneExpanded(
              child: _items.isEmpty
                  ? Center(
                      child: Text(
                        'No invoice items.',
                        style: TextStyle(
                          color: CutLinkPalette.color(0xFF777777),
                        ),
                      ),
                    )
                  : ListView.builder(
                      shrinkWrap: isPhoneLayout(context),
                      physics: isPhoneLayout(context)
                          ? const NeverScrollableScrollPhysics()
                          : null,
                      padding: const EdgeInsets.all(10),
                      itemCount: _items.length,
                      itemBuilder: (context, index) {
                        return _buildItemCard(_items[index]);
                      },
                    ),
            ),
          ],
        ),
      );
    }

    Widget totalsActionsPanel() {
      final totalDiscount = _items.fold<double>(
        0,
        (sum, item) => sum + _asDouble(item['discount_amount']),
      );
      final productsBeforeDiscount =
          _asDouble(_invoice?['products_subtotal']) + totalDiscount;

      return Container(
        decoration: BoxDecoration(
          color: CutLinkPalette.surface,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: CutLinkPalette.color(0xFFE3E5E8)),
          boxShadow: const [
            BoxShadow(
              color: Color(0x07000000),
              blurRadius: 10,
              offset: Offset(0, 3),
            ),
          ],
        ),
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              if ([
                    'issued',
                    'part_paid',
                    'paid',
                  ].contains(_invoice?['status']) &&
                  _invoice?['orders'] is Map &&
                  _invoice?['order_id'] != null)
                SupplierFulfilmentActions(
                  orderId: _invoice!['order_id'].toString(),
                  supplierId: _invoice!['supplier_business_id'].toString(),
                  order: Map<String, dynamic>.from(_invoice!['orders'] as Map),
                  onChanged: _loadPage,
                ),
              sectionTitle('Totals', icon: Icons.calculate_outlined),
              _TotalRow(
                label: totalDiscount > 0
                    ? 'Products before discount'
                    : 'Products inc GST',
                value: _money(
                  totalDiscount > 0
                      ? productsBeforeDiscount
                      : _invoice?['products_subtotal'],
                ),
              ),
              if (totalDiscount > 0)
                _TotalRow(
                  label: 'Discount',
                  value: '-${_money(totalDiscount)}',
                ),
              _TotalRow(
                label: 'Delivery inc GST',
                value: _asDouble(_invoice?['delivery_fee']) == 0
                    ? 'Free'
                    : _money(_invoice?['delivery_fee']),
              ),
              _TotalRow(label: 'GST included', value: _money(_gstIncluded)),
              _TotalRow(label: 'Total ex GST', value: _money(_exGstTotal)),
              const Divider(height: 16),
              _TotalRow(
                label: 'Total inc GST',
                value: _money(_incGstTotal),
                bold: true,
              ),
              _TotalRow(label: 'Amount paid', value: _money(_amountPaid)),
              _TotalRow(
                label: 'Outstanding',
                value: _money(_amountOutstanding),
                bold: true,
              ),
              InvoiceAccountBalancePanel(
                balance:
                    _invoice?['account_balance_summary']
                        as Map<String, dynamic>?,
              ),

              if (_hasPendingCustomerPaymentClaim) ...[
                const IosGap(height: 12),
                Container(
                  padding: const EdgeInsets.all(11),
                  decoration: BoxDecoration(
                    color: CutLinkPalette.color(0xFFFFF8E6),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: const Color(0xFFE0C26C)),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Customer marked this invoice as paid',
                        style: TextStyle(
                          color: Color(0xFF9A6700),
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                      const IosGap(height: 5),
                      Text(
                        'Claimed ${_money(_asDouble(_invoice?['customer_payment_claimed_amount']))}',
                        style: const TextStyle(fontWeight: FontWeight.w800),
                      ),
                      if (clean(
                        _invoice?['customer_payment_claimed_note'],
                        fallback: '',
                      ).isNotEmpty) ...[
                        const IosGap(height: 4),
                        Text(
                          clean(_invoice?['customer_payment_claimed_note']),
                          style: const TextStyle(fontSize: 11.5),
                        ),
                      ],
                      const IosGap(height: 8),
                      Row(
                        children: [
                          Expanded(
                            child: FilledButton(
                              onPressed: _isSaving
                                  ? null
                                  : () => _reviewCustomerPaymentClaim(true),
                              style: FilledButton.styleFrom(
                                backgroundColor: const Color(0xFF2E7D32),
                              ),
                              child: const Text('Confirm'),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: OutlinedButton(
                              onPressed: _isSaving
                                  ? null
                                  : () => _reviewCustomerPaymentClaim(false),
                              child: const Text('Reject'),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],

              const IosGap(height: 10),
              FilledButton.icon(
                onPressed: _canSendToButcher && !_isSaving
                    ? _sendInvoiceToButcher
                    : null,
                style: FilledButton.styleFrom(
                  backgroundColor: _darkRed,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 13),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
                icon: Icon(
                  _sentToButcher
                      ? Icons.mark_email_read_outlined
                      : Icons.send_outlined,
                ),
                label: Text(
                  !_hasButcherAccount
                      ? 'External Customer'
                      : _sentToButcher
                      ? 'Sent to Butcher'
                      : 'Send to Butcher',
                ),
              ),
              const IosGap(height: 7),
              OutlinedButton.icon(
                onPressed: _canRecordPayment && !_isSaving
                    ? _recordPayment
                    : null,
                icon: const Icon(Icons.payments_outlined),
                label: Text(
                  _amountOutstanding <= 0 ? 'Paid in Full' : 'Record Payment',
                ),
              ),

              if (clean(
                    _invoice?['bank_name_snapshot'],
                    fallback: '',
                  ).isNotEmpty ||
                  clean(
                    _invoice?['bank_account_name_snapshot'],
                    fallback: '',
                  ).isNotEmpty ||
                  clean(
                    _invoice?['bank_bsb_snapshot'],
                    fallback: '',
                  ).isNotEmpty ||
                  clean(
                    _invoice?['bank_account_number_snapshot'],
                    fallback: '',
                  ).isNotEmpty ||
                  clean(
                    _invoice?['payment_instructions_snapshot'],
                    fallback: '',
                  ).isNotEmpty) ...[
                const IosGap(height: 10),
                const Divider(height: 1),
                const IosGap(height: 10),
                sectionTitle(
                  'Payment Details',
                  icon: Icons.account_balance_outlined,
                ),
                if (clean(
                  _invoice?['bank_name_snapshot'],
                  fallback: '',
                ).isNotEmpty)
                  fact('Bank', clean(_invoice?['bank_name_snapshot'])),
                if (clean(
                  _invoice?['bank_account_name_snapshot'],
                  fallback: '',
                ).isNotEmpty)
                  fact(
                    'Account name',
                    clean(_invoice?['bank_account_name_snapshot']),
                  ),
                if (clean(
                  _invoice?['bank_bsb_snapshot'],
                  fallback: '',
                ).isNotEmpty)
                  fact('BSB', clean(_invoice?['bank_bsb_snapshot'])),
                if (clean(
                  _invoice?['bank_account_number_snapshot'],
                  fallback: '',
                ).isNotEmpty)
                  fact(
                    'Account no.',
                    clean(_invoice?['bank_account_number_snapshot']),
                  ),
                if (clean(
                  _invoice?['payment_instructions_snapshot'],
                  fallback: '',
                ).isNotEmpty)
                  fact(
                    'Instructions',
                    clean(_invoice?['payment_instructions_snapshot']),
                  ),
              ],

              const IosGap(height: 10),
              const Divider(height: 1),
              const IosGap(height: 10),
              sectionTitle('Invoice Notes', icon: Icons.notes_outlined),
              for (final entry in invoiceCommercialNotices(_invoice!).entries)
                fact(entry.key, entry.value),
              TextField(
                controller: _notesController,
                minLines: 2,
                maxLines: 4,
                enabled: status != 'void' && !_isSaving,
                decoration: InputDecoration(
                  hintText: 'Invoice notes',
                  border: OutlineInputBorder(),
                  isDense: true,
                ),
              ),
              const IosGap(height: 7),
              OutlinedButton.icon(
                onPressed: status != 'void' && !_isSaving ? _saveNotes : null,
                icon: const Icon(Icons.save_outlined),
                label: const Text('Save Notes'),
              ),
              const IosGap(height: 8),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(
                  horizontal: 12,
                  vertical: 11,
                ),
                decoration: BoxDecoration(
                  color: CutLinkPalette.color(0xFFF0F6F1),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: CutLinkPalette.color(0xFFCFE2D2)),
                ),
                child: const Row(
                  children: [
                    Icon(
                      Icons.verified_outlined,
                      size: 18,
                      color: Color(0xFF2E7D32),
                    ),
                    SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        'Invoices are issued automatically when created from the Work Order.',
                        style: TextStyle(
                          fontSize: 11.5,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      );
    }

    final header = Container(
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 15),
      decoration: BoxDecoration(
        color: CutLinkPalette.surface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: CutLinkPalette.color(0xFFE3E5E8)),
      ),
      child: Row(
        children: [
          Container(
            width: 38,
            height: 38,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: CutLinkPalette.color(0xFFF5EAEA),
              borderRadius: BorderRadius.circular(9),
            ),
            child: const Icon(
              Icons.receipt_long_outlined,
              color: _darkRed,
              size: 20,
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  _invoice?['invoice_number']?.toString() ?? 'Invoice',
                  style: const TextStyle(
                    fontSize: 17,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const IosGap(height: 2),
                Text(
                  clean(_invoice?['customer_name_snapshot']),
                  style: const TextStyle(
                    color: _darkRed,
                    fontSize: 12,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ],
            ),
          ),
          Chip(
            visualDensity: VisualDensity.compact,
            label: Text(_statusLabel(status)),
          ),
          if (creditNumber(_invoice?['credited_total']) > 0)
            Chip(
              label: Text(
                'Credited ${creditMoney(_invoice?['credited_total'])}',
              ),
            ),
          if (creditNumber(_invoice?['refunded_total']) > 0)
            Chip(
              label: Text(
                '${creditNumber(_invoice?['refunded_total']) >= creditNumber(_invoice?['total_amount']) ? 'Refunded' : 'Partially refunded'} ${creditMoney(_invoice?['refunded_total'])}',
              ),
            ),
          const SizedBox(width: 6),
          const Chip(
            visualDensity: VisualDensity.compact,
            label: Text('GST inclusive'),
          ),
          if (_sentToButcher) ...[
            const SizedBox(width: 6),
            const Chip(
              visualDensity: VisualDensity.compact,
              avatar: Icon(Icons.mark_email_read_outlined, size: 16),
              label: Text('Sent'),
            ),
          ],
        ],
      ),
    );

    return LayoutBuilder(
      builder: (context, constraints) {
        final desktop = constraints.maxWidth >= 920;

        if (!desktop) {
          return ListView(
            padding: const EdgeInsets.all(14),
            children: [
              header,
              const IosGap(height: 14),
              customerSummaryPanel(),
              const IosGap(height: 10),
              invoiceSummaryPanel(),
              const IosGap(height: 10),
              SizedBox(
                height: isPhoneLayout(context) ? null : 460,
                child: itemsPanel(),
              ),
              const IosGap(height: 10),
              totalsActionsPanel(),
            ],
          );
        }

        return IosPadding(
          padding: const EdgeInsets.all(14),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Expanded(
                child: Column(
                  children: [
                    header,
                    const IosGap(height: 10),
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(child: customerSummaryPanel()),
                        const SizedBox(width: 12),
                        Expanded(child: invoiceSummaryPanel()),
                      ],
                    ),
                    const IosGap(height: 10),
                    Expanded(child: itemsPanel()),
                  ],
                ),
              ),
              const SizedBox(width: 12),
              SizedBox(
                width: constraints.maxWidth >= 1400 ? 390 : 340,
                child: totalsActionsPanel(),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildItemCard(Map<String, dynamic> item) {
    final catchWeight = item['catch_weight_snapshot'] == true;

    final gradeCode = item['grade_code']?.toString().trim() ?? '';
    final gradeName = item['grade_name']?.toString().trim() ?? '';
    final specification = item['specification_name']?.toString().trim() ?? '';
    final hamCode = item['ham_code']?.toString().trim() ?? '';
    final section = item['section_name']?.toString().trim() ?? '';
    final animal = item['animal_name']?.toString().trim() ?? '';

    final gradeLabel = [
      gradeCode,
      if (gradeName.isNotEmpty && gradeName != gradeCode) gradeName,
    ].where((value) => value.isNotEmpty).join(' — ');

    final specificationLabel = [
      specification,
      if (hamCode.isNotEmpty) 'HAM $hamCode',
    ].where((value) => value.isNotEmpty).join(' • ');

    Widget pill(String value) {
      return Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
        decoration: BoxDecoration(
          color: CutLinkPalette.color(0xFFF5F1F1),
          borderRadius: BorderRadius.circular(999),
          border: Border.all(color: CutLinkPalette.color(0xFFE1D3D3)),
        ),
        child: Text(
          value,
          style: const TextStyle(
            color: _darkRed,
            fontSize: 10.5,
            fontWeight: FontWeight.w800,
          ),
        ),
      );
    }

    Widget metric(String label, String value) {
      return SizedBox(
        width: 112,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              label,
              style: TextStyle(
                color: CutLinkPalette.color(0xFF777777),
                fontSize: 9.5,
                fontWeight: FontWeight.w900,
              ),
            ),
            const IosGap(height: 2),
            Text(
              value,
              style: const TextStyle(
                fontSize: 11.5,
                fontWeight: FontWeight.w800,
              ),
            ),
          ],
        ),
      );
    }

    final ordered =
        '${_formatNumber(item['ordered_quantity'])} '
        '${_unitLabel(item['ordered_quantity_unit']?.toString())}';
    final supplied =
        '${_formatNumber(item['supplied_quantity'])} '
        '${_unitLabel(item['supplied_quantity_unit']?.toString())}';
    final rate =
        '${_money(item['locked_unit_price'])}'
        '${_basisLabel(item['price_basis']?.toString()).isEmpty ? '' : ' / ${_basisLabel(item['price_basis']?.toString())}'}';

    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 11),
      decoration: BoxDecoration(
        color: CutLinkPalette.color(0xFFFBFBF9),
        borderRadius: BorderRadius.circular(11),
        border: Border.all(color: CutLinkPalette.color(0xFFE2E2DE)),
      ),
      child: LayoutBuilder(
        builder: (context, constraints) {
          final narrow = constraints.maxWidth < 720;

          final identity = Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                gradeLabel.isEmpty
                    ? (item['product_name_snapshot']?.toString() ?? 'Product')
                    : '${item['product_name_snapshot']?.toString() ?? 'Product'} - $gradeLabel',
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  fontSize: 14.5,
                  fontWeight: FontWeight.w900,
                ),
              ),
              if (documentProductSpecifications(item).isNotEmpty)
                Text(
                  documentProductSpecifications(item),
                  style: TextStyle(
                    fontSize: 11,
                    color: CutLinkPalette.color(0xFF646A70),
                  ),
                ),
              if ((item['sku_snapshot']?.toString().trim() ?? '')
                  .isNotEmpty) ...[
                const IosGap(height: 2),
                Text(
                  'SKU ${item['sku_snapshot']}',
                  style: TextStyle(
                    color: CutLinkPalette.color(0xFF777777),
                    fontSize: 10.5,
                  ),
                ),
              ],
              if (gradeLabel.isNotEmpty ||
                  specificationLabel.isNotEmpty ||
                  section.isNotEmpty ||
                  animal.isNotEmpty) ...[
                const IosGap(height: 7),
                Wrap(
                  spacing: 5,
                  runSpacing: 5,
                  children: [
                    if (specificationLabel.isNotEmpty) pill(specificationLabel),
                    if (section.isNotEmpty) pill(section),
                    if (animal.isNotEmpty) pill(animal),
                  ],
                ),
              ],
              if (_asDouble(item['discount_amount']) > 0) ...[
                const IosGap(height: 7),
                Text(
                  'Discount: ${_money(item['discount_amount'])}',
                  style: const TextStyle(
                    color: _darkRed,
                    fontSize: 10.5,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ],
              if ((item['public_comment']?.toString().trim() ?? '')
                  .isNotEmpty) ...[
                const IosGap(height: 5),
                Text(
                  'Public: ${item['public_comment']}',
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 10.5),
                ),
              ],
            ],
          );

          final metrics = Wrap(
            spacing: 12,
            runSpacing: 8,
            children: [
              metric('ORDERED', ordered),
              metric('SUPPLIED', supplied),
              if (catchWeight)
                metric(
                  'ACTUAL WEIGHT',
                  '${_formatNumber(item['actual_weight'])} kg',
                ),
              metric('LOCKED RATE', rate),
            ],
          );

          final amount = Column(
            crossAxisAlignment: narrow
                ? CrossAxisAlignment.start
                : CrossAxisAlignment.end,
            children: [
              Text(
                'LINE TOTAL INC GST',
                style: TextStyle(
                  color: CutLinkPalette.color(0xFF777777),
                  fontSize: 9.5,
                  fontWeight: FontWeight.w900,
                ),
              ),
              const IosGap(height: 3),
              Text(
                _money(item['line_amount']),
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ],
          );

          if (narrow) {
            return Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                identity,
                const IosGap(height: 10),
                metrics,
                const IosGap(height: 10),
                amount,
              ],
            );
          }

          return Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(flex: 5, child: identity),
              const SizedBox(width: 14),
              Expanded(flex: 5, child: metrics),
              const SizedBox(width: 12),
              amount,
            ],
          );
        },
      ),
    );
  }
}

class _TotalRow extends StatelessWidget {
  const _TotalRow({
    required this.label,
    required this.value,
    this.bold = false,
  });

  final String label;
  final String value;
  final bool bold;

  @override
  Widget build(BuildContext context) {
    AppearanceScope.watch(context);
    final style = TextStyle(
      fontWeight: bold ? FontWeight.w800 : FontWeight.w500,
      fontSize: bold ? 17 : 14,
    );

    return IosPadding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: PhoneRow(
        mode: PhoneRowMode.wrap,
        desktop: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(label, style: style),
            const SizedBox(width: 20),
            Text(value, style: style),
          ],
        ),
      ),
    );
  }
}
