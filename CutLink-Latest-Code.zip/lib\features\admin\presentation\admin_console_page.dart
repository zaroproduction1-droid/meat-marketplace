import '../../../shared/widgets/ios_density.dart';
import '../../../shared/widgets/workspace_loading.dart';
import 'admin_notification_settings_page.dart';
import 'admin_product_notifications_bell.dart';
import 'admin_billing_panel.dart';
import '../services/admin_billing_labels.dart';
import '../../../shared/widgets/cutlink_logo.dart';
import 'admin_analytics_panel.dart';
import 'admin_featured_businesses_panel.dart';
import 'admin_theme.dart';
import '../../../shared/navigation/page_location.dart';

import 'dart:async';

import 'package:flutter/material.dart';

import '../../../shared/widgets/cutlink_workspace_theme.dart';
import '../../../shared/widgets/phone_layout.dart';
import '../../../shared/widgets/workspace_back_button.dart';
import '../../support/presentation/support_center_page.dart';
import '../services/platform_admin_service.dart';
import 'admin_widgets.dart';
import 'admin_business_page.dart';
import 'admin_announcement_page.dart';

class AdminConsolePage extends StatefulWidget {
  const AdminConsolePage({super.key, this.initialTab = 'overview'});
  final String initialTab;
  @override
  State<AdminConsolePage> createState() => _AdminConsolePageState();
}

class _AdminConsolePageState extends State<AdminConsolePage> {
  String _tab = 'overview', _search = '';
  String _billingView = 'accounts';
  String? _filter;
  bool _loading = true;
  String? _error;
  int _page = 0, _request = 0;
  Timer? _debounce;
  AdminRow _data = {};
  List<AdminRow> _rows = [];
  static const _tabs = {
    'overview': 'Overview',
    'analytics': 'Analytics',
    'homepage': 'Front page',
    'businesses': 'Businesses',
    'billing': 'Billing',
    'announcements': 'Announcements',
    'audit': 'Audit history',
    'preferences': 'Settings',
    'support': 'Support inbox',
  };
  @override
  void initState() {
    super.initState();
    final billing = adminBillingSection(widget.initialTab);
    _billingView = billing ?? 'accounts';
    _tab = billing != null
        ? 'billing'
        : _tabs.containsKey(widget.initialTab)
        ? widget.initialTab
        : 'overview';
    _load();
  }

  @override
  void dispose() {
    _debounce?.cancel();
    super.dispose();
  }

  Future<void> _load() async {
    final request = ++_request;
    setState(() {
      _loading = true;
      _error = null;
    });
    if (_tab == 'analytics' ||
        _tab == 'homepage' ||
        _tab == 'billing' ||
        _tab == 'preferences') {
      setState(() => _loading = false);
      return;
    }
    try {
      final value = await PlatformAdminService.query(
        _tab,
        search: _search,
        filter: _filter,
        offset: _page * 50,
      );
      if (mounted && request == _request) {
        setState(() {
          _data = PlatformAdminService.map(value);
          _rows = PlatformAdminService.rows(value);
          _loading = false;
        });
      }
    } catch (e) {
      if (mounted && request == _request) {
        setState(() {
          _error = PlatformAdminService.error(e);
          _loading = false;
        });
      }
    }
  }

  void _change(String tab, {String? filter}) {
    if (tab == 'support') {
      Navigator.push(
        context,
        MaterialPageRoute<void>(
          builder: (_) =>
              const SupportCenterPage(businessId: '', adminMode: true),
        ),
      );
      return;
    }
    _debounce?.cancel();
    setState(() {
      final billing = adminBillingSection(tab);
      _billingView = billing ?? _billingView;
      _tab = billing != null ? 'billing' : tab;
      _page = 0;
      _search = '';
      _filter = filter;
    });
    _load();
  }

  Future<void> _business(String id) async {
    await Navigator.push(
      context,
      MaterialPageRoute<void>(
        builder: (_) =>
            AdminBusinessPage(businessId: id, initialTab: 'business'),
      ),
    );
    if (mounted) {
      await _load();
    }
  }

  Future<void> _announcement() async {
    await Navigator.push(
      context,
      MaterialPageRoute<bool>(builder: (_) => const AdminAnnouncementPage()),
    );
    if (mounted) {
      await _load();
    }
  }

  Future<void> _archive(AdminRow row) async {
    final saved = await adminForm(
      context,
      title: 'Archive announcement',
      explanation:
          'The banner will be removed. Notifications already delivered remain in their inboxes.',
      fields: const [AdminField('reason', 'Reason', required: true)],
      submitLabel: 'Archive',
      submit: (d) async {
        await PlatformAdminService.action('archive_announcement', {
          ...d,
          'id': row['id'],
        });
      },
    );
    if (saved && mounted) {
      await _load();
    }
  }

  Widget _metric(
    String label,
    String value,
    IconData icon, {
    VoidCallback? onTap,
  }) => AdminStatTile(label: label, value: value, icon: icon, onTap: onTap);
  Widget _overview() => Column(
    crossAxisAlignment: CrossAxisAlignment.stretch,
    children: [
      const CutLinkSectionHeading(
        title: 'CutLink control centre',
        subtitle:
            'Business access, platform billing and customer communications.',
        icon: Icons.admin_panel_settings_outlined,
      ),
      const IosGap(height: 20),
      AdminTileGrid(
        children: [
          _metric(
            'Businesses',
            '${_data['businesses'] ?? 0}',
            Icons.business_outlined,
            onTap: () => _change('businesses'),
          ),
          _metric(
            'Awaiting approval',
            '${_data['pending'] ?? 0}',
            Icons.how_to_reg_outlined,
            onTap: () => _change('businesses', filter: 'pending'),
          ),
          _metric(
            'Unpaid CutLink invoices',
            PlatformAdminService.money(_data['outstanding']),
            Icons.account_balance_wallet_outlined,
            onTap: () => _change('accounts', filter: 'unpaid'),
          ),
          _metric(
            'Overdue payments',
            PlatformAdminService.money(_data['overdue']),
            Icons.schedule_outlined,
            onTap: () => _change('invoices', filter: 'overdue'),
          ),
          _metric(
            'Payments received',
            PlatformAdminService.money(_data['paid']),
            Icons.payments_outlined,
            onTap: () => _change('invoices'),
          ),
          _metric(
            'Ready to invoice',
            '${_data['due_accounts'] ?? 0}',
            Icons.receipt_long_outlined,
            onTap: () => _change('accounts', filter: 'needs_invoice'),
          ),
        ],
      ),
      const IosGap(height: 20),
      AdminCard(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '${_data['suppliers'] ?? 0} suppliers · ${_data['butchers'] ?? 0} butchers',
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
            ),
            const IosGap(height: 10),
            const Text(
              'Use Billing for CutLink memberships, invoices and received payments.',
            ),
            const IosGap(height: 16),
            Wrap(
              spacing: 10,
              runSpacing: 8,
              children: [
                FilledButton.icon(
                  onPressed: () => _change('businesses'),
                  icon: const Icon(Icons.business),
                  label: const Text('Manage businesses'),
                ),
                OutlinedButton.icon(
                  onPressed: () => _change('settings'),
                  icon: const Icon(Icons.settings_outlined),
                  label: const Text('Invoice details'),
                ),
                OutlinedButton.icon(
                  onPressed: _announcement,
                  icon: const Icon(Icons.campaign_outlined),
                  label: const Text('New announcement'),
                ),
              ],
            ),
          ],
        ),
      ),
    ],
  );
  Widget _row(AdminRow row) {
    if (_tab == 'businesses') {
      return AdminCard(
        child: ListTile(
          contentPadding: EdgeInsets.zero,
          title: Text(
            PlatformAdminService.name(row),
            style: const TextStyle(fontWeight: FontWeight.w800),
          ),
          subtitle: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('${row['business_type']} · ${row['business_email'] ?? ''}'),
              const IosGap(height: 8),
              AdminStatus('${row['verification_status']}'),
            ],
          ),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => _business('${row['id']}'),
        ),
      );
    }
    if (_tab == 'announcements') {
      final expired =
          DateTime.tryParse('${row['expires_at']}')?.isBefore(DateTime.now()) ??
          false;
      return AdminCard(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '${row['title']}',
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
            ),
            const IosGap(height: 8),
            Text('${row['body']}'),
            const IosGap(height: 12),
            Wrap(
              spacing: 10,
              runSpacing: 6,
              children: [
                AdminStatus(
                  row['archived_at'] != null
                      ? 'archived'
                      : expired
                      ? 'expired'
                      : 'published',
                ),
                Text(
                  '${row['audience']} · ${row['channel']} · ${PlatformAdminService.date(row['created_at'])}',
                ),
              ],
            ),
            if (row['archived_at'] == null)
              TextButton.icon(
                onPressed: () => _archive(row),
                icon: const Icon(Icons.archive_outlined),
                label: const Text('Archive'),
              ),
          ],
        ),
      );
    }
    return AdminCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            '${row['action']}'.replaceAll('_', ' '),
            style: const TextStyle(fontWeight: FontWeight.w800),
          ),
          Text(
            '${row['actor']} · ${PlatformAdminService.date(row['created_at'])}',
          ),
          if (row['business'] != null) Text('${row['business']}'),
          if (PlatformAdminService.map(row['details'])['reason'] != null)
            Text('${PlatformAdminService.map(row['details'])['reason']}'),
        ],
      ),
    );
  }

  static const _subtitles = {
    'overview': 'Your platform at a glance.',
    'analytics':
        'Subscription performance, business growth and support activity.',
    'businesses': 'Manage suppliers, butchers and account access.',
    'billing': 'Memberships, CutLink invoices and payments in one place.',
    'announcements': 'Keep the right businesses informed.',
    'audit': 'A traceable history of administrative actions and trade access.',
    'preferences': 'Manage your admin notification preferences.',
  };
  Widget _filters() => IosPadding(
    padding: const EdgeInsets.fromLTRB(20, 4, 20, 12),
    child: Column(
      children: [
        TextField(
          key: ValueKey(_tab),
          decoration: InputDecoration(
            labelText: _tab == 'invoices'
                ? 'Search invoice number or business'
                : 'Search business or billing email',
            prefixIcon: const Icon(Icons.search_rounded),
          ),
          onChanged: (v) {
            _search = v;
            _debounce?.cancel();
            _debounce = Timer(const Duration(milliseconds: 350), () {
              _page = 0;
              _load();
            });
          },
        ),
        const IosGap(height: 10),
        IosPadding(
          padding: EdgeInsets.zero,
          child: Wrap(
            runSpacing: 6,
            children: [
              for (final option in <String?>[
                null,
                ...(_tab == 'businesses'
                    ? [
                        'supplier',
                        'butcher',
                        'pending',
                        'approved',
                        'suspended',
                        'rejected',
                      ]
                    : _tab == 'accounts'
                    ? [
                        'needs_invoice',
                        'on_hold',
                        'active',
                        'trial',
                        'paused',
                        'cancelled',
                        'unpaid',
                        'overdue',
                      ]
                    : ['unpaid', 'part_paid', 'paid', 'overdue', 'void']),
              ])
                IosPadding(
                  padding: const EdgeInsets.only(right: 7),
                  child: ChoiceChip(
                    label: Text(
                      option == null
                          ? 'All'
                          : option == 'needs_invoice'
                          ? 'Ready to invoice'
                          : option.replaceAll('_', ' '),
                    ),
                    selected: _filter == option,
                    onSelected: (_) {
                      setState(() {
                        _filter = option;
                        _page = 0;
                      });
                      _load();
                    },
                  ),
                ),
            ],
          ),
        ),
      ],
    ),
  );
  Widget _records() => _loading
      ? const WorkspaceLoading(label: 'Loading admin workspace…')
      : _error != null
      ? Center(
          child: IosPadding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(
                  Icons.cloud_off_outlined,
                  size: 34,
                  color: AdminTheme.muted,
                ),
                const IosGap(height: 14),
                Text(_error!),
                TextButton(onPressed: _load, child: const Text('Try again')),
              ],
            ),
          ),
        )
      : ListView(
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
          children: [
            if (_tab == 'overview')
              _overview()
            else ...[
              if (_rows.isEmpty)
                AdminCard(
                  child: IosPadding(
                    padding: const EdgeInsets.symmetric(vertical: 36),
                    child: Column(
                      children: [
                        Icon(
                          AdminNavigation.icon(_tab),
                          size: 38,
                          color: AdminTheme.muted,
                        ),
                        const IosGap(height: 14),
                        const Text(
                          'Nothing to show yet',
                          style: TextStyle(
                            fontWeight: FontWeight.w800,
                            fontSize: 18,
                          ),
                        ),
                        const IosGap(height: 6),
                        Text(
                          _search.isNotEmpty || _filter != null
                              ? 'Try changing your search or filter.'
                              : 'New records will appear here.',
                          style: TextStyle(color: AdminTheme.muted),
                        ),
                      ],
                    ),
                  ),
                ),
              for (final row in _rows.take(50)) _row(row),
              if (_rows.isNotEmpty || _page > 0)
                AdminPager(
                  page: _page,
                  more: _rows.length > 50,
                  onPage: (v) {
                    _page = v;
                    _load();
                  },
                ),
            ],
          ],
        );
  @override
  Widget build(BuildContext context) {
    if (ModalRoute.of(context)?.isCurrent == true) {
      PageLocation.workspace({
        'page': 'admin',
        'tab': _tab == 'billing'
            ? (_billingView == 'pricing' ? 'memberships' : _billingView)
            : _tab,
      });
    }
    return AdminTheme(
      child: Scaffold(
        appBar: phoneAppBar(
          context,
          AppBar(
            leading: const WorkspaceBackButton(),
            title: const Row(
              children: [
                CutLinkLogo(width: 120, height: 30),
                SizedBox(width: 10),
                Text('Admin'),
              ],
            ),
            actions: [
              const AdminProductNotificationsBell(),
              IconButton(
                tooltip: 'Admin settings',
                onPressed: () => _change('preferences'),
                icon: const Icon(Icons.settings_outlined),
              ),
              IconButton(
                tooltip: 'Support inbox',
                onPressed: () => _change('support'),
                icon: const Icon(Icons.support_agent),
              ),
              if (_tab != 'analytics' &&
                  _tab != 'homepage' &&
                  _tab != 'preferences')
                IconButton(
                  tooltip: 'Refresh',
                  onPressed: _load,
                  icon: const Icon(Icons.refresh_rounded),
                ),
            ],
          ),
        ),
        body: AdminNavigation(
          items: _tabs,
          value: _tab,
          onChanged: _change,
          child: Align(
            alignment: Alignment.topCenter,
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 1440),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  IosPadding(
                    padding: const EdgeInsets.fromLTRB(20, 20, 20, 12),
                    child: Wrap(
                      alignment: WrapAlignment.spaceBetween,
                      spacing: 16,
                      runSpacing: 12,
                      crossAxisAlignment: WrapCrossAlignment.center,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              _tabs[_tab] ?? 'Admin',
                              style: const TextStyle(
                                fontSize: 25,
                                fontWeight: FontWeight.w800,
                                letterSpacing: -.5,
                              ),
                            ),
                            const IosGap(height: 4),
                            Text(
                              _subtitles[_tab] ?? '',
                              style: TextStyle(
                                color: AdminTheme.muted,
                                fontSize: 12,
                              ),
                            ),
                          ],
                        ),
                        if (_tab == 'announcements')
                          FilledButton.icon(
                            onPressed: _announcement,
                            icon: const Icon(Icons.add, size: 18),
                            label: const Text('New announcement'),
                          ),
                      ],
                    ),
                  ),
                  if (_tab == 'businesses') _filters(),
                  Expanded(
                    child: _tab == 'billing'
                        ? AdminBillingPanel(
                            key: ValueKey(_request),
                            initialView: _billingView,
                            initialFilter: _filter,
                            onViewChanged: (view) {
                              setState(() {
                                _billingView = view;
                                _filter = null;
                              });
                            },
                          )
                        : _tab == 'preferences'
                        ? const AdminNotificationSettingsPage(embedded: true)
                        : _tab == 'homepage'
                        ? const AdminFeaturedBusinessesPanel()
                        : _tab == 'analytics'
                        ? AdminAnalyticsPanel(
                            onNavigate: _change,
                            onBusiness: _business,
                          )
                        : _records(),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
