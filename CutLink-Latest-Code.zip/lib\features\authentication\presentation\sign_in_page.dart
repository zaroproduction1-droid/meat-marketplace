import '../../../shared/widgets/ios_density.dart';
import '../../../shared/widgets/public_auth_frame.dart';
import '../../../shared/widgets/ios_workspace.dart';
import 'restricted_account_page.dart';

import 'package:flutter/material.dart';

import '../../landing/presentation/public_page_palette.dart';

import 'package:supabase_flutter/supabase_flutter.dart';

import 'pending_verification_page.dart';
import 'business_details_page.dart';
import 'registration_type_page.dart';
import '../../dashboard/presentation/business_dashboard_page.dart';

class SignInPage extends StatefulWidget {
  const SignInPage({super.key, this.businessType, this.restoreSession = false});

  final BusinessType? businessType;
  final bool restoreSession;

  @override
  State<SignInPage> createState() => _SignInPageState();
}

class _SignInPageState extends State<SignInPage> {
  final _formKey = GlobalKey<FormState>();

  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();

  bool _hidePassword = true;
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    if (widget.restoreSession) {
      _isLoading = true;
      WidgetsBinding.instance.addPostFrameCallback((_) => _restoreSession());
    }
  }

  Future<void> _restoreSession() async {
    try {
      final auth = Supabase.instance.client.auth;
      if (auth.currentSession == null) {
        if (mounted) {
          setState(() => _isLoading = false);
        }
        return;
      }
      if (auth.currentSession!.isExpired) {
        await auth.refreshSession();
      }
      if (!mounted) {
        return;
      }
      await _openAccount();
    } catch (error) {
      if (!mounted) {
        return;
      }
      setState(() => _isLoading = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text(
            'Could not restore your session. Check your connection and retry.',
          ),
          action: SnackBarAction(
            label: 'Retry',
            onPressed: () {
              setState(() => _isLoading = true);
              _restoreSession();
            },
          ),
        ),
      );
    }
  }

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  String? _validateEmail(String? value) {
    final email = value?.trim() ?? '';

    if (email.isEmpty) {
      return 'Please enter your email address.';
    }

    if (!RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$').hasMatch(email)) {
      return 'Please enter a valid email address.';
    }

    return null;
  }

  String? _validatePassword(String? value) {
    if (value == null || value.isEmpty) {
      return 'Please enter your password.';
    }

    return null;
  }

  Future<void> _signIn() async {
    if (_isLoading) {
      return;
    }
    FocusScope.of(context).unfocus();

    if (!_formKey.currentState!.validate()) {
      return;
    }

    setState(() {
      _isLoading = true;
    });

    try {
      await Supabase.instance.client.auth.signInWithPassword(
        email: _emailController.text.trim(),
        password: _passwordController.text,
      );

      if (!mounted) {
        return;
      }

      await _openAccount();
    } on AuthException catch (error) {
      if (!mounted) {
        return;
      }

      setState(() {
        _isLoading = false;
      });

      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(error.message)));
    } catch (_) {
      if (!mounted) {
        return;
      }

      setState(() {
        _isLoading = false;
      });

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Sign-in could not complete. Check your connection and try again.',
          ),
        ),
      );
    }
  }

  Future<void> _openAccount() async {
    final user = Supabase.instance.client.auth.currentUser;

    if (user == null) {
      throw Exception('Unable to find the signed-in user.');
    }

    final response = await Supabase.instance.client.rpc(
      'get_my_cutlink_access',
    );
    final access = response is Map
        ? Map<String, dynamic>.from(response)
        : <String, dynamic>{};
    if (!mounted) {
      return;
    }
    if (access.isEmpty) {
      throw StateError('Unable to check account access. Please try again.');
    }
    if (access['is_admin'] == true || access['can_enter'] == true) {
      Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(builder: (_) => const BusinessDashboardPage()),
        (route) => !useIosWorkspace(context) && route.isFirst,
      );
      return;
    }
    if (access['pending'] == true) {
      Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(builder: (_) => const PendingVerificationPage()),
        (route) => route.isFirst,
      );
      return;
    }
    if (access['restrictions'] is List &&
        (access['restrictions'] as List).isNotEmpty) {
      Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(
          builder: (_) => RestrictedAccountPage(access: access),
        ),
        (_) => false,
      );
      return;
    }
    if (access['has_membership'] != true) {
      BusinessType? selectedBusinessType = widget.businessType;

      final metadataType = user.userMetadata?['business_type'] as String?;

      if (selectedBusinessType == null) {
        if (metadataType == 'supplier') {
          selectedBusinessType = BusinessType.supplier;
        } else if (metadataType == 'butcher') {
          selectedBusinessType = BusinessType.butcher;
        }
      }

      if (selectedBusinessType == null) {
        throw Exception('The business type could not be identified.');
      }

      Navigator.of(context).pushReplacement(
        MaterialPageRoute(
          builder: (context) =>
              BusinessDetailsPage(businessType: selectedBusinessType!),
        ),
      );

      return;
    }

    throw StateError(
      'Your business access is not active yet. Please contact the person who invited you.',
    );
  }

  @override
  Widget build(BuildContext context) {
    const darkRed = Color(0xFF933744);

    if (widget.restoreSession && _isLoading) {
      return const Scaffold(
        body: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              CircularProgressIndicator(),
              IosGap(height: 18),
              Text('Opening your CutLink account…'),
            ],
          ),
        ),
      );
    }
    return PublicAuthFrame(
      title: 'Welcome back to CutLink.',
      description: 'Your orders, stock and accounts — ready when you are.',
      child: Form(
        key: _formKey,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text(
              'Welcome back',
              style: TextStyle(fontSize: 30, fontWeight: FontWeight.w800),
            ),
            const IosGap(height: 12),
            Text(
              'Sign in using your confirmed email address.',
              style: TextStyle(color: PublicPagePalette.muted),
            ),
            const IosGap(height: 30),
            TextFormField(
              controller: _emailController,
              autofillHints: const [
                AutofillHints.username,
                AutofillHints.email,
              ],
              autocorrect: false,
              keyboardType: TextInputType.emailAddress,
              textInputAction: TextInputAction.next,
              decoration: const InputDecoration(labelText: 'Email address'),
              validator: _validateEmail,
            ),
            const IosGap(height: 18),
            TextFormField(
              controller: _passwordController,
              autofillHints: const [AutofillHints.password],
              autocorrect: false,
              enableSuggestions: false,
              obscureText: _hidePassword,
              textInputAction: TextInputAction.done,
              decoration: InputDecoration(
                labelText: 'Password',

                suffixIcon: IconButton(
                  tooltip: 'Show or hide password',
                  onPressed: () {
                    setState(() {
                      _hidePassword = !_hidePassword;
                    });
                  },
                  icon: Icon(
                    _hidePassword
                        ? Icons.visibility_outlined
                        : Icons.visibility_off_outlined,
                  ),
                ),
              ),
              validator: _validatePassword,
              onFieldSubmitted: (_) {
                _signIn();
              },
            ),
            const IosGap(height: 28),
            FilledButton(
              onPressed: _isLoading ? null : _signIn,
              style: FilledButton.styleFrom(
                backgroundColor: darkRed,
                padding: const EdgeInsets.symmetric(vertical: 18),
              ),
              child: _isLoading
                  ? const SizedBox(
                      width: 22,
                      height: 22,
                      child: CircularProgressIndicator(
                        strokeWidth: 2.5,
                        color: Colors.white,
                      ),
                    )
                  : const Text(
                      'Sign in',
                      style: TextStyle(
                        fontSize: 17,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
            ),
            const IosGap(height: 18),
            TextButton(
              onPressed: _isLoading
                  ? null
                  : () => Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (_) => const RegistrationTypePage(),
                      ),
                    ),
              child: const Text('New to CutLink? Register your business'),
            ),
          ],
        ),
      ),
    );
  }
}
