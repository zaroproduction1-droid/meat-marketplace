import '../theme/cutlink_appearance.dart';
import '../../features/orders/presentation/supplier_work_order_page.dart';
import '../navigation/page_location.dart';
import '../../features/credits/presentation/credit_notes_page.dart';

import 'dart:async';

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

/// One participant-scoped conversation; sending never changes a resolution.
class OrderIssueChat extends StatefulWidget {
  const OrderIssueChat({
    super.key,
    required this.issue,
    required this.businessId,
    required this.role,
    required this.orderReference,
    required this.otherParty,
    this.onReplacement,
  });
  final Map<String, dynamic> issue;
  final String businessId;
  final String role;
  final String orderReference;
  final String otherParty;
  final Future<void> Function()? onReplacement;

  @override
  State<OrderIssueChat> createState() => _OrderIssueChatState();
}

class _OrderIssueChatState extends State<OrderIssueChat> {
  final _text = TextEditingController();
  final _scroll = ScrollController();
  Timer? _timer;
  List<Map<String, dynamic>> _messages = [];
  late Map<String, dynamic> _issue;
  bool _loading = true;
  bool _fetching = false;
  bool _sending = false;
  bool _sent = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _issue = Map<String, dynamic>.from(widget.issue);
    _reload();
    // Only this open conversation is refreshed. No global listeners.
    _timer = Timer.periodic(const Duration(seconds: 8), (_) => _reload());
  }

  @override
  void dispose() {
    _timer?.cancel();
    _text.dispose();
    _scroll.dispose();
    super.dispose();
  }

  Future<void> _reload() async {
    if (_fetching || _sending) {
      return;
    }
    _fetching = true;
    final follow =
        !_loading && _scroll.hasClients && _scroll.position.extentAfter < 100;
    try {
      final client = Supabase.instance.client;
      final values = await Future.wait<dynamic>([
        client
            .from('order_issue_messages')
            .select()
            .eq('order_issue_id', widget.issue['id'].toString())
            .order('created_at')
            .order('id'),
        client
            .from('order_issues')
            .select()
            .eq('id', widget.issue['id'].toString())
            .single(),
      ]).timeout(const Duration(seconds: 20));
      if (!mounted) {
        return;
      }
      final rows = (values[0] as List)
          .map((e) => Map<String, dynamic>.from(e as Map))
          .toList();
      // An in-flight refresh must not discard a message just sent locally.
      final ids = rows.map((row) => row['id']).toSet();
      rows.addAll(_messages.where((row) => !ids.contains(row['id'])));
      rows.sort((a, b) {
        final byDate = a['created_at'].toString().compareTo(
          b['created_at'].toString(),
        );
        return byDate != 0
            ? byDate
            : a['id'].toString().compareTo(b['id'].toString());
      });
      final changed = rows.length != _messages.length;
      setState(() {
        _messages = rows;
        _issue = Map<String, dynamic>.from(values[1] as Map);
        _loading = false;
        _error = null;
      });
      if (follow && changed) {
        _toLatest();
      }
    } catch (_) {
      if (mounted) {
        setState(() {
          _loading = false;
          _error = 'Messages could not refresh. Your draft is still here.';
        });
      }
    } finally {
      _fetching = false;
    }
  }

  void _toLatest() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted && _scroll.hasClients) {
        _scroll.animateTo(
          _scroll.position.maxScrollExtent,
          duration: const Duration(milliseconds: 250),
          curve: Curves.easeOut,
        );
      }
    });
  }

  Future<void> _send() async {
    final body = _text.text.trim();
    if (_sending || body.isEmpty) {
      return;
    }
    setState(() {
      _sending = true;
      _error = null;
    });
    try {
      final row = await Supabase.instance.client
          .from('order_issue_messages')
          .insert({
            'order_issue_id': widget.issue['id'],
            'sender_business_id': widget.businessId,
            'sender_role': widget.role,
            'message': body,
          })
          .select()
          .single();
      if (!mounted) {
        return;
      }
      _text.clear();
      setState(() {
        if (!_messages.any((m) => m['id'] == row['id'])) {
          _messages.add(Map<String, dynamic>.from(row));
        }
        _sent = true;
      });
      _toLatest();
    } catch (_) {
      if (mounted) {
        setState(
          () => _error =
              'Message could not be sent. Your draft has been kept; check the conversation before retrying.',
        );
      }
    } finally {
      if (mounted) {
        setState(() => _sending = false);
      }
    }
  }

  Future<void> _action(String action) async {
    final note = TextEditingController();
    String resolution = 'other';
    final title = switch (action) {
      'resolve' => 'Mark issue resolved',
      'reject' => 'Decline issue',
      'reopen' => 'Reopen issue',
      'confirm' => 'Confirm the issue is fixed',
      _ => 'Start reviewing',
    };
    final accepted = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, change) => AlertDialog(
          title: Text(title),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                if (action == 'resolve') ...[
                  DropdownButtonFormField<String>(
                    initialValue: resolution,
                    decoration: const InputDecoration(
                      labelText: 'Completed outcome',
                    ),
                    items: const [
                      DropdownMenuItem(
                        value: 'other',
                        child: Text('Fixed / agreed solution'),
                      ),
                      DropdownMenuItem(
                        value: 'replacement',
                        child: Text('Replacement delivered'),
                      ),
                      DropdownMenuItem(
                        value: 'credit_note',
                        child: Text('Credit note issued'),
                      ),
                      DropdownMenuItem(
                        value: 'refund',
                        child: Text('Refund recorded'),
                      ),
                    ],
                    onChanged: (v) => change(() => resolution = v!),
                  ),
                  const SizedBox(height: 12),
                ],
                if (action == 'confirm')
                  const Text(
                    'Confirm that the supplier’s resolution has fixed your issue.',
                  )
                else if (action != 'review')
                  TextField(
                    controller: note,
                    minLines: 2,
                    maxLines: 4,
                    decoration: InputDecoration(
                      labelText: 'Reason / outcome',
                      border: OutlineInputBorder(),
                    ),
                  ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Cancel'),
            ),
            FilledButton(
              onPressed: () {
                if (action != 'review' &&
                    action != 'confirm' &&
                    note.text.trim().isEmpty) {
                  ScaffoldMessenger.of(ctx).showSnackBar(
                    const SnackBar(content: Text('Enter a reason or outcome.')),
                  );
                  return;
                }
                Navigator.pop(ctx, true);
              },
              child: Text(title),
            ),
          ],
        ),
      ),
    );
    final body = note.text.trim();
    note.dispose();
    if (accepted != true || !mounted) {
      return;
    }
    setState(() => _sending = true);
    bool success = false;
    try {
      await Supabase.instance.client.rpc(
        'transition_marketplace_issue',
        params: {
          'p_issue_id': widget.issue['id'],
          'p_action': action,
          'p_note': body,
          'p_resolution': action == 'resolve' ? resolution : null,
        },
      );
      _sent = true;
      success = true;
    } catch (e) {
      if (mounted) {
        setState(() => _error = e.toString());
      }
    } finally {
      if (mounted) {
        setState(() => _sending = false);
      }
    }
    if (mounted && success) {
      await _reload();
    }
  }

  Future<void> _credits({bool create = false}) async {
    setState(() => _sending = true);
    var success = false;
    try {
      final invoice = await Supabase.instance.client
          .from('invoices')
          .select('id')
          .eq('order_id', _issue['order_id'].toString())
          .inFilter('status', ['issued', 'part_paid', 'paid'])
          .limit(1)
          .maybeSingle();
      if (!mounted) {
        return;
      }
      if (invoice == null) {
        setState(
          () => _error = 'No issued invoice is available for this order yet.',
        );
        return;
      }
      await Navigator.of(context).push(
        MaterialPageRoute<void>(
          builder: (_) => create
              ? CreditNoteEditor(
                  invoiceId: invoice['id'].toString(),
                  issueId: _issue['id'].toString(),
                )
              : CreditNotesPage(
                  supplierView: widget.role == 'supplier',
                  invoiceId: invoice['id'].toString(),
                ),
        ),
      );
      success = true;
    } catch (e) {
      if (mounted) {
        setState(() => _error = e.toString());
      }
    } finally {
      if (mounted) {
        setState(() => _sending = false);
      }
    }
    if (mounted && success) {
      await _reload();
    }
  }

  Future<void> _replacement() async {
    if (_sending) {
      return;
    }
    if (widget.onReplacement != null) {
      setState(() => _sending = true);
      try {
        await widget.onReplacement!();
        if (mounted) {
          await _reload();
        }
      } finally {
        if (mounted) {
          setState(() => _sending = false);
        }
      }
      return;
    }
    final confirmed = _issue['replacement_order_id'] != null
        ? true
        : await showDialog<bool>(
            context: context,
            builder: (ctx) => AlertDialog(
              title: const Text('Arrange replacement'),
              content: const Text(
                'Create a no-charge replacement order for the affected products? It will appear in supplier Work Orders.',
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(ctx, false),
                  child: const Text('Cancel'),
                ),
                FilledButton(
                  onPressed: () => Navigator.pop(ctx, true),
                  child: const Text('Create replacement'),
                ),
              ],
            ),
          );
    if (confirmed != true || !mounted) {
      return;
    }
    setState(() => _sending = true);
    var success = false;
    try {
      final replacementId = await Supabase.instance.client.rpc(
        'create_replacement_order',
        params: {'target_issue_id': _issue['id']},
      );
      final id = replacementId?.toString();
      if (id == null || id.isEmpty) {
        throw StateError('The replacement work order was not returned.');
      }
      if (!mounted) {
        return;
      }
      await Navigator.of(context).push<void>(
        MaterialPageRoute<void>(
          builder: (_) => SupplierWorkOrderPage(orderId: id),
        ),
      );
      _sent = true;
      success = true;
    } catch (e) {
      if (mounted) {
        setState(() => _error = e.toString());
      }
    } finally {
      if (mounted) {
        setState(() => _sending = false);
      }
    }
    if (mounted && success) {
      await _reload();
    }
  }

  Widget _resolutionActions() {
    final closed = [
      'resolved',
      'rejected',
      'cancelled',
    ].contains(_issue['status']);
    final supplier = widget.role == 'supplier';
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: [
          if (supplier && !closed) ...[
            if (_issue['status'] == 'requested')
              TextButton(
                onPressed: _sending ? null : () => _action('review'),
                child: const Text('Start review'),
              ),
            TextButton(
              onPressed: _sending ? null : _replacement,
              child: Text(
                _issue['replacement_order_id'] == null
                    ? 'Create replacement work order'
                    : 'Open replacement work order',
              ),
            ),
            TextButton(
              onPressed: _sending ? null : () => _credits(create: true),
              child: const Text('Issue credit / refund'),
            ),
            FilledButton.icon(
              onPressed: _sending ? null : () => _action('resolve'),
              icon: const Icon(Icons.task_alt),
              label: const Text('Mark resolved'),
            ),
            TextButton(
              onPressed: _sending ? null : () => _action('reject'),
              child: const Text('Decline'),
            ),
          ],
          TextButton(
            onPressed: _sending ? null : () => _credits(),
            child: const Text('Credit notes'),
          ),
          if (closed && _issue['status'] != 'cancelled')
            TextButton(
              onPressed: _sending ? null : () => _action('reopen'),
              child: const Text('Still unresolved? Reopen'),
            ),
          if (!supplier &&
              _issue['status'] == 'resolved' &&
              _issue['butcher_confirmed_at'] == null)
            FilledButton.icon(
              onPressed: _sending ? null : () => _action('confirm'),
              icon: const Icon(Icons.check),
              label: const Text('Confirm fixed'),
            ),
          if (_issue['butcher_confirmed_at'] != null)
            const Chip(label: Text('Confirmed fixed by butcher')),
        ],
      ),
    );
  }

  String _date(dynamic value) {
    final d = DateTime.tryParse(value?.toString() ?? '')?.toLocal();
    if (d == null) {
      return '';
    }
    return '${d.day}/${d.month}/${d.year} ${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';
  }

  Widget _bubble(Map<String, dynamic> message) {
    final own = message['sender_business_id'] == widget.businessId;
    return Align(
      alignment: own ? Alignment.centerRight : Alignment.centerLeft,
      child: FractionallySizedBox(
        widthFactor: .86,
        child: Container(
          margin: const EdgeInsets.only(bottom: 12),
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: own
                ? CutLinkPalette.color(0xFF111C27)
                : CutLinkPalette.surface,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: CutLinkPalette.color(0xFFE1E3E5)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                '${own ? 'You' : widget.otherParty} • ${_date(message['created_at'])}',
                style: TextStyle(
                  fontSize: 11,
                  color: own
                      ? Colors.white70
                      : CutLinkPalette.color(0xFF656970),
                ),
              ),
              const SizedBox(height: 5),
              SelectableText(
                message['message']?.toString() ?? '',
                style: TextStyle(
                  fontSize: 14,
                  height: 1.4,
                  color: own ? Colors.white : CutLinkPalette.color(0xFF20252B),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    AppearanceScope.watch(context);
    PageLocation.track(context, {
      'page': 'issue',
      'id': widget.issue['id'],
      'reference': widget.orderReference,
      'other': widget.otherParty,
    });
    final status = switch (_issue['status']?.toString()) {
      'approved' => 'Resolution proposed',
      'under_review' => 'Under review',
      'resolved' => 'Resolved',
      'rejected' => 'Declined',
      'cancelled' => 'Cancelled',
      _ => 'Awaiting supplier review',
    };
    return PopScope(
      canPop: !_sending,
      child: Dialog(
        backgroundColor: CutLinkPalette.color(0xFFF7F8FA),
        insetPadding: EdgeInsets.all(
          MediaQuery.sizeOf(context).width < 600 ? 8 : 24,
        ),
        clipBehavior: Clip.antiAlias,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        child: SizedBox(
          width: 820,
          height: 760,
          child: Column(
            children: [
              Container(
                color: CutLinkPalette.surface,
                padding: const EdgeInsets.fromLTRB(16, 12, 6, 12),
                child: Row(
                  children: [
                    const Icon(Icons.forum_outlined, color: Color(0xFF741C1C)),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            widget.otherParty,
                            style: const TextStyle(
                              fontSize: 17,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                          Text(
                            '${widget.orderReference} • $status',
                            style: const TextStyle(fontSize: 12),
                          ),
                        ],
                      ),
                    ),
                    IconButton(
                      tooltip: 'Refresh conversation',
                      onPressed: _sending ? null : _reload,
                      icon: const Icon(Icons.refresh),
                    ),
                    IconButton(
                      tooltip: 'Close conversation',
                      onPressed: _sending
                          ? null
                          : () => Navigator.pop(context, _sent),
                      icon: const Icon(Icons.close),
                    ),
                  ],
                ),
              ),
              const Divider(height: 1),
              Expanded(
                child: _loading
                    ? const Center(child: CircularProgressIndicator())
                    : ListView(
                        controller: _scroll,
                        padding: const EdgeInsets.all(16),
                        children: [
                          Container(
                            padding: const EdgeInsets.all(14),
                            margin: const EdgeInsets.only(bottom: 16),
                            decoration: BoxDecoration(
                              color: CutLinkPalette.color(0xFFF4E9E9),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Text(
                                  'Original issue',
                                  style: TextStyle(fontWeight: FontWeight.w800),
                                ),
                                const SizedBox(height: 6),
                                SelectableText(
                                  _issue['description']?.toString() ?? '',
                                ),
                                if ((_issue['resolution_type']?.toString() ??
                                        '')
                                    .isNotEmpty) ...[
                                  const SizedBox(height: 8),
                                  Text(
                                    'Proposed outcome: ${_issue['resolution_type'].toString().replaceAll('_', ' ')}',
                                  ),
                                ],
                              ],
                            ),
                          ),
                          if (_messages.isEmpty)
                            const Padding(
                              padding: EdgeInsets.all(16),
                              child: Text(
                                'Ask a question or share an update below.',
                              ),
                            ),
                          ..._messages.map(_bubble),
                        ],
                      ),
              ),
              if (_error != null)
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 16,
                    vertical: 8,
                  ),
                  child: Text(
                    _error!,
                    style: const TextStyle(color: Color(0xFF9B2424)),
                  ),
                ),
              Container(
                color: CutLinkPalette.surface,
                padding: const EdgeInsets.all(12),
                child: Column(
                  children: [
                    _resolutionActions(),
                    const SizedBox(height: 8),
                    Text(
                      'Use this conversation for messages. Use the actions below to complete the issue.',
                      style: TextStyle(
                        fontSize: 11,
                        color: CutLinkPalette.color(0xFF656970),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Expanded(
                          child: TextField(
                            controller: _text,
                            enabled: !_sending,
                            minLines: 1,
                            maxLines: 4,
                            textCapitalization: TextCapitalization.sentences,
                            decoration: InputDecoration(
                              hintText: 'Write a message…',
                              border: OutlineInputBorder(),
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        IconButton.filled(
                          tooltip: 'Send message',
                          onPressed: _sending ? null : _send,
                          icon: _sending
                              ? const SizedBox(
                                  width: 20,
                                  height: 20,
                                  child: CircularProgressIndicator(
                                    strokeWidth: 2,
                                  ),
                                )
                              : const Icon(Icons.send_rounded),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
