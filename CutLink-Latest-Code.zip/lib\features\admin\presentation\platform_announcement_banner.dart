import '../../../shared/theme/cutlink_appearance.dart';
import '../../../shared/widgets/ios_density.dart';
import 'announcement_style.dart';

import 'dart:async';

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../services/platform_admin_service.dart';

/// One lightweight refresh per minute, with no unfiltered realtime listener.
class PlatformAnnouncementBanner extends StatefulWidget {
  const PlatformAnnouncementBanner({super.key, required this.businessId});
  final String businessId;
  @override
  State<PlatformAnnouncementBanner> createState() =>
      _PlatformAnnouncementBannerState();
}

class _PlatformAnnouncementBannerState extends State<PlatformAnnouncementBanner>
    with WidgetsBindingObserver {
  List<AdminRow> _rows = [];
  final Set<String> _dismissed = {};
  Timer? _timer;
  bool _fetching = false;
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _start();
  }

  void _start() {
    _timer?.cancel();
    _load();
    _timer = Timer.periodic(const Duration(minutes: 1), (_) => _load());
  }

  @override
  void didUpdateWidget(covariant PlatformAnnouncementBanner oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.businessId != widget.businessId) {
      _rows = [];
      _dismissed.clear();
      _start();
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _start();
    } else {
      _timer?.cancel();
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _load() async {
    if (_fetching) {
      return;
    }
    _fetching = true;
    final id = widget.businessId;
    try {
      final rows = PlatformAdminService.rows(
        await Supabase.instance.client.rpc(
          'list_platform_banners',
          params: {'p_business_id': id},
        ),
      );
      if (mounted && id == widget.businessId) {
        setState(() => _rows = rows);
      }
    } catch (_) {
      /* Keep the workspace usable during a temporary connection issue. */
    } finally {
      _fetching = false;
    }
  }

  @override
  Widget build(BuildContext context) {
    AppearanceScope.watch(context);
    final rows = _rows
        .where((r) => !_dismissed.contains('${r['id']}'))
        .toList();
    if (rows.isEmpty) {
      return const SizedBox.shrink();
    }
    final row = rows.first;
    final tone = row['tone']?.toString() ?? 'normal';
    final foreground = AnnouncementStyle.foreground(tone);
    void readNotice() {
      showDialog<void>(
        context: context,
        builder: (c) => AlertDialog(
          title: Text('${row['title']}'),
          content: SingleChildScrollView(child: Text('${row['body']}')),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(c),
              child: const Text('Close'),
            ),
          ],
        ),
      );
    }

    return Material(
      color: CutLinkPalette.color(0xFFF5F6F8),
      child: SafeArea(
        bottom: false,
        child: IosPadding(
          padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
          child: Container(
            decoration: BoxDecoration(
              color: AnnouncementStyle.background(tone),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: foreground.withValues(alpha: .16)),
            ),
            padding: const EdgeInsets.fromLTRB(12, 8, 6, 8),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Icon(AnnouncementStyle.icon(tone), color: foreground, size: 21),
                const SizedBox(width: 12),
                Expanded(
                  child: InkWell(
                    onTap: readNotice,
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          '${row['title']}',
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            color: foreground,
                            fontSize: 13,
                            height: 1.35,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        const IosGap(height: 2),
                        Text(
                          '${row['body']}',
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            color: foreground,
                            fontSize: 12,
                            height: 1.35,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                TextButton(
                  onPressed: readNotice,
                  child: Text(
                    rows.length > 1 ? 'View (${rows.length})' : 'Read more',
                    style: TextStyle(color: foreground),
                  ),
                ),
                IconButton(
                  tooltip: 'Dismiss for this session',
                  onPressed: () =>
                      setState(() => _dismissed.add('${row['id']}')),
                  icon: Icon(Icons.close, size: 18, color: foreground),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
